<?php
/**
 * OpenCaseTracker
 * Copyright (C) 2010 Jason Cleeland
 * All rights reserved.
 * License: GNU/GPL License v2 or later, see LICENSE.php
 * LimeSurvey is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 *
 */

// no direct access
if (!isset($dbprefix) || isset($_REQUEST['dbprefix'])) {die("Cannot run this script directly");}
?>

OpenCaseTracker derives from copyrighted works licensed under the GNU General
Public License. This version has been modified pursuant to the GNU
General Public License as of August 5, 2007, and as distributed, it
includes or is derivative of works licensed under the GNU General Public
License or other free or open source software licenses, including works
copyrighted by any or all of the following, from 2005 through 2012:
Jason Cleeland

OpenCaseTracker also includes or is derivative of works distributed under 
the following copyright notices: Flyspray, 2005

