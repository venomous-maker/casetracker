; <?php die( 'Do not access this page directly.' ); ?>
; This is the OpenCaseTracker configuration file. It contains the basic settings
; needed for OpenCaseTracker to operate. All other preferences are stored in the
; database itself and are managed directly within the OpenCaseTracker admin interface.
; You should consider putting this file somewhere that isn't accessible using
; a web browser, and editing header.php to point to wherever you put this file.
; These values are found in the variable $conf_array['sectionname']['valuename']
; ie: $conf_array['general']['basedir']

[general]
basedir = "d:/xampp/htdocs/oct_install_test/"; Location of your OpenCaseTracker installation
cookiesalt = "4t"               			; Randomisation value for cookie encoding
adodbpath = "d:/xampp/htdocs/oct_install_test/classes/adodb5/adodb.inc.php"  ; Path to the main ADODB include file
jpgraphpath = "d:/xampp/htdocs/oct_install_test/classes/jpgraph"  			; Path to the main JPGraph DIRECTORY
phpmailerpath = "d:/xampp/htdocs/oct_install_test/scripts/phpmailer/"; Path to the phpmailer class
cookieprefix = "casetracker"  				; prefix for cookies, so that multiple versions can run
dbprefix = "casetracker_"					; Prefix for database tables
baseproject = 1								; The basic project to use if this is a single project installation (see line 83 or header.php)
cleanuphours = 2							; The number of hours to wait before cleaning up request_hashes
unsethash = 0								; Whether or not to delete the request_hash used to check for repeated actions: set to zero if in doubt
panicuser = 10								; The default user to select when panicing
attachmentdir = "d:/xampp/htdocs/oct_install_test/attachments"; The location where attachments should be stored
defaulttimezone = "UTC"                     ; The default timezone (Set to UTC or delete line to use system default if unsure) (eg: Australia/Melbourne)

[database]
dbtype = "mysql"                 			; Type of database ('mysql' or 'pgsql')
dbhost = "localhost"             			; Name or IP of your database server
dbname = "oct_test"             	 				; The name of the database
dbuser = "root"              				; The user to access the database
dbpass = ""              					; The password to go with that username above

[must]
usemust    = false					; True if you want to ingetrate CaseTracker with the MUST membership database
externaldb = "must"                 ; Name of the external membership system used (for the class file). Leave this is must if you aren't using any.
mustdbtype = "odbc"					; Database type for membershipdatabase
mustdbhost = "SYBASE"				;
mustdbname = "must2"				;
mustdbuser = "admin"				;
mustdbpass = "password"				;
mustodbcdsn = "must2"			    ;
mustfilestable = "files_v"          ;
financialsql  = "AND employers.emp_type='C'"		;

[email]
pop3host = "localhost"; The email server for receiving emails (attachments)
pop3account = "casetracker";
pop3password = "casetracker";
smtphost = "localhost";  The outgoing mail server
smtpaccount = "casetracker";
smtppassword = "casetracker";
smtp_auth = TRUE;
smtp_tls = TRUE;
smtp_ntlm = FALSE;
smtp_debug = 2;
;
;The following setup options are used to retrieve/collect emails sent
;to the casetracker email account.
;
attach_address = "casetracker@mydomain.com"; The email address used for sending attachments to casetracker
tempdir = "d:/xampp/htdocs/oct_install_test/scripts/emailtemp/"; Location of temp dir for email
keeplog = FALSE; True to keep a log of emails or false to not
;
;Here is where you set the actual basic account and method for retrieval
;
retrievalmethod = "pop"; pop or imap (note that imap requires the php imap modules)
retrievalhost = "localhost"; The email server for receiving emails (attachments)
retrievalaccount = "casetracker";
retrievalpassword = "casetracker";
;
;If you're using POP as the retrieval method, these are additional settings used 
;to establish the connection with different systems
;
classdir = "d:/xampp/htdocs/oct_install_test/scripts/pop3class/"; Location of pop3 classes
pop3protocol = "tcp"; Choose between tcp, ssl, sslv2, sslv3, tls
pop3port = 110; tcp default is 110, tls is 995, ssl is 443
pop3useIPV6 = FALSE;
pop3usesockets = FALSE;
pop3autodetect = TRUE;
pop3hideusernameatlog = FALSE;
;
;If you're using imap as the retrieval method, these are additional settings used
;to establish the imap connection.
;
imapoptions = ""; Additional options such as "/imap/ssl/notls/secure"
imapport = "143"; Port to connect (ie: 993 for ssl)
imapmailbox = "Inbox"; Name of the default mailbox to use
;
use_replyto = true; Set to true if your server can't fake the sender address (ie: authentication requires the sender be the same as the logged in user) and you need to use the reply-to for replies to users instead
sendemaildebug = true; Show detailed debugging messages while sending emails (where available) - turn this off in production environments


[jpgraph]
jpgraphdir = "d:/xampp/htdocs/oct_install_test/classes/jpgraph/src"	;

[must_translate]
occupation = "class_descrip"		;
classgroup = "class_level"			;
level      = "attrib_3"				;
increment  = "attrib_4"				;
mobile     = "attrib_6"				;

[notifications]
groups     = "1,2,7,8"				;
project    = "4"					;
url        = "http://localhost/oct_install_test/";
from       = "Open Casetracker Mailer <casetracker@mydomain.com>";
admingroupexclude = "8"  ;
sendtoselfonattachmentemail = "1"; Even if the system thinks the email came from the user assigned to the case, send a notification anyway

[specialversions]
version_ids = "13,8";
message13   = "This is a pre-existing issue. All time spent on this case must be logged and recorded.";
style13     = "background-color: red; color: white; font-weight: bold; padding-left: 4px; padding-right: 4px;";
style8		= "background-color: yellow; color: blue; font-weight: bold; padding-left: 8px; padding-right: 8px;";

[billing]
deposit		= "650"					;
casetypes	= "13"					;
trigger     = "150"					;

[tab_display]
comments = "on"						;
attachments = "on"					;
peopleofinterest = "on"				;
related = "on"						;
masterservant = "on"				;
notify = "on"						;
strategy = "on"						;
billing = "on"						;
history = "on"						;

[member_tab_display]
general = "on";
workdetails = "on";
committees = "off";
files = "off";
cases="on";
notes="on";