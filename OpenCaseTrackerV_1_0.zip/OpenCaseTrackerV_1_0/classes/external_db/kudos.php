<?php
/**
* Class CaseTracker extends the base class fucntionality with EXTERNAL database
* specific functions
* 
*/
class CaseTracker extends OCT {

    /**
    * Open connection to the database, in this case a standard ODBC connection.
    * On linux servers this requires openodbc or similar, and a dsn connection
    * 
    * @param mixed $mustodbcdsn The name DSN connection (from casetracker.conf.php)
    * @param mixed $mustdbuser The database username
    * @param mixed $mustdbpass The database password
    */
    function odbcOpen($mustodbcdsn = '', $mustdbuser='', $mustdbpass='') {
       $this->must2->dbtype = "mssql";
       $this->must2->dblink = NewADOConnection('odbc');
       $must2 = $this->must2->dblink->Connect($mustodbcdsn, $mustdbuser, $mustdbpass);
       $this->must2->dblink->SetFetchMode(ADODB_FETCH_BOTH);
       return $must2;
    }

    /**
    * Close the odbc database link
    * 
    */
    function odbcClose() {
      $this->must2->dblink->Close();
    }
   
    /**
    * Perform a SQL command on the odbc connection
    * 
    * @param mixed $sql The SQL command to perform
    * @param mixed $inputarr Any input values in an array format
    * @param mixed $numrows The number of rows to return (-1 = unlimited)
    * @param mixed $offset Which record to start at
    */
    function odbcExec($sql, $inputarr=false, $numrows=-1, $offset=-1) {

      $inputarr = $this->dbUndefToEmpty($inputarr); //Replace any undefined values (which should be treated as a null in SQL databases) with an empty string

      $ADODB_FETCH_MODE = ADODB_FETCH_ASSOC;
      if (($numrows>=0) or ($offset>=0)) {
          @$result =  $this->must2->dblink->SelectLimit($sql, $numrows, $offset, $inputarr);
      } else {
          @$result =  $this->must2->dblink->Execute($sql, $inputarr);
      }

      if (!$result) {
          if (function_exists("debug_backtrace")) {
              echo "<pre style='text-align: left;'>";
              var_dump(debug_backtrace());
              echo "</pre>";
          }

          die (sprintf("Query {%s} with params {%s} Failed! (%s)",
                    $sql, implode(', ', $inputarr),
                    $this->must2->dblink->ErrorMsg()));
      }
      return $result;
    }

    /**
    * Perform a query on the odbc connection (this is the function to use)
    * 
    * @param mixed $sql
    * @param mixed $inputarr
    * @param mixed $numrows
    * @param mixed $offset
    */
    function odbcQuery($sql, $inputarr=false, $numrows=-1, $offset=-1) {
      $result = $this->odbcExec($sql, $inputarr, $numrows, $offset);
      return $result;
    }

    function odbcFetchArray(&$result) {
      $row = $this->dbFetchRow($result);
      return $row;
    }

    /**
    * ReturnSmiley returns a smiley face based on the financiality of the member
    * 
    * @param mixed $member - the unique id of the member
    * @param mixed $tags - HTML tags to include in the output
    * @param mixed $popup - Extra text to include in the html popup message
    * @return mixed
    */
    function returnSmiley($member, $tags="", $popup="") {
       $flyspray_prefs = $this->GetGlobalPrefs();
       if ($member == 0) {
           return "";
       }
       
       $spd=$this->GetPaidTo($member);
       list($pfr, $pmt)=$this->GetPaymentInfo($member);
       $time=time();
       $offset=16; //How many days leeway to give before the smiley indicates they are behind.
                   //A value of 16, for example, will mean that the embarrassed face only starts showing up when the member is over 16 days in arrears
       $subs_paid_to=$spd ? intval(((((($spd)-time())/60/60/24)-(26-$offset))/30)+0) : 0;
       $spd_date=date("d M Y", $spd);
       $explanation = "This member is paying by $pmt, and payments are made $pfr. Subscriptions are currently paid up until $spd_date";
       $pay_method=$this->GetPayMethod($member);
       if ($this->GetLegitMemberNumber($member) && $pay_method != "P") {
          switch($subs_paid_to) {
             case -3:
               $output = "<img $tags src='themes/".$flyspray_prefs['theme_style']."/mortified.png' border='0' title='This member is financial but between two and three months in arrears! ($explanation)'";
               break;
             case -2:
               $output = "<img $tags src='themes/".$flyspray_prefs['theme_style']."/ashamed.png' border='0' title='This member is financial but between one and two months in arrears! ($explanation)'";
               break;
             case -1:
               $output = "<img $tags src='themes/".$flyspray_prefs['theme_style']."/embarrassed.png' border='0' title='This member is financial but up to one month in arrears! ($explanation)'";
               break;
             default:
               $output = "<img $tags src='themes/".$flyspray_prefs['theme_style']."/happy.png' border='0' title='This member is Fully financial $popup ($explanation)'";
               break;
          }
          if ($popup != "") {
              $output .=" onClick='alert(\"This member is FINANCIAL $popup\")'";
          }
          $output .= ">";
          return $output;
       } elseif ($this->GetLegitMemberNumber($member) && $pay_method == "P") {
          $output = "<img $tags src='themes/".$flyspray_prefs['theme_style']."/happy.png' border='0' title='This member is Fully financial $popup'";
          if ($popup != "") {
              $output .=" onClick='alert(\"This member is FINANCIAL $popup\")'";
          }
          $output .= ">";
          return $output;

       } else {
             $output ="<img $tags src='themes/".$flyspray_prefs['theme_style']."/sad.png' border='0' title='This member is Unfinancial!'";
          if ($popup != "") {
              $output .= "return  onClick='alert(\"This member is UNFINANCIAL $popup\")'";
          }
          $output .= ">";
          return $output;
       }
   }

    function GetLegitMemberNumber($member) {
        //Gets Legitimate Financial Member Numbers
        global $conf_array;
        $flyspray_prefs = $this->GetGlobalPrefs();
        $lang = $flyspray_prefs['lang_code'];
        $get_details = $this->odbcQuery("SELECT Members.MemberID
                                                  FROM Members
                                                  WHERE 1=1
                                                  ".$conf_array['must']['financialsql']."
                                                  AND Members.memberID = $member
                                                  ORDER BY MemberID");
        $get_details = $this->odbcFetchArray($get_details);
        if (empty($get_details)) {
            return FALSE;
        }

        return TRUE;
    }

    function GetPaidTo($member) {
      //Gets "paid_to" date for member
      $flyspray_prefs = $this->GetGlobalPrefs();
      $updatecache=false;
      //Hack for original must_member_cache
      $cachetable="casetracker_member_cache";
      
      $get_details = $this->dbQuery("SELECT subs_paid_to, modified FROM $cachetable WHERE member=?", array(intval($member)));
      $get_details = $this->dbFetchRow($get_details);
      $mymodified=$get_details['modified'];
        if(!isset($get_details['modified']) || $get_details['modified'] <= time()-(60*60*24)) {
            $get_details = $this->odbcQuery("SELECT FinancialToDate as subs_paid_to, Surname as surname, GivenNames as pref_name, 
                                             AdmissionDate as joined, Employers.EmployerGroup as paying_emp 
                                             FROM Members, Employers
                                             WHERE Members.Employer=Employers.EmployerID
                                             AND Members.MemberID=?", array(intval($member)));
            $get_details = $this->dbFetchRow($get_details);
            if(!$mymodified) {
                $insertcache=true;
            } else {
                $updatecache=true;
            }
        }
      if(empty($get_details['subs_paid_to'])) {$get_details['subs_paid_to']="1980-01-01 12:00:00";}
      list($jdate, $jtime) = explode(" ", $get_details['subs_paid_to']);
      list($year, $month, $day)=explode("-",$jdate);
      if($updatecache) {
        $updatenow = $this->dbQuery("UPDATE $cachetable SET subs_paid_to=?, modified=? WHERE member=?", array("$year-$month-$day", time(), intval($member)));
      }
        if($insertcache) {
            $this->dbQuery("INSERT INTO $cachetable (member, subs_paid_to, paying_emp, joined, surname, pref_name, modified)
                             VALUES (".intval($member).", '$year-$month-$day', '".$get_details['paying_emp']."', '".$get_details['joined']."', '".mysql_escape_string($get_details['surname'])."', '".$get_details['pref_name']."', ".time().")");
        }
        return mktime(0, 0, 0, $month, $day, $year);
    }

    function GetPayMethod($member) {
      $flyspray_prefs = $this->GetGlobalPrefs();
      $get_details = $this->odbcQuery("SELECT PayMethod FROM Members WHERE MemberID=?", array(intval($member)));
      $get_details = $this->dbFetchRow($get_details);
      return $get_details['PayMethod'];
    }

    function GetPaymentInfo($member) {
      $flyspray_prefs=$this->GetGlobalPrefs();
      $get_details = $this->odbcQuery("SELECT '-' as pay_frequency_descrip, PayMethods.description as pay_method_descrip
                                       FROM Members, PayMethods
                                       WHERE Members.PayMethod=PayMethods.Code
                                       AND MemberID = ?", array(intval($member)));
      $get_details = $this->dbFetchRow($get_details);
      return array($get_details['pay_frequency_descrip'], $get_details['pay_method_descrip']);
    }

    function highlightMemberNumberByEmpType($member, $emp_type) {
        if ($emp_type == "C" || $emp_type == "X") {
            return "<font color='green'>$member</font>";
        } else {
            return "<font color='red'>$member</font>";
        }
    }

    function returnMemberNumber($member, $searchbutton=TRUE) {
        global $project_prefs, $flyspray_prefs;
        if ($member == 0) {
            $number = "N/A";
        } else {
            $number = $member;
        }
        if ($this->GetLegitMemberNumber($member)) {
            $output="<font color='green'>$number</font>";
        } else {
            $output="<font color='red'>$number</font>";
        }
        if ($search) {
            $output.= "&nbsp;<a href='' onClick='window.open(\"index.php?do=member_search&member=$number\", \"_blank\", \"toolbar=no, scrollbars=yes, width=610, height=450\")'><img src='themes/" . $project_prefs['theme_style'] . "/find.png' border='0' hspace=0 vspace=0 title='Search' /></a>";
        }
        return $output;
    }

    function returnMemberName($member=0) {
    if (empty($member)) {
        $member=0;
    }
    $sql = "SELECT GivenNames, KnownName, Surname
            FROM Members
            WHERE MemberID = ".$member;
    $return = $this->odbcQuery($sql);
    $return = $this->dbFetchArray($return);
    //print_r($return)."<br />";
    $output="";
    if (!empty($return)) {
            if(empty($return['KnownName'])) {$output = $return['GivenNames']." ".$return['Surname'];}
            else {$output = $return['KnownName']." ".$return['Surname'];}
    }
    return $output;
   }

    function returnDaysMember($member) {
    if ($member==0) {
      return "";
    }
    $sql = "SELECT datediff(day, AdmissionDate, getdate()) FROM Members WHERE MemberID = ".$member;
    $return = $this->odbcQuery($sql);
    $return = $this->dbFetchArray($return);
    if (!empty($return)) {
        foreach($return as $ret) {
         return ($ret);
        }
    }
   }

    function returnSubsLevel($member) {
        if ($member==0) {
            return "";
        }
        $sql = "SELECT ChargeScale FROM Members WHERE MemberID = ".$member;
        $return = $this->odbcQuery($sql);
        $return = $this->dbFetchArray($return);
        if (!empty($return)) {
             foreach($return as $ret) {
                return ($ret);
             }
        }
   }

    function returnContactInfo($member) {
    if ($member==0) {
      return array();
    }
    $results=array();
    $return = $this->dbFetchArray($this->odbcQuery("SELECT WorkPhone as work_phone, HomePhone as home_phone, EmailAddress as email, 
            Mobile as attrib_6, StreetAddress as mail_addr_1
            FROM Members
            WHERE MemberID = $member"));
    if (!empty($return)) {
     $results=$return;
    }
    return $results;
   }

    function returnMemberNameWithPE($member) {
        $sql = "SELECT KnowName + ' ' + Surname + ' ('+Employers.EmployerGroup+')' FROM Members, Employers WHERE Members.Employer=Employers.EmployerID AND MemberID = ".$member;
        $return = $this->odbcQuery($sql);
        $return = $this->dbFetchArray($return);
        //print_r($return)."<br />";
        $output="";
        if (!empty($return)) {
            foreach ($return as $ret) {
                $output=$ret;
            }
        }
        return $ret;
   }

    function getMemberPayingEmp($member) {
           $get_details = $this->odbcQuery("SELECT Employer FROM Members WHERE MemberID = $member");
        $get_details = $this->odbcFetchArray($get_details);
        return $get_details['Employer'];
   }

    function getPayingEmpCatCode($paying_emp) {
           $get_details = $this->dbQuery("SELECT category_id
                                       FROM ".$this->returnDBPrefix()."list_category
                                       WHERE category_name = ?",
                                       array($paying_emp));
        $get_details = $this->dbFetchArray($get_details);
        return $get_details['category_id'];
   }

    function getPayingEmpCatCodeTas($paying_emp) {
           $get_details = $this->dbQuery("SELECT category_id
                                       FROM ".$this->returnDBPrefix()."list_category
                                       WHERE category_descrip = ?",
                                       array($paying_emp));
        $get_details = $this->dbFetchArray($get_details);
        //print "\n\n<!-- paying_emp: $paying_emp -->\n";
        return $get_details['category_descrip'];
   }

    function GetMemberDetails($member=0) {
        global $must;
        if(empty($member)) {$member=0;}
        $flyspray_prefs = $this->GetGlobalPrefs;
        $lang = $flyspray_prefs['lang_code'];
        if(!$must) {
            $get_details=$this->dbQuery("SELECT name FROM ".$this->returnDBPrefix()."tasks
                                         WHERE member = ?",
                                         array($member));
            $get_details = $this->dbFetchArray($get_details);
            if(empty($get_details)) {
                $get_details=array();
            } else {
                list($given_names, $surname)=split(" ", $get_details[0]['name']);
                $get_details[0]['surname']=$surname;
                $get_details[0]['given_names']=$given_names;
                $get_details[0]['email']="";
            }
            return $get_details;
        }
        $get_details = $this->odbcQuery("SELECT Members.Surname as surname, Members.GivenNames as given_names,
                                                Members.KnownName as pref_name, Members.Title as title,
                                                Members.eMailAddress as email, Members.DateOfBirth as birth,
                                                Members.Sex as gender, Members.StreetAddress as home_addr_1,
                                                Members.StreetAddress2 as home_addr_2, Members.Suburb as home_addr_3,
                                                Members.HomePhone as home_phone, Members.WorkPhone as work_phone,
                                                Members.WorkFax as fax, Members.Department as actual_emp,
                                                Employers.EmployerGroup as paying_emp,
                                                EmployerGroups.Description as emp_descrip, Employers.PostalAddress as work_addr_1,
                                                Employers.PostalAddress2 as work_addr_2, '' as work_addr_3,
                                                Employers.Suburb as work_addr_4, Members.MemberID as member,
                                                Members.Mobile as attrib_6, Members.FinancialToDate as subs_paid_to,
                                                Members.Award as award, Awards.Description as award_descrip,
                                                Awards.AwardDocument as url, Members.StreetAddress as mail_addr_1
                                                  FROM Members, Employers,
                                                       EmployerGroups, Awards
                                                  WHERE Members.Employer=Employers.EmployerID
                                                  AND Employers.EmployerGroup=EmployerGroups.Code
                                                  AND Members.Award*=Awards.code
                                                  AND Members.MemberID=$member");
        $get_details = $this->odbcFetchArray($get_details);
        if (empty($get_details)) {
            $get_details = array();
        }
        return $get_details;
    }

    function getCommitteeInfo($member) {
      
        /* $details=$this->odbcQuery("SELECT * FROM committees, committee_mems
                                                           WHERE committees.committee=committee_mems.committee
                                                           AND member = $member
                                                             ORDER BY committee_descrip",
                                                           array());
        */
      $output=array();
      /* while ($row = $this->odbcFetchArray($details)) {
          $output[]=$row;
        }*/
        return $output;
    }

    function getCorroDetails($member) {
        /*
        $get_details = $this->odbcQuery("SELECT *
                                       FROM corro
                                       WHERE file_number = ?
                                       ORDER BY date_received DESC", array($member));
                                       */
        $output=array();
        /*
        while ($row = $this->odbcFetchArray($get_details)) {
            $output[]=$row;
        }
        */
        return $output;
    }

    /**
    * Search Members Returns an array containing detailed member
    * information from the ODBC database as per the conditions in the $where variable
    * 
    * Note that because the $where expects database specific select statements this
    * is usually called from within the external DB script
    * 
    * @param mixed $wheres - an array containing additional "WHERE" statements such as:
    *     "surname LIKE '%CLEELAND%'"
    */
    function SearchMembers($wheres) {
        $sql = "SELECT Members.Surname as surname, Members.GivenNames as given_names,
                Members.KnownName as pref_name, Members.Title as title,
                Members.EmailAddress as email, Members.DateOfBirth as birth,
                Members.Sex as gender, Members.StreetAddress as home_addr_1,
                Members.StreetAddress2 as home_addr_2, Members.Suburb as home_addr_3,
                Members.HomePhone as home_phone, Members.WorkPhone as work_phone,
                Members.WorkFax as fax, Members.Employer as actual_emp,
                EmployerGroups.Code as paying_emp, Members.Class as class,
                Members.AdmissionDate as joined, Members.ExitDate as resignation,
                Members.Employer as workplace, Members.StartEmploymentDate as employed,
                EmployerGroups.Description as emp_descrip, Employers.StreetAddress as work_addr_1,
                Employers.StreetAddress2 as work_addr_2, '' as work_addr_3,
                Employers.Suburb as work_addr_4, Members.MemberID as member,
                '' as attrib_3, '' as attrib_4,
                Members.Mobile as attrib_6, Members.FinancialToDate as subs_paid_to,
                Members.Award as award, Awards.Description as award_descrip,
                Members.Employer as emp_descrip,
                Classes.Description as class_descrip,
                Members.Status as emp_type,
                Awards.AwardDocument as url,
                'Class level (TODO)' as class_level,
                Members.ChargeScale as mem_type, Members.StreetAddress as mail_addr_1
                  FROM Members,
                       Employers,
                       EmployerGroups,
                       Awards,
                       Classes
                  WHERE Members.Employer=Employers.EmployerID
                  AND Employers.EmployerGroup=EmployerGroups.Code
                  AND Members.Award *= Awards.Code
                  AND Members.Class=Classes.Code
                  AND ".$wheres."
                  ORDER BY Members.Surname";
        //echo $sql;
        //echo "<!-- $sql -->";
        $get_details = $this->odbcQuery($sql);
                while ($row = $this->dbFetchArray($get_details)) {
                    $output[]=$row;
                }
                if (empty($get_details)) {
                    $get_details = array();
                }
        return $output;
    }

    /**
    * This function returns a list of member numbers to be used searching the internal
    * database. It matches to a name or member number search from the main filter
    * 
    * @param mixed $search - string
    */
    function findMemberNumbers($search) {
        if (is_numeric($search)) {
            //Search is by member number only
            $output[]=$search;
        } else {
            //Search by name
            $search=strtoupper($search);
            $search=str_replace("\'", "%", $search);
            if(strpos(' ', $search)) {$nospaces=str_replace(" ", "%", $search);} else {$nospaces='';}

            $sql = "SELECT Members.MemberID FROM Members WHERE Members.Surname LIKE '%".$search."%' OR Members.GivenNames LIKE '%".$search."%' OR Members.KnownName LIKE '%".$search."%' OR Members.GivenNames +' '+Members.Surname LIKE '$nospaces'";
            $numbers=$this->odbcQuery($sql);
            while ($row = $this->dbFetchArray($numbers)) {
                $output[]=$row['member'];
            }
        }
        if (empty($output)) {
            $output=array("99999999999");
        }
        return $output;
    }

    function getPayingEmps() {
        $get_details = $this->odbcQuery("SELECT Code as employer, Description as emp_descrip FROM EmployerGroups
                        WHERE 1=1
                        ORDER BY Description");
//        print_r($get_details);
        while ($row = $this->odbcFetchArray($get_details)) {
            $output[]=$row;
        }
//        $get_details = $this->odbcFetchArray($get_details);
        if (empty($get_details)) {
            $get_details = array();
        }
        return $output;
    }

    function getWorkplaces($array=array()) {
      $inlist = count($array)>0 ? "AND Members.EmployerID IN ('".implode("', '", $array)."')" : null;
      $get_details = $this->odbcQuery("SELECT count(MemberID) as total, Employers.EmployerID as workplace, 
                                       Employers.StreetAddress as work_addr_1, Employers.StreetAddress2 as work_addr_2, 
                                       '' as work_addr_3, Employers.Suburb as work_addr_4
                                                                       FROM Members, Employers
                                                                       WHERE Members.Employer=Employers.EmployerID
                                                                         $inlist
                                                                       GROUP BY Employers.EmployerID");
      $output=array();
      while($row=$this->dbFetchArray($get_details)) {
          $output[]=array('workplace'=>$row['workplace'], 'name'=>$row['work_addr_1']." ".$row['work_addr_2'], 'count'=>$row['total']);
        }
        return $output;
    }

    function getActualEmps() {
        $get_details = $this->odbcQuery("SELECT Code as employer, Description as emp_descrip FROM EmployerGroups
                        WHERE 1=1
                        ORDER BY Description");
//        print_r($get_details);
        while ($row = $this->dbFetchArray($get_details)) {
            $output[]=$row;
        }
//        $get_details = $this->odbcFetchArray($get_details);
        if (empty($get_details)) {
            $get_details = array();
        }
        return $output;
    }
    
    function getReps($workplace="%", $exclude=array()) {
        //TODO: Complete the getReps function    
        
            /* $repcount=$this->odbcQuery("SELECT * FROM workplace_reps WHERE workplace = ? AND rep_type != ?", array($workplace, 'FAX'));
            $repcount=$this->dbCountRows($repcount); 
            */
            $repcount=0;            
            return $repcount;
    }

    function getContacts($workplace, $excludes=array()) {
        /*
          $get_contacts = $this->odbcQuery("SELECT workplace_reps.*, work_phone, fax, email, surname, pref_name, rep_type_descrip
                               FROM workplace_reps, members, rep_types
                               WHERE members.member=workplace_reps.member
                             AND workplace_reps.rep_type=rep_types.rep_type
                             AND workplace_reps.workplace = ?
                             AND workplace_reps.rep_type != ?
                             ORDER BY workplace_reps.rep_type desc",
                             array($workplace, 'FAX'));
          */
          $contacts=array();
          /*
          while($row=$fs->odbcFetchArray($get_contacts)){
            $contacts[]=$row;
          } // while
          */
          return $contacts;
    }
    
    function getFileDetails($member) {
        global $conf_array;
        /* $flyspray_prefs = $this->GetGlobalPrefs;
        $lang = $flyspray_prefs['lang_code'];
        $get_details = $this->odbcQuery("SELECT *
                                           FROM ".$conf_array['must']['mustfilestable']."
                                           WHERE file_number = '$member'");
        $get_details = $this->odbcFetchArray($get_details);
        */
        if (empty($get_details)) {
            $get_details = array();
        }
        return $get_details;

    }
    
    /* Name conversions for this database */
    function member_search_query_converter($query) {
        $searchfields=array("member"=>"MemberId", 
                            "surname"=>"Surname", 
                            "given_names"=>"GivenNames", 
                            "paying_emp"=>"Employer", 
                            "actual_emp"=>"Department", 
                            "workplace"=>"Employer", 
                            "classification"=>"Class", 
                            "email"=>"EmailAddress");

        $output=array();
        
        foreach($query as $key=>$value) {
            if($searchfields[$key]) {
                $output[$searchfields[$key]]=$value;
            } else {
                $output[$key]=$value;
            }
        }
        return ($output);
    }
    
    function getMustTranslations() {
        return array("member"=>"MemberId", 
                            "surname"=>"Surname", 
                            "given_names"=>"GivenNames", 
                            "paying_emp"=>"Employer", 
                            "actual_emp"=>"Department", 
                            "workplace"=>"Employer", 
                            "classification"=>"Class",
                            "class"=>"Class", 
                            "email"=>"EmailAddress");        
    }
    
    function paying_emp_search($text) {
        $searchterm="%".strtoupper($text)."%";
        $result = $this->odbcQuery("SELECT code=Code, value=Description
                                  FROM EmployerGroups
                                  WHERE (Code LIKE ?
                                  OR Description LIKE ?)
                                  ORDER BY Description",
                                  array($searchterm, $searchterm));
        while($row=$this->odbcFetchArray($result)) {
            $results[]=$row;
        }
        return $results;        
    }
    function actual_emp_search($text) {
        $searchterm="%".strtoupper($text)."%";
        $result = $this->odbcQuery("SELECT code=EmployerID, value=EmployerName FROM Employers
                                  WHERE (EmployerID LIKE ?
                                  OR EmployerName LIKE ?)
                                  ORDER BY EmployerName",
                                  array($searchterm, $searchterm));
        while($row=$this->odbcFetchArray($result)) {
            $results[]=$row;
        }
        return $results;        
    }
    function workplace_search($text) {
        $searchterm="%".strtoupper($text)."%";
        $result = $this->odbcQuery("SELECT code=EmployerID, value=EmployerName+' '+PostalAddress+' '+PostalAddress2+' '+Suburb
                                  FROM Employers
                                  WHERE (EmployerID LIKE ?
                                  OR PostalAddress+PostalAddress2+Suburb LIKE ?)
                                  ORDER BY EmployerName",
                                  array($searchterm, $searchterm));
        while($row=$this->odbcFetchArray($result)) {
            $results[]=$row;
        }
        return $results;
    }
    function classification_search($text) {
        $searchterm="%".strtoupper($text)."%";
        $result = $this->odbcQuery("SELECT code=Code, value=Description
                                  FROM Classes
                                  WHERE (Code LIKE ?
                                  OR Description LIKE ?)
                                  ORDER BY Description",
                                  array($searchterm, $searchterm));
        while($row=$this->odbcFetchArray($result)) {
            $results[]=$row;
        }
        return $results;
    }

    /**
    * Function getUFMembers returns an array of members who are unfinancial
    * 
    * @param mixed $members A list of members (as an array) to check
    */
    function getUFMembers($members) {
    
        //First, split the array into a series of arrays less than 150 members in size
        
        //Extra large quantities of members will break the SQL query here, so let's do it in two lots if there are more than 200
        for($i=0; $i<=(count($members)-1); $i++) {
            if($i < 150) {
                $members1[]=$members[$i];
            } elseif($i > 149 && $i<300) {
                $members2[]=$members[$i];
            } else {
                $members3[]=$members[$i];
            }
        }
        
        $memberin1=implode(", ", $members1);
        if($members2) {$memberin2=implode(", ", $members2);}
        if($members3) {$memberin3=implode(", ", $members3);}

        //Create an array ($ufmembers) of members who are not financial
        $mustsql="SELECT Members.MemberID FROM Members WHERE 1=1 ".$conf_array['must']['financialsql']." AND Members.memberID IN (".$memberin1.")";

        $mresult=$this->odbcQuery($mustsql);
        $ufmembers=array();
        while ($row=$this->dbFetchArray($mresult)) {
            $ufmembers[]=$row['MemberID'];
        }

        if($memberin2) {
            $mustsql="SELECT Members.MemberID FROM Members WHERE 1=1 ".$conf_array['must']['financialsql']." AND Members.memberID IN (".$memberin2.")";

            $mresult=$this->odbcQuery($mustsql);
            $ufmembers=array();
            while ($row=$this->dbFetchArray($mresult)) {
                $ufmembers[]=$row['MemberID'];
            }
        }        

        if($memberin3) {
            $mustsql="SELECT Members.MemberID FROM Members WHERE 1=1 ".$conf_array['must']['financialsql']." AND Members.memberID IN (".$memberin3.")";

            $mresult=$this->odbcQuery($mustsql);
            $ufmembers=array();
            while ($row=$this->dbFetchArray($mresult)) {
                $ufmembers[]=$row['MemberID'];
            }
        }        
        
        return $ufmembers; 
    }

}  
?>
