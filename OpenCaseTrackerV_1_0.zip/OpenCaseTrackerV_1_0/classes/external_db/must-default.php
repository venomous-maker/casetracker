<?php
/**
* Class CaseTracker extends the base class fucntionality with EXTERNAL database
* specific functions
* 
*/
class CaseTracker extends OCT {

    /**
    * Open connection to the database, in this case a standard ODBC connection.
    * On linux servers this requires openodbc or similar, and a dsn connection
    * 
    * @param mixed $mustodbcdsn The name DSN connection (from casetracker.conf.php)
    * @param mixed $mustdbuser The database username
    * @param mixed $mustdbpass The database password
    */
    function odbcOpen($mustodbcdsn = '', $mustdbuser='', $mustdbpass='') {
       @$this->must2->dbtype = "sybase";
       $this->must2->dblink = NewADOConnection('odbc');
       $must2 = $this->must2->dblink->Connect($mustodbcdsn, $mustdbuser, $mustdbpass);
       $this->must2->dblink->SetFetchMode(ADODB_FETCH_BOTH);
       return $must2;
    }

    /**
    * Close the odbc database link
    * 
    */
    function odbcClose() {
      $this->must2->dblink->Close();
    }
   
    /**
    * Perform a SQL command on the odbc connection
    * 
    * @param mixed $sql The SQL command to perform
    * @param mixed $inputarr Any input values in an array format
    * @param mixed $numrows The number of rows to return (-1 = unlimited)
    * @param mixed $offset Which record to start at
    */
    function odbcExec($sql, $inputarr=false, $numrows=-1, $offset=-1) {

      $inputarr = $this->dbUndefToEmpty($inputarr); //Replace any undefined values (which should be treated as a null in SQL databases) with an empty string

      $ADODB_FETCH_MODE = ADODB_FETCH_ASSOC;
      if (($numrows>=0) or ($offset>=0)) {
          @$result =  $this->must2->dblink->SelectLimit($sql, $numrows, $offset, $inputarr);
      } else {
          @$result =  $this->must2->dblink->Execute($sql, $inputarr);
      }

      if (!$result) {
          if (function_exists("debug_backtrace")) {
              echo "<pre style='text-align: left;'>";
              var_dump(debug_backtrace());
              echo "</pre>";
          }

          die (sprintf("Query {%s} with params {%s} Failed! (%s)",
                    $sql, implode(', ', $inputarr),
                    $this->must2->dblink->ErrorMsg()));
      }
      return $result;
    }

    /**
    * Perform a query on the odbc connection (this is the function to use)
    * 
    * @param mixed $sql
    * @param mixed $inputarr
    * @param mixed $numrows
    * @param mixed $offset
    */
    function odbcQuery($sql, $inputarr=false, $numrows=-1, $offset=-1) {
      $result = $this->odbcExec($sql, $inputarr, $numrows, $offset);
      return $result;
    }

    function odbcFetchArray(&$result) {
      $row = $this->dbFetchRow($result);
      return $row;
    }

    /**
    * ReturnSmiley returns a smiley face based on the financiality of the member
    * 
    * @param mixed $member - the unique id of the member
    * @param mixed $tags - HTML tags to include in the output
    * @param mixed $popup - Extra text to include in the html popup message
    * @return mixed
    */
    function returnSmiley($member, $tags="", $popup="") {
       $flyspray_prefs = $this->GetGlobalPrefs();
       if ($member == 0) {
           return "";
       }

       $spd=$this->GetPaidTo($member);
       list($pfr, $pmt)=$this->GetPaymentInfo($member);
       $time=time();
       $offset=16; //How many days leeway to give before the smiley indicates they are behind.
                   //A value of 16, for example, will mean that the embarrassed face only starts showing up when the member is over 16 days in arrears
       $subs_paid_to=$spd ? intval(((((($spd)-time())/60/60/24)-(26-$offset))/30)+0) : 0;
       $spd_date=date("d M Y", $spd);
       $explanation = "This member is paying by $pmt, and payments are made $pfr. Subscriptions are currently paid up until $spd_date";
       $pay_method=$this->GetPayMethod($member);
       if ($this->GetLegitMemberNumber($member) && $pay_method != "P") {
          switch($subs_paid_to) {
             case -3:
               $output = "<img $tags src='themes/".$flyspray_prefs['theme_style']."/mortified.png' border='0' title='This member is financial but between two and three months in arrears! ($explanation)'";
               break;
             case -2:
               $output = "<img $tags src='themes/".$flyspray_prefs['theme_style']."/ashamed.png' border='0' title='This member is financial but between one and two months in arrears! ($explanation)'";
               break;
             case -1:
               $output = "<img $tags src='themes/".$flyspray_prefs['theme_style']."/embarrassed.png' border='0' title='This member is financial but up to one month in arrears! ($explanation)'";
               break;
             default:
               $output = "<img $tags src='themes/".$flyspray_prefs['theme_style']."/happy.png' border='0' title='This member is Fully financial $popup ($explanation)'";
               break;
          }
          if ($popup != "") {
              $output .=" onClick='alert(\"This member is FINANCIAL $popup\")'";
          }
          $output .= ">";
          return $output;
       } elseif ($this->GetLegitMemberNumber($member) && $pay_method == "P") {
          $output = "<img $tags src='themes/".$flyspray_prefs['theme_style']."/happy.png' border='0' title='This member is Fully financial $popup'";
          if ($popup != "") {
              $output .=" onClick='alert(\"This member is FINANCIAL $popup\")'";
          }
          $output .= ">";
          return $output;

       } else {
             $output ="<img $tags src='themes/".$flyspray_prefs['theme_style']."/sad.png' border='0' title='This member is Unfinancial!'";
          if ($popup != "") {
              $output .= "return  onClick='alert(\"This member is UNFINANCIAL $popup\")'";
          }
          $output .= ">";
          return $output;
       }
   }

    function GetLegitMemberNumber($member) {
        //Gets Legitimate Financial Member Numbers
        global $conf_array;
        $flyspray_prefs = $this->GetGlobalPrefs();
        $lang = $flyspray_prefs['lang_code'];
        $get_details = $this->odbcQuery("SELECT members.member
                                                  FROM members, employers
                                                  WHERE members.paying_emp=employers.employer
                                                  ".$conf_array['must']['financialsql']."
                                                  AND members.member = $member
                                                  ORDER BY member");
        $get_details = $this->odbcFetchArray($get_details);
        if (empty($get_details)) {
            return FALSE;
        }

        return TRUE;
    }

    function GetPaidTo($member) {
      //Gets "paid_to" date for member
      $flyspray_prefs = $this->GetGlobalPrefs();
      $updatecache=false;
      $get_details = $this->dbQuery("SELECT subs_paid_to, modified FROM ".$this->returnDBPrefix()."member_cache WHERE member=?", array(intval($member)));
      $get_details = $this->dbFetchRow($get_details);
      $mymodified=$get_details['modified'];
      if(!isset($get_details['modified']) || $get_details['modified'] <= time()-(60*60*24)) {
          $get_details = $this->odbcQuery("SELECT subs_paid_to, surname, pref_name, joined, paying_emp, given_names FROM mem_subs_control, members WHERE members.member=mem_subs_control.member AND members.member=?", array(intval($member)));
          $get_details = $this->dbFetchRow($get_details);
          if(!$mymodified) {
              $insertcache=true;
          } else {
              $updatecache=true;
          }
      }
      if(empty($get_details['subs_paid_to'])) {$get_details['subs_paid_to']="1980-01-01 12:00:00";}
      if(empty($get_details['pref_name'])) {$get_details['pref_name']=$get_details['given_names'];}
      list($jdate, $jtime) = explode(" ", $get_details['subs_paid_to']);
      list($year, $month, $day)=explode("-",$jdate);
      if($updatecache) {
        $updatenow = $this->dbQuery("UPDATE ".$this->returnDBPrefix()."member_cache SET subs_paid_to=?, modified=? WHERE member=?", array("$year-$month-$day", time(), intval($member)));
      }
        if($insertcache) {
            $this->dbQuery("INSERT INTO ".$this->returnDBPrefix()."member_cache (member, subs_paid_to, paying_emp, joined, surname, pref_name, modified)
                             VALUES (".intval($member).", '$year-$month-$day', '".$get_details['paying_emp']."', '".substr($get_details['joined'],20)."', '".mysql_real_escape_string($get_details['surname'])."', '".$get_details['pref_name']."', ".time().")");
        }
        return mktime(0, 0, 0, $month, $day, $year);
    }

    function GetPayMethod($member) {
      $flyspray_prefs = $this->GetGlobalPrefs();
      $get_details = $this->odbcQuery("SELECT pay_method FROM mem_subs_control WHERE member=?", array(intval($member)));
      $get_details = $this->dbFetchRow($get_details);
      return $get_details['pay_method'];
    }

    function GetPaymentInfo($member) {
      $flyspray_prefs=$this->GetGlobalPrefs();
      $get_details = $this->odbcQuery("SELECT pay_frequency_descrip, pay_method_descrip
                                       FROM mem_subs_control, pay_frequencies, pay_methods
                                       WHERE mem_subs_control.pay_frequency=pay_frequencies.pay_frequency
                                       AND mem_subs_control.pay_method=pay_methods.pay_method
                                       AND member = ?", array(intval($member)));
      $get_details = $this->dbFetchRow($get_details);
      return array($get_details['pay_frequency_descrip'], $get_details['pay_method_descrip']);
    }

    function highlightMemberNumberByEmpType($member, $emp_type) {
        if ($emp_type == "C" || $emp_type == "X") {
            return "<font color='green'>$member</font>";
        } else {
            return "<font color='red'>$member</font>";
        }
    }

    function returnMemberNumber($member, $searchbutton=TRUE) {
        global $project_prefs, $flyspray_prefs;
        if ($member == 0) {
            $number = "N/A";
        } else {
            $number = $member;
        }
        if ($this->GetLegitMemberNumber($member)) {
            $output="<font color='green'>$number</font>";
        } else {
            $output="<font color='red'>$number</font>";
        }
        if ($search) {
            $output.= "&nbsp;<a href='' onClick='window.open(\"index.php?do=member_search&member=$number\", \"_blank\", \"toolbar=no, scrollbars=yes, width=610, height=450\")'><img src='themes/" . $project_prefs['theme_style'] . "/find.png' border='0' hspace=0 vspace=0 title='Search' /></a>";
        }
        return $output;
    }

    function returnMemberName($member=0) {
    if (empty($member)) {
        $member=0;
    }
    $sql = "SELECT given_names, pref_name, surname
            FROM members
            WHERE member = ".$member;
    $return = $this->odbcQuery($sql);
    $return = $this->dbFetchArray($return);
    //print_r($return)."<br />";
    $output="";
    if (!empty($return)) {
            if(empty($return['pref_name'])) {$output = $return['given_names']." ".$return['surname'];}
            else {$output = $return['pref_name']." ".$return['surname'];}
    }
    return $output;
   }

    function returnDaysMember($member) {
    if ($member==0) {
      return "";
    }
    $sql = "SELECT datediff(day, joined, getdate()) FROM members WHERE member = ".$member;
    $return = $this->odbcQuery($sql);
    $return = $this->dbFetchArray($return);
    if (!empty($return)) {
        foreach($return as $ret) {
         return ($ret);
        }
    }
   }

    function returnSubsLevel($member) {
        if ($member==0) {
            return "";
        }
        $sql = "SELECT mem_type FROM mem_subs_control WHERE member = ".$member;
        $return = $this->odbcQuery($sql);
        $return = $this->dbFetchArray($return);
        if (!empty($return)) {
             foreach($return as $ret) {
                return ($ret);
             }
        }
   }

    function returnContactInfo($member) {
    if ($member==0) {
      return array();
    }
    $results=array();
    $return = $this->dbFetchArray($this->odbcQuery("SELECT work_phone, home_phone, email, attrib_6, mail_addr_1
            FROM members, mem_attributes
            WHERE members.member *= mem_attributes.member
            AND members.member = $member"));
    if (!empty($return)) {
     $results=$return;
    }
    return $results;
   }

    function returnMemberNameWithPE($member) {
    $sql = "SELECT pref_name + ' ' + surname + ' ('+paying_emp+')' FROM members WHERE member = ".$member;
    $return = $this->odbcQuery($sql);
    $return = $this->dbFetchArray($return);
    //print_r($return)."<br />";
    $output="";
    if (!empty($return)) {
        foreach ($return as $ret) {
            $output=$ret;
        }
    }
    return $ret;
   }

    function getMemberPayingEmp($member) {
           $get_details = $this->odbcQuery("SELECT paying_emp FROM members WHERE member = $member");
        $get_details = $this->odbcFetchArray($get_details);
        return $get_details['paying_emp'];
   }

    function getPayingEmpCatCode($paying_emp) {
           $get_details = $this->dbQuery("SELECT category_id
                                       FROM ".$this->returnDBPrefix()."list_category
                                       WHERE category_name = ?",
                                       array($paying_emp));
        $get_details = $this->dbFetchArray($get_details);
        return $get_details['category_id'];
   }

    function getPayingEmpCatCodeTas($paying_emp) {
           $get_details = $this->dbQuery("SELECT category_id
                                       FROM ".$this->returnDBPrefix()."list_category
                                       WHERE category_descrip = ?",
                                       array($paying_emp));
        $get_details = $this->dbFetchArray($get_details);
        //print "\n\n<!-- paying_emp: $paying_emp -->\n";
        return $get_details['category_descrip'];
   }

    function GetMemberDetails($member=0) {
        global $must;
        if(empty($member)) {$member=0;}
        $flyspray_prefs = $this->GetGlobalPrefs;
        $lang = $flyspray_prefs['lang_code'];
        if(!$must) {
            $get_details=$this->dbQuery("SELECT name FROM ".$this->returnDBPrefix()."tasks
                                         WHERE member = ?",
                                         array($member));
            $get_details = $this->dbFetchArray($get_details);
            if(empty($get_details)) {
                $get_details=array();
            } else {
                list($given_names, $surname)=split(" ", $get_details[0]['name']);
                $get_details[0]['surname']=$surname;
                $get_details[0]['given_names']=$given_names;
                $get_details[0]['email']="";
            }
            return $get_details;
        }
        $get_details = $this->odbcQuery("SELECT members.surname, members.given_names,
                                                members.pref_name, members.title,
                                                members.email, members.birth,
                                                members.gender, members.home_addr_1,
                                                members.home_addr_2, members.home_addr_3,
                                                members.home_phone, members.work_phone,
                                                members.fax, members.actual_emp,
                                                members.paying_emp,
                                                employers.emp_descrip, workplaces.work_addr_1,
                                                workplaces.work_addr_2, workplaces.work_addr_3,
                                                workplaces.work_addr_4, members.member,
                                                mem_attributes.attrib_6, mem_subs_control.subs_paid_to,
                                                awards.award, awards.award_descrip,
                                                award_details.url, members.mail_addr_1
                                                  FROM members, employers, workplaces,
                                                       mem_attributes, mem_subs_control, awards,
                                                       award_details
                                                  WHERE members.member *= mem_attributes.member
                                                  AND members.paying_emp=employers.employer
                                                  AND members.workplace=workplaces.workplace
                                                  AND members.member=mem_subs_control.member
                                                  AND members.award=awards.award
                                                  AND awards.award *= award_details.award
                                                  AND members.member=$member");
        $get_details = $this->odbcFetchArray($get_details);
        if (empty($get_details)) {
            $get_details = array();
        }
        return $get_details;
    }

    function getCommitteeInfo($member) {
      $details=$this->odbcQuery("SELECT * FROM committees, committee_mems
                                                           WHERE committees.committee=committee_mems.committee
                                                           AND member = $member
                                                             ORDER BY committee_descrip",
                                                           array());
      $output=array();
      while ($row = $this->odbcFetchArray($details)) {
          $output[]=$row;
        }
        return $output;
    }

    function getCorroDetails($member) {
        $get_details = $this->odbcQuery("SELECT *
                                       FROM corro
                                       WHERE file_number = ?
                                       ORDER BY date_received DESC", array($member));
        $output=array();
        while ($row = $this->odbcFetchArray($get_details)) {
            $output[]=$row;
        }
        return $output;
    }

    /**
    * Search Members Returns an array containing detailed member
    * information from the ODBC database as per the conditions in the $where variable
    * 
    * Note that because the $where expects database specific select statements this
    * is usually called from within the external DB script
    * 
    * @param mixed $wheres - an array containing additional "WHERE" statements such as:
    *     "surname LIKE '%CLEELAND%'"
    */
    function SearchMembers($wheres) {
        $sql = "SELECT members.surname, members.given_names,
                members.pref_name, members.title,
                members.email, members.birth,
                members.gender, members.home_addr_1,
                members.home_addr_2, members.home_addr_3,
                members.home_phone, members.work_phone,
                members.fax, members.actual_emp,
                members.paying_emp, members.class,
                members.joined, members.resignation,
                members.workplace, members.employed,
                b.emp_descrip, workplaces.work_addr_1,
                workplaces.work_addr_2, workplaces.work_addr_3,
                workplaces.work_addr_4, members.member,
                mem_attributes.attrib_3, mem_attributes.attrib_4,
                mem_attributes.attrib_6, mem_subs_control.subs_paid_to,
                awards.award, awards.award_descrip,
                actual_emp_descrip = a.emp_descrip,
                classes.class_descrip,
                b.emp_type,
                award_details.url,
                members.class_level,
                mem_type, members.mail_addr_1
                  FROM members,
                       employers a,
                       employers b,
                       workplaces,
                       mem_attributes,
                       mem_subs_control,
                       awards,
                       award_details,
                       classes
                  WHERE members.member *= mem_attributes.member
                  AND members.paying_emp=b.employer
                  AND members.actual_emp=a.employer
                  AND members.workplace=workplaces.workplace
                  AND members.member=mem_subs_control.member
                  AND members.award=awards.award
                  AND members.class=classes.class
                  AND awards.award *= award_details.award
                  AND ".$wheres."
                  ORDER BY surname";
//        echo $sql;
        echo "<!-- $sql -->";
        $get_details = $this->odbcQuery($sql);
                while ($row = $this->dbFetchArray($get_details)) {
                    $output[]=$row;
                }
                if (empty($get_details)) {
                    $get_details = array();
                }
        return $output;
    }

    /**
    * This function returns a list of member numbers to be used searching the internal
    * database. It matches to a name or member number search from the main filter
    * 
    * @param mixed $search - string
    */
    function findMemberNumbers($search) {
        if (is_numeric($search)) {
            //Search is by member number only
            $output[]=$search;
        } else {
            //Search by name
            $search=strtoupper($search);
            $search=str_replace("\'", "%", $search);
            if(strpos(' ', $search)) {$nospaces=str_replace(" ", "%", $search);} else {$nospaces='';}

            $sql = "SELECT member FROM members WHERE surname LIKE '%".$search."%' OR given_names LIKE '%".$search."%' OR pref_name LIKE '%".$search."%' OR given_names+' '+surname LIKE '$nospaces'";
            $numbers=$this->odbcQuery($sql);
            while ($row = $this->dbFetchArray($numbers)) {
                $output[]=$row['member'];
            }
        }
        if (empty($output)) {
            $output=array("99999999999");
        }
        return $output;
    }

    function getPayingEmps() {
        $get_details = $this->odbcQuery("SELECT employer, emp_descrip FROM employers
                        WHERE can_be_paying_emp='Y'
                        AND employer not like 'ZR%'
                        ORDER BY employer");
//        print_r($get_details);
        while ($row = $this->odbcFetchArray($get_details)) {
            $output[]=$row;
        }
//        $get_details = $this->odbcFetchArray($get_details);
        if (empty($get_details)) {
            $get_details = array();
        }
        return $output;
    }

    function getWorkplaces($array=array()) {
      $inlist = count($array)>0 ? "AND workplaces.workplace IN ('".implode("', '", $array)."')" : null;
      $get_details = $this->odbcQuery("SELECT total=count(member), workplaces.workplace, work_addr_1, work_addr_2, work_addr_3, work_addr_4
                                                                       FROM members, workplaces, employers
                                                                       WHERE members.workplace=workplaces.workplace
                                                                       AND members.paying_emp=employers.employer
                                                                       AND emp_type='C'
                                                                         $inlist
                                                                       GROUP BY workplaces.workplace");
      $output=array();
      while($row=$this->dbFetchArray($get_details)) {
          $output[]=array('workplace'=>$row['workplace'], 'name'=>$row['work_addr_1']." ".$row['work_addr_2'], 'count'=>$row['total']);
        }
        return $output;
    }

    function getActualEmps() {
        $get_details = $this->odbcQuery("SELECT employer, emp_descrip FROM employers
                        WHERE employer not like 'ZR%'
                        ORDER BY employer");
//        print_r($get_details);
        while ($row = $this->dbFetchArray($get_details)) {
            $output[]=$row;
        }
//        $get_details = $this->odbcFetchArray($get_details);
        if (empty($get_details)) {
            $get_details = array();
        }
        return $output;
    }
    
    function getReps($workplace="%", $exclude=array()) {
        //TODO: Complete the getReps function    
        
            $repcount=$this->odbcQuery("SELECT * FROM workplace_reps WHERE workplace = ? AND rep_type != ?", array($workplace, 'FAX'));
            $repcount=$this->dbCountRows($repcount); 
                        
            return $repcount;
    }

    function getContacts($workplace, $excludes=array()) {
          $get_contacts = $this->odbcQuery("SELECT workplace_reps.*, work_phone, fax, email, surname, pref_name, rep_type_descrip
                               FROM workplace_reps, members, rep_types
                               WHERE members.member=workplace_reps.member
                             AND workplace_reps.rep_type=rep_types.rep_type
                             AND workplace_reps.workplace = ?
                             AND workplace_reps.rep_type != ?
                             ORDER BY workplace_reps.rep_type desc",
                             array($workplace, 'FAX'));
          $contacts=array();
          while($row=$this->odbcFetchArray($get_contacts)){
            $contacts[]=$row;
          } // while
          return $contacts;
    }
    
    function getFileDetails($member) {
        global $conf_array;
        $flyspray_prefs = $this->GetGlobalPrefs;
        $lang = $flyspray_prefs['lang_code'];
        $get_details = $this->odbcQuery("SELECT *
                                           FROM ".$conf_array['must']['mustfilestable']."
                                           WHERE file_number = '$member'");
        $get_details = $this->odbcFetchArray($get_details);
        if (empty($get_details)) {
            $get_details = array();
        }
        return $get_details;

    }
    
    /* Name conversions for this database */
    function member_search_query_converter($query) {
        $searchfields=array(); //No need to convert anything, this is the original

        $output=array();
        
        foreach($query as $key=>$value) {
            if($searchfields[$key]) {
                $output[$searchfields[$key]]=$value;
            } else {
                $output[$key]=$value;
            }
        }
        
        return ($output);
    }
    
    function getMustTranslations() {
        return array("member"=>"members.member", 
                            "surname"=>"members.surname", 
                            "given_names"=>"members.given_names", 
                            "paying_emp"=>"members.paying_emp", 
                            "actual_emp"=>"members.actual_emp", 
                            "workplace"=>"members.workplace", 
                            "classification"=>"members.classification",
                            "class"=>"members.class", 
                            "email"=>"members.email");        
    }
    function paying_emp_search($text) {
        $searchterm="%".strtoupper($text)."%";
        $result = $this->odbcQuery("SELECT code=employer, value=emp_descrip FROM employers
                                  WHERE (employer LIKE ?
                                  OR emp_descrip LIKE ?)
                                  AND can_be_paying_emp='Y'
                                  ORDER BY emp_descrip",
                                  array($searchterm, $searchterm));
        while($row=$this->odbcFetchArray($result)) {
            $results[]=$row;
        }
        return $results;        
    }
    function actual_emp_search($text) {
        $searchterm="%".strtoupper($text)."%";
        $result = $this->odbcQuery("SELECT code=employer, value=emp_descrip FROM employers
                                  WHERE (employer LIKE ?
                                  OR emp_descrip LIKE ?)
                                  AND can_be_paying_emp='N'
                                  ORDER BY emp_descrip",
                                  array($searchterm, $searchterm));
        while($row=$this->odbcFetchArray($result)) {
            $results[]=$row;
        }
        return $results;        
    }
    function workplace_search($text) {
        $searchterm="%".strtoupper($text)."%";
        $result = $this->odbcQuery("SELECT code=workplace, value=work_addr_1+'<br />'+work_addr_2+'<br />'+work_addr_3+'<br />'+work_addr_4
                                  FROM workplaces
                                  WHERE (workplace LIKE ?
                                  OR work_addr_1+work_addr_2+work_addr_3+work_addr_4 LIKE ?)
                                  ORDER BY work_addr_1",
                                  array($searchterm, $searchterm));
        while($row=$this->odbcFetchArray($result)) {
            $results[]=$row;
        }
        return $results;
    }
    function classification_search($text) {
        $searchterm="%".strtoupper($text)."%";
        $result = $this->odbcQuery("SELECT code=class, value=class_descrip
                                  FROM classes
                                  WHERE (class LIKE ?
                                  OR class_descrip LIKE ?)
                                  ORDER BY class_descrip",
                                  array($searchterm, $searchterm));
        while($row=$this->odbcFetchArray($result)) {
            $results[]=$row;
        }
        return $results;
    }
    
    /**
    * Function getUFMembers returns an array of members who are unfinancial
    * 
    * @param mixed $members A list of members (as an array) to check
    */
    function getUFMembers($members) {
    
        //First, split the array into a series of arrays less than 150 members in size
        
        //Extra large quantities of members will break the SQL query here, so let's do it in two lots if there are more than 200
        for($i=0; $i<=(count($members)-1); $i++) {
            if($i < 150) {
                $members1[]=$members[$i];
            } elseif($i > 149 && $i<300) {
                $members2[]=$members[$i];
            } else {
                $members3[]=$members[$i];
            }
        }
        
        $memberin1=implode(", ", $members1);
        if($members2) {$memberin2=implode(", ", $members2);}
        if($members3) {$memberin3=implode(", ", $members3);}

        //Create an array ($ufmembers) of members who are not financial
        $mustsql="SELECT member FROM members, employers WHERE members.paying_emp=employers.employer AND emp_type != 'C' AND member IN (".$memberin1.")";

        $mresult=$this->odbcQuery($mustsql);
        $ufmembers=array();
        while ($row=$this->dbFetchArray($mresult)) {
            $ufmembers[]=$row['member'];
        }

        if($memberin2) {
            $mustsql="SELECT member FROM members, employers WHERE members.paying_emp=employers.employer AND emp_type != 'C' AND member IN (".$memberin2.")";

            $mresult=$this->odbcQuery($mustsql);
            $ufmembers=array();
            while ($row=$this->dbFetchArray($mresult)) {
                $ufmembers[]=$row['member'];
            }
        }        

        if($memberin3) {
            $mustsql="SELECT member FROM members, employers WHERE members.paying_emp=employers.employer AND emp_type != 'C' AND member IN (".$memberin3.")";

            $mresult=$this->odbcQuery($mustsql);
            $ufmembers=array();
            while ($row=$this->dbFetchArray($mresult)) {
                $ufmembers[]=$row['member'];
            }
        }        
        
        return $ufmembers; 
    }
}  
?>
