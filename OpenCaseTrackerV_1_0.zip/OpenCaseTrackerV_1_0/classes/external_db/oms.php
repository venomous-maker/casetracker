<?php
/**
* Class CaseTracker extends the base class fucntionality with EXTERNAL database
* specific functions
* 
*/
//error_reporting(E_ALL);
require_once($basedir.'/classes/external_db/oms/memberInfo.php');

class CaseTracker extends OCT {
    var $OMSgroupID = "39078f18-dd9d-448f-ac1d-f2387db9a82e"; //Permanently set to internal CPSU ID (modify)
    
    var $UUIDs = array();
    var $peoplecache=array();
    var $isfinancialcache=array();
    var $employmentcache=array();
    var $subscriptioncache=array();
    var $employerscache=array();
    var $employercache;
    var $committeemembershipscache=array();
    var $committeescache;
    var $committeecache=array();
        
    /**
    * Open connection to the database, in this case a standard ODBC connection.
    * On linux servers this requires openodbc or similar, and a dsn connection
    * 
    * @param mixed $mustodbcdsn The name DSN connection (from casetracker.conf.php)
    * @param mixed $mustdbuser The database username
    * @param mixed $mustdbpass The database password
    */
    function odbcOpen($mustodbcdsn = '', $mustdbuser='', $mustdbpass='') {
       //This is not required for OMS
       //We are hacking this function so that it connects, instead to a SOAP interface
       $oms=new memberInfo($mustodbcdsn."?wsdl", array('login'=>$mustdbuser, 
                                                      'password'=>$mustdbpass,
                                                      'location'=>$mustodbcdsn,                        
                                                      'features'=>SOAP_SINGLE_ELEMENT_ARRAYS+SOAP_USE_XSI_ARRAY_TYPE,
                                                      ));
       return $oms;
    }

    /**
    * Close the odbc database link
    * 
    */
    function odbcClose() {
      //Not required with OMS
      //Only required to remain compatible with other external databases
    }

    /**
    * getUUID function takes a member number and returns the OMS person UUID - by querying OMS
    * if necessary, or using the existing cached version if possible
    * 
    * @param mixed $member
    * 
    * @return string containing uuid
    */
    function getUUID($member) {
        global $must;
        if(!isset($this->UUIDs[$member])) {
            $getMembersSoapRequestParameters=new getMembers();
            $getMembersSoapRequestParameters->associationName = $member;
            $getMembersSoapRequestParameters->groupId = $this->OMSgroupID;
            $uuids = $must->getMembers($getMembersSoapRequestParameters)->return;
            $this->UUIDs[$member]=$uuids[0];
        }
        return $this->UUIDs[$member];
    }
    
    /**
    * getPerson returns person info from the cache, or builds it into the cache if needed
    * based on UUID
    * 
    * @param mixed $uuid
    * 
    * @return stdClass containing address object, alias, created, dob, email, firstNames, homePhone, id, lastName, mobilePhone, modified and title
    *        [address]
    *                [administrativeArea] => VIC
    *                [countryCode] => AU
    *                 [created] => 2013-03-12T12:17:10.740+10:30
    *                [formatted] => 81A GRENDA DRIVE, MILL PARK, VIC 3082
    *                [id] => 45206198-edb8-47a0-a6f5-df07402dbc29
    *                [locality] => MILL PARK,
    *                [modified] => 2013-03-12T12:17:10.740+10:30
    *                [postalCode] => 3082
    *                [street] => 
    *                [subAdministrativeArea] => 
    *                [subStreet] => 81A GRENDA DRIVE
    *        [created] => 2013-03-12T12:17:10.748+10:30
    *        [dob] => 1969-02-24T00:00:00+09:30
    *        [email] => rosanna.costanzo@police.vic.gov.au
    *        [firstNames] => ROSANNA
    *        [homePhone] => 9437 7730
    *        [id] => ea664397-eaa9-4352-a3e4-7e63cd5e1089
    *        [lastName] => COSTANZO
    *        [mobilePhone] => 
    *        [modified] => 2013-03-12T12:17:10.748+10:30
    *        [title] => STUB
    */
    function getPerson($uuid) {
        global $must;
        if(empty($uuid)) return "";
        if(!isset($this->peoplecache[$uuid])) {
            $getPersonSoapRequestParamaters=new getPersonInfo();
            $getPersonSoapRequestParamaters->personId=$uuid;
            $this->peoplecache[$uuid]=$must->getPersonInfo($getPersonSoapRequestParamaters)->return;
        } 
        return $this->peoplecache[$uuid];
    }
    
    /**
    * get isFinancial and cache it
    * 
    * @param mixed $uuid
    * 
    * @return boolean
    */
    function getFinancial($uuid) {
        global $must;
        if(empty($uuid)) return false;
        if(!isset($this->isfinancialcache[$uuid])) {
            $isFinancialSoapRequestParameters=new isFinancial();
            $isFinancialSoapRequestParameters->personId=$uuid;
            $isFinancialSoapRequestParameters->groupId=$this->OMSgroupID;
            $this->isfinancialcache[$uuid]=$must->isFinancial($isFinancialSoapRequestParameters)->return;
        }
        return $this->isfinancialcache[$uuid];    
    }
    
    /**
    * getEmployment retrieves the employment contract based on a UUID
    * 
    * @param string $uuid
    * 
    * @return \stdClass holding address, associationId, contractMethod, created, division, email, fax, from, groupId, modified, phone, position and to 
    *       [address] => 
            [associationId] => 22fec48d-efc3-4b12-81a3-a6a7fa14e4f1
            [contractMethod] => 
            [created] => 2013-03-12T13:04:05.159+10:30
            [division] => STUB
            [email] => STUB
            [fax] => STUB
            [from] =>
            [groupId] => UUID for Employer
            [modified] => 2013-03-12T13:04:05.159+10:30
            [phone] => STUB
            [position] => TEAM / GROUP LEADER (PRF54)
            [to] => employment ended
    */
    function getEmployment($uuid) {
        global $must;
        if(empty($uuid)) return null;
        if(!isset($this->employmentcache[$uuid]))  {
            $getEmploymentSoapRequestParamaters=new getEmploymentInfo();
            $getEmploymentSoapRequestParamaters->personId=$uuid;
            $this->employmentcache[$uuid] = $must->getEmploymentInfo($getEmploymentSoapRequestParamaters)->return;
        }
        return $this->employmentcache[$uuid];
    }
    
    /**
    * Return member subscription information
    * 
    * @param mixed $uuid
    * 
    * @returns
    *     associationFrom  dateTime
    *     associationId    string
    *     associationTo    dateTime
    *     created          dateTime
    *     modified         dateTime
    *     paidTo           dateTime
    *     paymentMethod    string
    *     subscriptionFrequency  string
    *     subscriptionMethod     string
    *     totalAccountBalance    string   (4410, as a debit to the association - in otherwords, a positive number equals a debt by the member - 4410 means the member owes the union $44.10)
    */
    function getSubscription($uuid) {
        global $must;
        if(empty($uuid)) return null;
        if(!isset($this->subscriptioncache[$uuid])) {
            $getSubscriptionStatusesSoapRequestParamaters=new getSubscriptionStatuses();
            $getSubscriptionStatusesSoapRequestParamaters->personId=$uuid;
            $getSubscriptionStatusesSoapRequestParamaters->groupId=$this->OMSgroupID;
            $this->subscriptioncache[$uuid] = $must->getSubscriptionStatuses($getSubscriptionStatusesSoapRequestParamaters)->return[0];
        }
        return $this->subscriptioncache[$uuid];        
    }
    
    /**
    * getEmployers returns a list of all employers
    * 
    * @param 
    * 
    * @return     $abbreviatedName  string
    * @return     $created          dateTime
    * @return     $groupId          string
    * @return     $modified         dateTime
    * @return     $name             string
    * @return     $parentGroupId    
    */
    function getEmployers($search="") {
         global $must; 
         if(empty($this->employerscache)) {
             $getEmployersSoapRequestParamaters=new getEmployers();
             $this->employerscache=$must->getEmployers($getEmployersSoapRequestParamaters)->return;
         }
         return $this->employerscache;
    }
    
    /**
    * getEmployer returns a single employer based on their groupId
    * 
    * @param mixed $groupId
    * @return     $abbreviatedName  string
    * @return     $created          dateTime
    * @return     $groupId          string
    * @return     $modified         dateTime
    * @return     $name             string
    * @return     $parentGroupId    
    */
    function getEmployer($groupId) {
         global $must; 
         if(empty($this->employercache)) {
             $getEmployerSoapRequestParamaters=new getEmployer();
             $getEmployerSoapRequestParamaters->groupId=$groupId;
             $this->employercache=$must->getEmployer($getEmployerSoapRequestParamaters)->return;
         }
         return $this->employercache;
    }
    
    /**
    * getCommittees collects a list of committees associated to a UUID (only current)
    * 
    * @param mixed $uuid
    * 
    * @return stdClass containing ...
    */
    function getCommitteeMemberships($uuid) {
         global $must; 
         if(empty($this->committeemembershipscache[$uuid])) {
             $getCommitteeMembershipsSoapRequestParamaters=new getCommitteeMemberships();
             $getCommitteeMembershipsSoapRequestParamaters->personId = $uuid;
             $this->committeemembershipscache[$uuid]=$must->getCommitteeMemberships($getCommitteeMembershipsSoapRequestParamaters)->return;
         }
         return $this->committeemembershipscache[$uuid];        
    }
    
    function getCommittees() {
         global $must; 
         if(empty($this->committeescache[$uuid])) {
             $getCommitteesSoapRequestParamaters=new getCommittees();
             $this->committeescache[$uuid]=$must->getCommittees($getCommitteesSoapRequestParamaters)->return;
         }
         return $this->committeescache;        
    }
    
    function getCommittee($groupId) {
         global $must; 
         if(empty($this->committeecache[$groupId])) {
             $getCommitteeSoapRequestParamaters=new getCommittee();
             $getCommitteeSoapRequestParamaters->groupId=$groupId;
             $this->committeecache[$groupId]=$must->getCommittee($getCommitteeSoapRequestParamaters)->return;
         }
         return $this->committeecache[$groupId];        
        
    }
    /**
    * ReturnSmiley returns a smiley face based on the financiality of the member
    * 
    * @param mixed $member - the unique id of the member
    * @param mixed $tags - HTML tags to include in the output
    * @param mixed $popup - Extra text to include in the html popup message
    * @return mixed
    */
    function returnSmiley($member, $tags="", $popup="") {
       $flyspray_prefs = $this->GetGlobalPrefs();
       if ($member == 0) {
           return "";
       }

       $spd=$this->GetPaidTo($member);
       list($pfr, $pmt)=$this->GetPaymentInfo($member);
       $time=time();
       $offset=16; //How many days leeway to give before the smiley indicates they are behind.
                   //A value of 16, for example, will mean that the embarrassed face only starts showing up when the member is over 16 days in arrears
       $subs_paid_to=$spd ? intval(((((($spd)-time())/60/60/24)-(26-$offset))/30)+0) : 0;
       $spd_date=date("d M Y", $spd);
       $explanation = "\nPayment method: $pmt\nPayment frequency: $pfr\nSubscriptions paid until: $spd_date";
       $pay_method=$this->GetPayMethod($member);
       if ($this->GetLegitMemberNumber($member) && $pay_method != "P") {
          switch($subs_paid_to) {
             case -3:
               $output = "<img $tags src='themes/".$flyspray_prefs['theme_style']."/mortified.png' border='0' title='This member is financial but between two and three months in arrears! $explanation'";
               break;
             case -2:
               $output = "<img $tags src='themes/".$flyspray_prefs['theme_style']."/ashamed.png' border='0' title='This member is financial but between one and two months in arrears! $explanation'";
               break;
             case -1:
               $output = "<img $tags src='themes/".$flyspray_prefs['theme_style']."/embarrassed.png' border='0' title='This member is financial but up to one month in arrears! $explanation'";
               break;
             default:
               $output = "<img $tags src='themes/".$flyspray_prefs['theme_style']."/happy.png' border='0' title='This member is Fully financial $popup $explanation'";
               break;
          }
          if ($popup != "") {
              $output .=" onClick='alert(\"This member is FINANCIAL $popup\")'";
          }
          $output .= ">";
          return $output;
       } elseif ($this->GetLegitMemberNumber($member) && $pay_method == "P") {
           /* With OMS, we don't know if they're payroll deductions, so this never gets acticated */
            $output = "<img $tags src='themes/".$flyspray_prefs['theme_style']."/happy.png' border='0' title='This member is Fully financial $popup'";
            if ($popup != "") {
              $output .=" onClick='alert(\"This member is FINANCIAL $popup\")'";
            }
            $output .= ">";
            return $output;

       } else {
             $output ="<img $tags src='themes/".$flyspray_prefs['theme_style']."/sad.png' border='0' title='This member is Unfinancial!'";
          if ($popup != "") {
              $output .= "return  onClick='alert(\"This member is UNFINANCIAL $popup\")'";
          }
          $output .= ">";
          return $output;
       }
   }

   /**
   * GetLegitMemberNumber function checks if a member number exists in the database
   * and returns a true if they both exist, and are financial. It returns false
   * if they don't exist in the database, or they do exist but they are not
   * financial
   * 
   * @param string $member   The member number
   */
    function GetLegitMemberNumber($member) {

        $uuid=$this->getUUID($member);
        $isFinancial=$this->getFinancial($uuid);
        
        return $isFinancial;
    }

    function GetPaidTo($member) {
      //Gets "paid_to" date for member
      $flyspray_prefs = $this->GetGlobalPrefs();
      $updatecache=false;
      $get_details = $this->dbQuery("SELECT subs_paid_to, modified FROM must_member_cache WHERE member=?", array(intval($member)));
      $get_details = $this->dbFetchRow($get_details);
      $mymodified=$get_details['modified'];       
      list($year, $month, $day)=explode("-", $get_details['subs_paid_to']);
      $paidto=date("U", mktime(NULL,NULL,NULL, $month, $day, $year));
      
        if(!isset($get_details['modified']) || $get_details['modified'] <= time()-(60*60*24)) {
            
            $uuid=$this->getUUID($member);
            $subscription=$this->getSubscription($uuid);
            if($subscription->paidTo) {
                $paidto=date("U",strtotime($subscription->paidTo));
            }
            if(!$mymodified) {
                $insertcache=true;
            } else {
                $updatecache=true;
            }
        }
      
      if($paidto > 0 && $updatecache) {
          $updatenow = $this->dbQuery("UPDATE must_member_cache SET subs_paid_to=?, modified=? WHERE member=?", array(date("Y-M-d", $paidto), time(), intval($member)));
      } else {
          //The date is wrong, don't update anything
      }
      if($insertcache) {
            $this->dbQuery("INSERT INTO must_member_cache (member, subs_paid_to, paying_emp, joined, surname, pref_name, modified)
                             VALUES (".intval($member).", '$year-$month-$day', '".$get_details['paying_emp']."', '".$get_details['joined']."', '".mysql_escape_string($get_details['surname'])."', '".$get_details['pref_name']."', ".time().")");
      }
      return date("Y-M-d", $paidto);
    }

    /* This expects to return the pay method CODE */
    function GetPayMethod($member) {
        $uuid=$this->getUUID($member);
        $subscription=$this->getSubscription($uuid);
        return $subscription->paymentmethod;
    }

    /**
    * Finds out the pay method and pay frequency of a member's subscriptions
    * 
    * @param mixed $member
    */
    function GetPaymentInfo($member) {
        $uuid=$this->getUUID($member);
        $subscription=$this->getSubscription($uuid);
        $subsFreq=!empty($subscription->subscriptionFrequency) ? $subscription->subscriptionFrequency : "unknown";
        $subsMeth=!empty($subscription->paymentMethod) ? $subscription->paymentMethod : "unknown";
        return array($subsFreq, $subsMeth);
    }
    
    /**
    * Uses old MUST system to mark a member number green or red based on financiality
    * 
    * @param mixed $member
    * @param mixed $emp_type
    */
    function highlightMemberNumberByEmpType($member, $emp_type) {
        if ($emp_type == "C" || $emp_type == "X") {
            return "<font color='green'>$member</font>";
        } else {
            return "<font color='red'>$member</font>";
        }
    }

    function returnMemberNumber($member, $searchbutton=TRUE) {
        global $project_prefs, $flyspray_prefs;
        if ($member == 0) {
            $number = "N/A";
        } else {
            $number = $member;
        }
        
        if ($this->GetLegitMemberNumber($member)) {
            $output="<font color='green'>$number</font>";
        } else {
            $output="<font color='red'>$number</font>";
        }
        if ($search) {
            $output.= "&nbsp;<a href='' onClick='window.open(\"index.php?do=member_search&member=$number\", \"_blank\", \"toolbar=no, scrollbars=yes, width=610, height=450\")'><img src='themes/" . $project_prefs['theme_style'] . "/find.png' border='0' hspace=0 vspace=0 title='Search' /></a>";
        }
        return $output;
    }

    /**
    * get the name of a member by their membership number
    * 
    * @param mixed $member
    */
    function returnMemberName($member=0) {
        if (empty($member)) {
            $member=0;
        }

        $uuid=$this->getUUID($member);
        $person=$this->getPerson($uuid);
        $output="";
        if(!empty($person->alias)) {
            $output=$person->alias." ".$person->lastName;
        } else {
            $output=$person->firstNames." ".$person->lastName; 
        }

        return $output;
    }

    /**
    * Calculates how many days a member has been a member
    * 
    * @param mixed $member
    */
    function returnDaysMember($member) {
        if ($member==0) {
          return "";
        }
        $uuid=$this->getUUID($member);
        $subscription=$this->getSubscription($uuid);
        
        $datestamp=date("U",strtotime($subscription->associationFrom));
        $days=round((time()-$datestamp)/60/60/24);
        return $days;
    }

    /**
    * Returns the name of the subscription level for the member 
    * (called from details.php in /scripts)
    * 
    * @param mixed $member
    */
    function returnSubsLevel($member) {
        if ($member==0) {
            return "";
        }
        $uuid=$this->getUUID($member);
        $subscription=$this->getSubscription($uuid);
        return $subscription->subscriptionMethod;
   }

    /**
    * Returns basic contact information for member (ie: phone numbers, email etc)
    * 
    * @param mixed $member
    */
    function returnContactInfo($member) {
        if ($member==0) {
          return array();
        }
        $results=array();
        
        $uuid=$this->getUUID($member);
        
        $person=$this->getPerson($uuid);
                
        $employment=$this->getEmployment($uuid);

        /* work_phone, home_phone, email, mobile, mail address */
        $output['email']=isset($employment->email) ? $employment->email : $person->email;
        $output['attrib_6']=$person->mobile;
        $output['home_phone']=$person->homePhone;
        $output['mail_addr_1']=$person->address->formatted; 
        $output['work_phone']=$employment->phone;
               
        return $output;
   }

    function returnMemberNameWithPE($member) {
        // TODO: See if this is even used anymore!
        $uuid=$this->getUUID($member);
        $member=$this->getPerson($uuid);
        // TODO: Add the paying emp/employer alias into the brackets
        if(!empty($member->alias)){$output=$member->alias." ".$member->lastName." ()";}
        else {$output=$member->firstNames." ".$member->lastName." ()";}
        return $output;
   }

    function getMemberPayingEmp($member) {
        /*
        $get_details = $this->odbcQuery("SELECT paying_emp FROM members WHERE member = $member");
        $get_details = $this->odbcFetchArray($get_details);
        */
        $get_details['paying_emp']="";
        return $get_details['paying_emp'];
   }

    function getPayingEmpCatCode($paying_emp)  {
        /* INTERNAL CASETRACKER CODE, NOT EXTERNAL DB */
        /* TODO: Move this out */
        $get_details = $this->dbQuery("SELECT category_id
                                       FROM ".$this->returnDBPrefix()."list_category
                                       WHERE category_name = ?",
                                       array($paying_emp));
        $get_details = $this->dbFetchArray($get_details);
        return $get_details['category_id'];
   }

    function getPayingEmpCatCodeTas($paying_emp) {
        /* INTERNAL CASETRACKER CODE, NOT EXTERNAL DB */
        /* TODO: Move this out */
        $get_details = $this->dbQuery("SELECT category_id
                                       FROM ".$this->returnDBPrefix()."list_category
                                       WHERE category_descrip = ?",
                                       array($paying_emp));
        $get_details = $this->dbFetchArray($get_details);
        //print "\n\n<!-- paying_emp: $paying_emp -->\n";
        return $get_details['category_descrip'];
   }

    function GetMemberDetails($member=0) {
        global $must;
        if(empty($member)) {$member=0;}  //Stop errors when there is no member number
        $flyspray_prefs = $this->GetGlobalPrefs;
        $lang = $flyspray_prefs['lang_code'];
        if(!$must) {
            //TODO: Move back to main function
            $get_details=$this->dbQuery("SELECT name FROM ".$this->returnDBPrefix()."tasks
                                         WHERE member = ?",
                                         array($member));
            $get_details = $this->dbFetchArray($get_details);
            if(empty($get_details)) {
                $get_details=array();
            } else {
                list($given_names, $surname)=split(" ", $get_details[0]['name']);
                $get_details[0]['surname']=$surname;
                $get_details[0]['given_names']=$given_names;
                $get_details[0]['email']="";
            }
            return $get_details;
        }
        /* $get_details = $this->odbcQuery("SELECT members.surname, members.given_names,
                                                members.pref_name, members.title,
                                                members.email, members.birth,
                                                members.gender, members.home_addr_1,
                                                members.home_addr_2, members.home_addr_3,
                                                members.home_phone, members.work_phone,
                                                members.fax, members.actual_emp,
                                                members.paying_emp,
                                                employers.emp_descrip, workplaces.work_addr_1,
                                                workplaces.work_addr_2, workplaces.work_addr_3,
                                                workplaces.work_addr_4, members.member,
                                                mem_attributes.attrib_6, mem_subs_control.subs_paid_to,
                                                awards.award, awards.award_descrip,
                                                award_details.url, members.mail_addr_1
                                                  FROM members, employers, workplaces,
                                                       mem_attributes, mem_subs_control, awards,
                                                       award_details
                                                  WHERE members.member *= mem_attributes.member
                                                  AND members.paying_emp=employers.employer
                                                  AND members.workplace=workplaces.workplace
                                                  AND members.member=mem_subs_control.member
                                                  AND members.award=awards.award
                                                  AND awards.award *= award_details.award
                                                  AND members.member=$member"); 
        $get_details = $this->odbcFetchArray($get_details);
        if (empty($get_details)) {
            $get_details = array();
        }         */
        $uuid=$this->getUUID($member);
        $person=$this->getPerson($uuid);
        
              
        
        return $get_details;
    }

    function getCommitteeInfo($member) {
      /* $details=$this->odbcQuery("SELECT * FROM committees, committee_mems
                                                           WHERE committees.committee=committee_mems.committee
                                                           AND member = $member
                                                             ORDER BY committee_descrip",
                                                           array());   */
      $output=array();
      $uuid=$this->getUUID($member);
      
      $committees=$this->getCommitteeMemberships($uuid);
      print_r($committees); die();
      /* while ($row = $this->odbcFetchArray($details)) {
          $output[]=$row;
        }               */
        return $output;
    }

    /**
    * Funcion irrelevent in OMS - no files or corro
    * 
    * @param mixed $member
    */
    function getCorroDetails($member) {
        /*$get_details = $this->odbcQuery("SELECT *
                                       FROM corro
                                       WHERE file_number = ?
                                       ORDER BY date_received DESC", array($member));*/
        $output=array();
        /*while ($row = $this->odbcFetchArray($get_details)) {
            $output[]=$row;
        }*/
        return $output;
    }

    /**
    * List members who match against a set of criteria
    * 
    * @param mixed $wheres
    */
    function SearchMembers($wheres) {
        /* $sql = "SELECT members.surname, members.given_names,
                members.pref_name, members.title,
                members.email, members.birth,
                members.gender, members.home_addr_1,
                members.home_addr_2, members.home_addr_3,
                members.home_phone, members.work_phone,
                members.fax, members.actual_emp,
                members.paying_emp, members.class,
                members.joined, members.resignation,
                members.workplace, members.employed,
                b.emp_descrip, workplaces.work_addr_1,
                workplaces.work_addr_2, workplaces.work_addr_3,
                workplaces.work_addr_4, members.member,
                mem_attributes.attrib_3, mem_attributes.attrib_4,
                mem_attributes.attrib_6, mem_subs_control.subs_paid_to,
                awards.award, awards.award_descrip,
                actual_emp_descrip = a.emp_descrip,
                classes.class_descrip,
                b.emp_type,
                award_details.url,
                members.class_level,
                mem_type, members.mail_addr_1
                  FROM members,
                       employers a,
                       employers b,
                       workplaces,
                       mem_attributes,
                       mem_subs_control,
                       awards,
                       award_details,
                       classes
                  WHERE members.member *= mem_attributes.member
                  AND members.paying_emp=b.employer
                  AND members.actual_emp=a.employer
                  AND members.workplace=workplaces.workplace
                  AND members.member=mem_subs_control.member
                  AND members.award=awards.award
                  AND members.class=classes.class
                  AND awards.award *= award_details.award
                  AND ".$wheres."
                  ORDER BY surname";
//        echo $sql;
        echo "<!-- $sql -->";
        $get_details = $this->odbcQuery($sql);
                while ($row = $this->dbFetchArray($get_details)) {
                    $output[]=$row;
                }
                if (empty($get_details)) {
                    $get_details = array();
                }                          */
        if(substr($wheres, 0, 15)== "members.member=") {
            //We have a selected member, so we can display a result
            $member=substr($wheres, 15, strlen($wheres)-15);
            
            $uuid=$this->getUUID($member);
            $person=$this->getPerson($uuid);
            $financial=$this->getFinancial($uuid);
            $employment=$this->getEmployment($uuid);
            $employment=$employment[0]; //We only want the first, if this is a list
            $employer=$this->getEmployer($employment->groupId);
            //print_r($employer); die();
            $subscription=$this->getSubscription($uuid);
            
            $output["surname"]=$person->lastName;
            $output["given_names"]=$person->firstNames;
            $output["pref_name"]=$person->alias;
            $output["title"]=$person->title;
            $output["email"]=!empty($employment->email) ? $employment->email : $person->email;
            $output["birth"]=$this->omsDateConversion($person->dob);
            $output["gender"]=$person->gender ? $person->gender : "NA";
            $output["home_addr_1"]=$person->address->street;
            $output["home_addr_2"]=$person->address->subStreet;
            $output["home_addr_3"]=$person->address->locality.", ".$person->address->postalCode;
            $output["home_phone"]=$person->homePhone;
            $output["work_phone"]=$employment->workPhone;
            $output["fax"]=$employment->fax;
            $output["actual_emp"]=$employer->division;
            $output["paying_emp"]=$employer->abbreviatedName;
            $output["class"]="N/A";
            $output["joined"]=$this->omsDateConversion($subscription->associationFrom);
            $output["resignation"]=$this->omsDateConversion($subscription->associationTo);
            $output["workplace"]="";
            $output["employed"]=$this->omsDateConversion($employment->from);
            $output["emp_descrip"]=$employer->name;
            $output["work_addr_1"]=$employment->address->subStreet;
            $output["work_addr_2"]=$employment->address->street;
            $output["work_addr_3"]="";
            $output["work_addr_4"]=$employment->address->locality.", ".$employment->address->postalCode." ".$employment->address->administrativeArea;
            $output["member"]=$member;
            $output["attrib_3"]=""; //VPS Grade
            $output["attrib_4"]=""; //VPS Subgrade
            $output["attrib_6"]=""; //Mobile phone
            $output["subs_paid_to"]=$this->omsDateConversion($subscription->paidTo);
            $output["award"]="";    //Agreement/award - later
            $output["award_descrip"]="";
            $output["class_descrip"]=$employment->position;
            $output["emp_type"]="";
            $output["url"]=""; //Award details URL
            $output["class_level"]="";
            $output["mem_type"]="";
            $output["mail_addr_1"]=$person->address->formatted;
            //echo "<pre>";print_r($employment);echo "</pre>";
        }
        //print_r($output);die();
        return array($output);
    }

    function omsDateConversion($date) {
        $newdate=new DateTime($date);
        return $newdate->format("Y-m-d h:m:s");
    }
    
    /**
    * getPayingEmps lists employers ordered alphabetically by name
    * 
    * @return array containing array of employer code and employer description
    * 
    */
    function getPayingEmps() {
        
        /* $get_details = $this->odbcQuery("SELECT employer, emp_descrip FROM employers
                        WHERE can_be_paying_emp='Y'
                        AND employer not like 'ZR%'
                        ORDER BY employer");
//        print_r($get_details);
        while ($row = $this->odbcFetchArray($get_details)) {
            $output[]=$row;
        }
//        $get_details = $this->odbcFetchArray($get_details);
        if (empty($get_details)) {
            $get_details = array();
        }*/
        
        $output=$this->getEmployers();
        $output=json_encode($output);
        $output=json_decode($output, true);
        return $output;
    }

    /**
    * List workplaces that match a particular search/filter
    * 
    * @param mixed $array
    */
    function getWorkplaces($array=array()) {
      /* $inlist = count($array)>0 ? "AND workplaces.workplace IN ('".implode("', '", $array)."')" : null;
      $get_details = $this->odbcQuery("SELECT total=count(member), workplaces.workplace, work_addr_1, work_addr_2, work_addr_3, work_addr_4
                                                                       FROM members, workplaces, employers
                                                                       WHERE members.workplace=workplaces.workplace
                                                                       AND members.paying_emp=employers.employer
                                                                       AND emp_type='C'
                                                                         $inlist
                                                                       GROUP BY workplaces.workplace");
      $output=array();
      while($row=$this->dbFetchArray($get_details)) {
          $output[]=array('workplace'=>$row['workplace'], 'name'=>$row['work_addr_1']." ".$row['work_addr_2'], 'count'=>$row['total']);
        } */
        return $output;
    }

    /**
    * List all divisions/ programmes available
    * 
    */
    function getActualEmps() {
        /* $get_details = $this->odbcQuery("SELECT employer, emp_descrip FROM employers
                        WHERE employer not like 'ZR%'
                        ORDER BY employer");
//        print_r($get_details);
        while ($row = $this->dbFetchArray($get_details)) {
            $output[]=$row;
        }
//        $get_details = $this->odbcFetchArray($get_details);
        if (empty($get_details)) {
            $get_details = array();
        }*/
        return $output;
    }
    
    function getReps($workplace="%", $exclude=array()) {
        //TODO: Complete the getReps function    
        
        /* $repcount=$fs->odbcQuery("SELECT * FROM workplace_reps WHERE workplace = ? AND rep_type != ?", array($memberdata['workplace'], 'FAX'));
            $repcount=$fs->dbCountRows($repcount);  */
            
            $repcount=0;
            
            return $repcount;
    }
    
    function getContacts($workplace, $excludes=array()) {
          /* $get_contacts = $fs->odbcQuery("SELECT workplace_reps.*, work_phone, fax, email, surname, pref_name, rep_type_descrip
                               FROM workplace_reps, members, rep_types
                               WHERE members.member=workplace_reps.member
                             AND workplace_reps.rep_type=rep_types.rep_type
                             AND workplace_reps.workplace = ?
                             AND workplace_reps.rep_type != ?
                             ORDER BY workplace_reps.rep_type desc",
                             array($workplace, 'FAX'));    */
          $contacts=array();
          /* while($row=$fs->odbcFetchArray($get_contacts)){
            $contacts[]=$row;
          } // while   */
          return $contacts;
    }
    
    
    /* This function is irrelevent for OMS since it doesn't
       handle files */
    function getFileDetails($member) {
        global $conf_array;
        $flyspray_prefs = $this->GetGlobalPrefs;
        $lang = $flyspray_prefs['lang_code'];
        /* $get_details = $this->odbcQuery("SELECT *
                                           FROM ".$conf_array['must']['mustfilestable']."
                                           WHERE file_number = '$member'");
        $get_details = $this->odbcFetchArray($get_details); */
        if (empty($get_details)) {
            $get_details = array();
        }
        return $get_details;

    }

    /**
    * Function getUFMembers returns an array of members who are unfinancial
    * 
    * @param mixed $members A list of members (as an array) to check
    */
    function getUFMembers($members) {
        $ufmembers=array();
        return $ufmembers;   
    }

}  
?>
