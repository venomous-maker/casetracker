/* THANKS TO FLYSPRAY */
OpenCaseTracker was developed by modifying a GPL Software Tool designed for
bugtracking software development.

We took the Flyspray version released in about 2005 and made significant
modifications to it in order to use it as a method for tracking and managing
individual cases for the CPSU in Victoria.

The software was so well written and easy to modify that as the years went by
we made more and more modifications. Although the code is now significantly
different to the original flyspray code, the general layout and coding
methodology has been followed to some extent.

This file is to credit the developers of flyspray for developing such a useful
application and releasing it as a GPL product which allowed us to modify it
to suit our own purposes.

It is released under the terms of the GPL 3, which complies with the original
flyspray GPL 2.1 license. You are, as per the original flyspray, free to modify
and distribute this source code to suit your needs and as you see fit.

OpenCaseTracker is a fork of the flyspray software in the sense that it has been
taken into a new coding direction, but not to compete with the original - instead
it has been forked to use flyspray for a purpose completely different to the
intentions of the original designers. Again, this is testament to the design
of the original developers. Congratuations to them.

Browse to the original flyspray development at:

http://flyspray.org