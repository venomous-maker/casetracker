<?php
/** Get translation for specified language and page.  It loads default
language (en) and then merges with requested one. Thus it makes English
messages available even if translation is not present.
*/
function get_language_pack($lang, $module) {
	if(!isset($lang)) {$lang = "en";}
    $before = get_defined_vars();
    require_once("lang/en/$module.php");
    $after_en = get_defined_vars();
    $new_var = array_keys(array_diff($after_en, $before));
    $new_var_name = $new_var[1];
    $new_var['en'] = $$new_var_name;
    require_once("lang/$lang/$module.php");
    $new_var[$lang] = $$new_var_name;

    $$new_var_name = array_merge($new_var['en'], $new_var[$lang]);
}

/*
Function to return distinct keys in a two-level array
*/
function array_keys_recurs($array, $method="all") {
 $output=array();
 foreach($array as $element) {
  foreach($element as $key=>$val) {
   switch($method) {
    case "strings":
     //$output["strings"]="strings";
	 if(!is_numeric($key)) {
	  $output[$key]=$key;
	 }
	 break;
	case "numbers":
	 if(is_numeric($key)) {
	  $output[$key]=$key;
	 }
	 break;
	case "all":
	 $output[$key]=$key;
	break;
   }
  }
 }
 return $output;
}

/** Test to see if user resubmitted a form.
  Checks only newtask and addcomment actions.
  @return   true if user has submitted the same action within less than
	    6 hours, false otherwise
*/
function requestDuplicated() {
  // garbage collection -- clean entries older than x hrs
  $now = time();
  global $conf_array;
  if (!empty($_SESSION['requests_hash'])) {
    foreach ($_SESSION['requests_hash'] as $key => $val) {
      if ($val < $now-60*60*$conf_array['general']['cleanuphours']) {
	unset($_SESSION['requests_hash'][$key]);
      }
    }
  }
  $requestarray = array_merge(array_keys($_POST), array_values($_POST));
  /* UNCOMMENT THE NEXT SECTION FOR DEBUGGING INFO TO BE OUTPUT TO HTML SOURCE */
  /* 
  echo "<!--\n";
  echo "CURRENT REQUEST - FROM requestDuplicated FUNCTION \n";
  $currentrequest = md5(join(':', $requestarray));
  echo $currentrequest."\n";
  echo "REQUESTS HASH\n";
  print_r($_SESSION['requests_hash']);
  echo "\n".$_SESSION['requests_hash'][$currentrequest];
  echo "\nREQUEST ARRAY - FROM requestDuplicated FUNCTION \n";
  print_r($requestarray);
  echo "\nPOSTS\n";
  print_r($_POST);
  echo "-->\n"; 
  */
  if (isset($_POST['do']) && $_POST['do']=='modify'
	and preg_match('/^newtask|addcomment|newopenshut$/',$_POST['action'])) {
    $currentrequest = md5(join(':', $requestarray));
    /* UNCOMMENT THE NEXT SECTION FOR DEBUGGING INFO TO BE OUTPUT TO HTML SOURCE */
    /*
    echo "\n\n<!-- CURRENT REQUEST: $currentrequest -->\n";
    echo "\n\n<!-- requests hash!\n";
    print_r($_SESSION['requests_hash']);
    echo "\n-->\n";
    */
    if (!empty($_SESSION['requests_hash'][$currentrequest])) {
      if($conf_array['unsethash'] == 1) {
          unset($_SESSION['requests_hash'][$currentrequest]);
      }
      return true;
    }
  }
  $_SESSION['requests_hash'][$currentrequest] = time();
  return false;
}

/**
* If there is no MySQL connection, create an atlernative mysql_real_escape_string function
* 
*/
if(!function_exists('mysql_real_escape_string')) {
    function mysql_real_escape_string($inp) {
        if(is_array($inp))
            return array_map(__METHOD__, $inp);

        if(!empty($inp) && is_string($inp)) {
            return str_replace(array('\\', "\0", "\n", "\r", "'", '"', "\x1a"), array('\\\\', '\\0', '\\n', '\\r', "\\'", '\\"', '\\Z'), $inp);
        }

        return $inp;
    }     
}

if(!function_exists('array_combine')) {
 function array_combine($a, $b) {
   $c = array();
   $at = array_values($a);
   $bt = array_values($b);
   foreach($at as $key=>$aval) $c[$aval] = $bt[$key];
   return $c;
 }
}

if(!function_exists('json_encode')) {
	function json_encode( $data ) {
		if( is_array($data) || is_object($data) ) {
			$islist = is_array($data) && ( empty($data) || array_keys($data) === range(0,count($data)-1) );

			if( $islist ) {
				$json = '[' . implode(',', array_map('json_encode', $data) ) . ']';
			} else {
				$items = Array();
				foreach( $data as $key => $value ) {
					$items[] = json_encode("$key") . ':' . json_encode($value);
				}
				$json = '{' . implode(',', $items) . '}';
			}
		} elseif( is_string($data) ) {
			# Escape non-printable or Non-ASCII characters.
			# I also put the \\ character first, as suggested in comments on the 'addclashes' page.
			$string = '"' . addcslashes($data, "\\\"\n\r\t/" . chr(8) . chr(12)) . '"';
			$json    = '';
			$len    = strlen($string);
			# Convert UTF-8 to Hexadecimal Codepoints.
			for( $i = 0; $i < $len; $i++ ) {

				$char = $string[$i];
				$c1 = ord($char);

				# Single byte;
				if( $c1 <128 ) {
					$json .= ($c1 > 31) ? $char : sprintf("\\u%04x", $c1);
					continue;
				}

				# Double byte
				$c2 = ord($string[++$i]);
				if ( ($c1 & 32) === 0 ) {
					$json .= sprintf("\\u%04x", ($c1 - 192) * 64 + $c2 - 128);
					continue;
				}

				# Triple
				$c3 = ord($string[++$i]);
				if( ($c1 & 16) === 0 ) {
					$json .= sprintf("\\u%04x", (($c1 - 224) <<12) + (($c2 - 128) << 6) + ($c3 - 128));
					continue;
				}

				# Quadruple
				$c4 = ord($string[++$i]);
				if( ($c1 & 8 ) === 0 ) {
					$u = (($c1 & 15) << 2) + (($c2>>4) & 3) - 1;

					$w1 = (54<<10) + ($u<<6) + (($c2 & 15) << 2) + (($c3>>4) & 3);
					$w2 = (55<<10) + (($c3 & 15)<<6) + ($c4-128);
					$json .= sprintf("\\u%04x\\u%04x", $w1, $w2);
				}
			}
		} else {
			# int, floats, bools, null
			$json = strtolower(var_export( $data, true ));
		}
		return $json;
	}
}

function GetDirContents($dir){
   ini_set("max_execution_time",10);
   if (!is_dir($dir)) return array();
   if ($root=@opendir($dir)){
       while ($file=readdir($root)){
           if($file=="." || $file==".."){continue;}
           if(is_dir($dir."/".$file)){
               //$files=array_merge($files,GetDirContents($dir."/".$file));
           }else{
		   $files[]=array("value"=>$dir."/".$file, "name"=>$file);
           }
       }
   }
   return $files;
}

/**
* Class OCT provides all the base class functionality including
* standard internal OCT database connectivity
*/
class OCT {
   var $version = '2';    

   function convertMySQLDateToUnix($date="00-00-0000") {
      list($year, $month, $day)=explode("-", $date);
      return mktime(0, 0, 0, $month, $day, $year);
    }

   function returnDBPrefix() {
        global $dbprefix;
        return $dbprefix;
    }

   function getGlobalPrefs() {
      $get_prefs = $this->dbQuery("SELECT pref_name, pref_value FROM ".$this->returnDBPrefix()."prefs");

      $global_prefs = array();

      while (list($pref, $value) = $this->dbFetchRow($get_prefs)) {
         $temp_array = array("$pref"  => "$value");
         $global_prefs = $global_prefs + $temp_array;
      }

      return $global_prefs;
   }

   function getProjectPrefs($project_id) {
      $get_prefs = $this->dbQuery("SELECT * FROM ".$this->returnDBPrefix()."projects WHERE project_id = ?", array($project_id));

      $project_prefs = $this->dbFetchArray($get_prefs);

      return $project_prefs;
   }

   function getUserPrefs($user_id) {
      $get_prefs = $this->dbQuery("SELECT * FROM ".$this->returnDBPrefix()."users WHERE user_id = ?", array($user_id));
      $user_prefs = $this->dbFetchArray($get_prefs);
      return $user_prefs;
   }

    /**
   * Database Functions: dbOpen  - connects to the local OpenCaseTracker database
   * 
   * @param mixed $dbhost host name of database server
   * @param mixed $dbuser user name for database
   * @param mixed $dbpass password for database
   * @param mixed $dbname Name of database
   * @param mixed $dbtype Database type
   */
    function dbOpen($dbhost = '', $dbuser = '', $dbpass = '', $dbname = '', $dbtype = '') {

      $this->dbtype = $dbtype;

      $this->dblink = NewADOConnection($dbtype);
      //$this->dblink->debug=true;
      $res = $this->dblink->Connect($dbhost, $dbuser, $dbpass, $dbname);
      $this->dblink->SetFetchMode(ADODB_FETCH_BOTH);

      return $res;

   }

    function dbExec($sql, $inputarr=false, $numrows=-1, $offset=-1) {
      // replace undef values (treated as NULL in SQL database) with empty
      // strings -> uncomment for mysql, but probably not needed
      global $conf_array;
      if($conf_array['database']['dbtype']=="mysql") {
          $inputarr = $this->dbUndefToEmpty($inputarr);
      }
      $ADODB_FETCH_MODE = ADODB_FETCH_ASSOC;
      @$ADODB_FORCE_TYPE = ADODB_FORCE_NULL;
      if (($numrows>=0) or ($offset>=0)) {
          $result =  $this->dblink->SelectLimit($sql, $numrows, $offset, $inputarr);
      } else {
          $result =  $this->dblink->Execute($sql, $inputarr);
      }
      if (!$result) {
          if (function_exists("debug_backtrace")) {
              echo "<pre style='text-align: left;'>";
              var_dump(debug_backtrace());
              echo "</pre>";
          }

          die (sprintf("Query {%s} with params {%s} Failed! (%s)",
                    $sql, implode(', ', $inputarr),
                    $this->dblink->ErrorMsg()));
      }
      return $result;
   }

    function dbCountRows($result) {
      $num_rows = $result->RecordCount();
           return $num_rows;
   }

    function dbFetchRow(&$result) {
      @$row = $result->FetchRow();
           return $row;
   }

    /* compatibility functions */
    function dbQuery($sql, $inputarr=false, $numrows=-1, $offset=-1) {
      $result = $this->dbExec($sql, $inputarr, $numrows, $offset);
      return $result;
   }

    function dbFetchArray(&$result) {
      $row = $this->dbFetchRow($result);
      return $row;
   }

    function dbClose() {
      $this->dblink->Close();
   }

    /* Replace undef values (treated as NULL in SQL database) with empty
   strings.
   @param arr        input array or false
   @return        SQL safe array (without undefined values)
   */
    function dbUndefToEmpty($arr) {
       if (is_array($arr)) {
           $c = count($arr);

           for($i=0; $i<$c; $i++)
               if (!isset($arr[$i]))
                   $arr[$i] = '';
       }
       return $arr;
   }

    /** Replace empty values with 0. Useful when inserting values from
    checkboxes.
    */
    function emptyToZero($arg) {
        return empty($arg) ? 0 : $arg;
    }

    function emptyToNull($arg) {
       return empty($arg) ? NULL : $arg;
    }

    function emailsSent($caseid) {
       $get_emails = $this->dbQuery("SELECT date_added, file_desc
                                        FROM ".$this->returnDBPrefix()."attachments
                                     WHERE task_id = ?
                                     AND file_desc LIKE  '%Email Template Sent%'
                                     ORDER BY date_added",
                                     array($caseid));
        while($row=$this->dbFetchArray($get_emails)){
            $aname=substr($row['file_desc'],
                          strpos($row['file_desc'], '(') +1,
                          strpos($row['file_desc'], ')', strpos($row['file_desc'], '(')+1)-(strpos($row['file_desc'], '(')+1));
            $list[]=date("d M Y", $row['date_added']).": $aname";
        } // while
        return $list;
   }

    function getTimes($id) {
      $query = "SELECT *
      FROM ".$this->returnDBPrefix()."times, ".$this->returnDBPrefix()."users
      WHERE ".$this->returnDBPrefix()."times.user_id=".$this->returnDBPrefix()."users.user_id
      AND task_id = ? ORDER BY date desc";
      $get_details = $this->dbQuery($query, array($id));
      $output=array();
      while ($row = $this->dbFetchArray($get_details)) {
        $output[]=$row;
      }
      return $output;
    }

    function getTimePayments($id, $type="total") {
      $query = "SELECT * FROM ".$this->returnDBPrefix()."payments WHERE task_id = ? ORDER BY date_received";
      $get_details = $this->dbQuery($query, array($id));

      if($type == "total") {
        $output=0;
        while ($row=$this->dbFetchArray($get_details)) {
            $output+=$row['amount'];
        }
      } elseif($type == "list") {
        $output=array();
        while ($row=$this->dbFetchArray($get_details)) {
            $output[]=$row;
        }
      }
      return $output;
    }

    function getTotalTime($times) {
      $totaltime=0;
      foreach($times as $entry) {
        $totaltime=$totaltime+($entry['end'] - $entry['start']);
      }
      return $totaltime;
    }

    function getCreditTime($id) {
      $prefs=$this->getGlobalPrefs();
      $defaultrate=$prefs['billing_rate'];
      $query = "SELECT time, rate FROM ".$this->returnDBPrefix()."times WHERE task_id = ? ORDER BY date";
      $get_details = $this->dbQuery($query, array($id));
      $totalused=0;
      while ($row = $this->dbFetchArray($get_details)) {
      //echo $row['rate']."--".$row['time']."<br />";
        if($row['rate']) {
          $thistime = ($row['time']*$row['rate']);

        } else {
          $thistime = ($row['time']*$defaultrate);
        }
        $totalused=$totalused+$thistime;
      }
      $totalused=$totalused/60;
      $totalpaid=$this->getTimePayments($id);
      $output=$totalpaid-$totalused;
      return $output;
    }

    function getTaskClassList() {
      $query = "SELECT distinct class_descrip FROM ".$this->returnDBPrefix()."task_classes ORDER BY class_descrip";
      $result = $this->odbcQuery($query);
      while ($row=$this->dbFetchArray($result)) {
        $task_classes[]=$row['class_descrip'];
      }
      return $task_classes;
    }

    function getTaskActivityLevel($taskid) {

      //Find out if this is a servant task
      $query = "SELECT master_task FROM ".$this->returnDBPrefix()."master WHERE servant_task=$taskid";
      $result = $this->dbQuery($query);
      while($row=$this->dbFetchArray($result)) {
        $taskid=$row['master_task'];
      }

      list($year, $month, $day)=explode("-", date("Y-m-d", time()));
      $now=mktime(0, 0, 0, $month, $day, $year);
      $fourweeksago=$now - (60*60*24*28);
      $threeweeksago=$now - (60*60*24*21);
      $twoweeksago=$now - (60*60*24*14);
      $oneweeksago=$now - (60*60*24*7);
      $now=$now+(60*60*24);
      $query = "SELECT *
                FROM ".$this->returnDBPrefix()."history
                WHERE task_id = $taskid
                AND event_type IN (1, 4, 5, 6, 7, 8)
                ORDER BY event_date DESC LIMIT 1";
      $result = $this->dbQuery($query);
      $output=array(1=>0, 2=>0, 3=>0, 4=>0);
      while($row=$this->dbFetchArray($result)) {
        if($row['event_date'] < $fourweeksago) {
          return 5;
        } elseif ($row['event_date'] < $threeweeksago) {
          return 4;
        } elseif ($row['event_date'] < $twoweeksago) {
          return 3;
        } elseif ($row['event_date'] < $oneweeksago) {
          return 2;
        } elseif ($row['event_date'] < $now) {
          return 1;
        } else {
          return 1;
        }
      }
    }

    function buildAddDateMenu($case, $date="", $extraid="") {
        global $mobile;
        global $flyspray_prefs;
        if($mobile) {$output .= "<br />";}
        $output .= "<input~type='text'~id='datedue$case$extraid'~style='display:~none'~readonly='readonly'~name='datedue$case$extraid'~size='12'~value='".date("Y-m-d", $date)."'~onChange='loadURL(\"index.php?do=modify&action=adddays&id=$case&newdate=\", \"_top\", this.value, \"~change~the~date-due~to~\"+this.value)'>";
        $output .= "\n<button~id=\"triggerdate$case$extraid\"~title='Re-schedule~this~case!'>.</button>\n~<script~type=\"text/javascript\">\n~Calendar.setup(\n{\ninputField~~:~\"datedue$case$extraid\",\nifFormat~~:~\"%Y-%m-%d\",\nbutton~~:~\"triggerdate$case$extraid\",\nelectric~~:~false\n}\n);\n</script>";

        return $output;
    }
    
    function countCases($user) {
        if(isset($_SESSION['noslaves']) && $_SESSION['noslaves'] == "true") {
          $get_details = $this->dbQuery ("SELECT count(*) FROM ".$this->returnDBPrefix()."tasks LEFT JOIN ".$this->returnDBPrefix()."master ON ".$this->returnDBPrefix()."tasks.task_id = ".$this->returnDBPrefix()."master.servant_task WHERE assigned_to = ? AND ".$this->returnDBPrefix()."master.servant_task IS NULL AND is_closed=0", array($user));
        } else {
          $get_details = $this->dbQuery ("SELECT count(*) FROM ".$this->returnDBPrefix()."tasks WHERE assigned_to = ? AND is_closed = 0", array($user));
        }
        if (empty($get_details)) {
            $get_details = array();
        }
        $get_details = $this->dbFetchArray($get_details);
        foreach($get_details as $detail) {
            $count=$detail;
        }
        return $count;
    }

    function countClosedCases($user) {
        $get_details = $this->dbQuery ("SELECT count(*) FROM ".$this->returnDBPrefix()."tasks WHERE assigned_to = ? AND is_closed = 1", array($user));
        if (empty($get_details)) {
            $get_details = array();
        }
        $get_details = $this->dbFetchArray($get_details);
        foreach($get_details as $detail) {
            $count=$detail;
        }
        return $count;
    }

    function countOverdueCases($user) {
        global $conf_array;
        if($user > 0) {
            if($conf_array['database']['dbtype']=="mysql") {$modifier="LIKE";} else {$modifier="=";}
            $get_details = $this->dbQuery("SELECT count(*) FROM ".$this->returnDBPrefix()."tasks WHERE assigned_to ".$modifier." ? AND date_due < ? AND is_closed != 1", array($user, date(U, mktime(0, 0, 0, date("m"), date("d"), date("Y")))));
        } else {
            $get_details = $this->dbQuery("SELECT count(*) FROM ".$this->returnDBPrefix()."tasks WHERE date_due < ? AND is_closed != 1", array(date(U, mktime(0, 0, 0, date("m"), date("d"), date("Y")))));
        }
        if (empty($get_details)) {
            $get_details = array();
        }
        $get_details = $this->dbFetchArray($get_details);
        foreach($get_details as $detail) {
            $count=$detail;
        }
        return $count;
    }

    function getOverdueCases($user) {
        $get_details = $this->dbQuery(
                        "SELECT task_id, member, item_summary, date_due
                         FROM ".$this->returnDBPrefix()."tasks
                         WHERE assigned_to LIKE ?
                         AND date_due < ?
                         AND is_closed != 1
                         ORDER BY date_due",
                        array(
                            $user,
                            date(U, mktime(0, 0, 0, date("m"), date("d"), date("Y")))
                            )
                        );

        while ($row = $this->dbFetchArray($get_details)) {
          $details[]=$row;
        }
        return $details;
    }  

    function getMemberDetailsByCase($caseid) {
        //Get member number
        $casedetails=$this->dbQuery("SELECT member FROM ".$this->returnDBPrefix()."tasks WHERE task_id = ?", array($this->emptyToZero($caseid)));
        $casedetails=$this->dbFetchArray($casedetails);

        $memberinfo=$this->getMemberDetails($casedetails['member']);
        return $memberinfo;

    }

    function getEmailTemplateList($project_id) {
        $get_details = $this->dbQuery("SELECT template_id, name FROM ".$this->returnDBPrefix()."emailtemplates WHERE project_id = ? ORDER BY name", array($project_id));
        while ($row = $this->dbFetchArray($get_details)) {
            $output[]=$row;
        }
        return $output;
    }

    function getEmailTemplate($template_id) {
        $get_details=$this->dbQuery("SELECT * FROM ".$this->returnDBPrefix()."emailtemplates WHERE template_id = ?", array($template_id));
        $get_details=$this->dbFetchArray($get_details);
        return $get_details;
    }

    // Thanks to Mr Lance Conry for this query that saved me a lot of effort.
    // Check him out at http://www.rhinosw.com/
    function GetTaskDetails($task_id) {

       $flyspray_prefs = $this->GetGlobalPrefs();
       $lang = $flyspray_prefs['lang_code'];

        $get_details = $this->dbQuery("SELECT *,
                                                vr.version_name as reported_version_name,
                                                vd.version_name as due_in_version_name
                                                FROM ".$this->returnDBPrefix()."tasks t
                                                LEFT JOIN ".$this->returnDBPrefix()."projects p ON t.attached_to_project = p.project_id
                                                LEFT JOIN ".$this->returnDBPrefix()."list_category c ON t.product_category = c.category_id
                                                LEFT JOIN ".$this->returnDBPrefix()."list_os o ON t.operating_system = o.os_id
                                                LEFT JOIN ".$this->returnDBPrefix()."list_resolution r ON t.resolution_reason = r.resolution_id
                                                LEFT JOIN ".$this->returnDBPrefix()."list_tasktype tt ON t.task_type = tt.tasktype_id
                                                LEFT JOIN ".$this->returnDBPrefix()."list_version vr ON t.product_version = vr.version_id
                                                LEFT JOIN ".$this->returnDBPrefix()."list_version vd ON t.closedby_version = vd.version_id

                                                WHERE t.task_id = ?
                                                ", array($this->emptyToNull($task_id)));
        $get_details = $this->dbFetchArray($get_details);
    if (empty($get_details)) {
           $get_details = array();
    }

        $status_id = $get_details['item_status'];
    require("lang/$lang/status.php");
        $tmp_array = array("status_name" => $status_list[$status_id]);
        $get_details = $get_details + $tmp_array;

        $severity_id = $get_details['task_severity'];
    require("lang/$lang/severity.php");
        $tmp_array = array("severity_name" => $severity_list[$severity_id]);
        $get_details = $get_details + $tmp_array;

        $priority_id = $get_details['task_priority'];
    require("lang/$lang/priority.php");
        $tmp_array = array("priority_name" => $priority_list[$priority_id]);
        $get_details = $get_details + $tmp_array;

        return $get_details;
    }

    // Thank you to Mr Lance Conry for this awesome, FAST Jabber message function
    // Check out his company at http://www.rhinosw.com/
    function JabberMessage( $sHost, $sPort, $sUsername, $sPassword, $vTo, $sSubject, $sBody, $sClient='Flyspray' ) {

       if ($sHost != ''
           && $sPort != ''
           && $sUsername != ''
           && $sPassword != ''
           && !empty($vTo)
          ) {

       $sBody = str_replace('&amp;', '&', $sBody);

       $socket = fsockopen ( $sHost, $sPort, $errno, $errstr, 30 );
       if ( !$socket ) {
          return '$errstr (' . $errno . ')';
       } else {

       fputs($socket, '<?xml version="1.0" encoding="UTF-8"?><stream:stream to="' . $sHost . '" xmlns="jabber:client" xmlns:stream="http://etherx.jabber.org/streams">' );
       fgets( $socket, 1 );

       fputs( $socket, '<iq type="set" id="AUTH_01"><query xmlns="jabber:iq:auth"><username>' . $sUsername . '</username><password>' . $sPassword . '</password><resource>' . $sClient . '</resource></query></iq>' );
       fgets( $socket, 1 );

       if ( is_array( $vTo )) {
           foreach ($vTo as $sTo) {
               //fputs ( $socket, '<message to="' . $sTo . '" ><body>' . $sBody . '</body><subject>' . $sSubject . '</subject></message>' );
               fputs ( $socket, '<message to="' . $sTo . '" ><body><![CDATA[' . $sBody . ']]></body><subject><![CDATA[' . $sSubject . ']]></subject></message>' );
           }
        }
        else {
               fputs ( $socket, '<message to="' . $vTo . '" ><body><![CDATA[' . $sBody . ']]></body><subject><![CDATA[' . $sSubject . ']]></subject></message>' );
        }

       fclose ( $socket );
       }

       // End of checking that jabber is set up
       }

       //return TRUE;
    }

    function SendEmail($to, $subject, $message) {
        global $conf_array;
        if (empty($to)){
             //echo "No To: ";
             return;
        } elseif (is_array($to)) {
            $to = implode(",", $to);
        }

        $flyspray_prefs = $this->GetGlobalPrefs();
        require('lang/'.$flyspray_prefs['lang_code'].'/functions.inc.php');
        // $subject = $functions_text['notifyfrom'].' '.$flyspray_prefs['project_title'];
        // $message = nl2br($message); //Convert text new lines to html new lines
        
        $headers = array();
        $headers[] = "Content-Type: text/plain; charset=UTF-8";
        $headers[] = trim('From: '.$conf_array['general']['project_title'].' <'.$flyspray_prefs['admin_email'].'>');
       // We are using Mutt as the user-agent so spamassassin likes us
        $headers[] = "User-Agent: Mutt";
        $headers = implode("\n", $headers);
        require_once($conf_array['general']['phpmailerpath']."class.phpmailer.php");
        require_once($conf_array['general']['phpmailerpath']."class.smtp.php");
        $mail = new PHPMailer();
        //Find out if the message uses HTML or not
        if($message != strip_tags($message)) {
            $mail->IsHTML(true);
        } else {
            $message = str_replace('&amp;', '&', $message);
            $message = $functions_text['autogenerated']."\n".str_repeat('-', 72)."\n\n".$message;
            $message = stripslashes(wordwrap($message, 72));
        }
        $mail->SetLanguage("en", $conf_array['general']['phpmailerpath']."language/");
        $mail->IsSMTP(); //Set mailer to use PHP
        $mail->From     = $flyspray_prefs['admin_email'];
        $mail->FromName = $conf_array['general']['project_title'];
        $mail->Host     = $conf_array['email']['smtphost'];
        $mail->Username = $conf_array['email']['smtpaccount'];
        $mail->Password = $conf_array['email']['smtppassword'];
        $mail->SMTPAuth = $conf_array['email']['smtp_auth'];
        if($conf_array['email']['smtp_tls']) {
            $mail->SMTPSecure = "tls";
        }
        $mail->Mailer   = "smtp";        
        //$mail->IsHTML(true);
        $mail->clearAddresses();
        $mail->AddAddress($to);
        $mail->Subject = $subject;
        $mail->Body = $message;
        if($mail->send()) {
            if($conf_array['sendemaildebug']) {
                echo "Mail succesfully sent to "; print_r($to); echo "<br />";
                echo "<hr /><pre>MAIL OBJECT:<br />\n";
                print_r($mail); 
                echo "</pre>";          
            }
        } else {
            echo "Mail failed to send.";
            echo "<br />\n";
            echo $mail->ErrorInfo;
        }
        /* if (mail($to, $subject, $message, $headers)) {
        } else {
            echo "Mail failed to send!";
        } */
    }

    // This function sends out basic messages at specified times.
    function SendBasicNotification($to, $subject, $message) {
        if (empty($to))
            return "No email address to send to!";

       $flyspray_prefs = $this->GetGlobalPrefs();

       $lang = $flyspray_prefs['lang_code'];
       require("lang/$lang/functions.inc.php");

       $get_user_details = $this->dbQuery("SELECT real_name, jabber_id, email_address, notify_type FROM ".$this->returnDBPrefix()."users WHERE user_id = ?", array($to));
       
       list($real_name, $jabber_id, $email_address, $notify_type) = $this->dbFetchArray($get_user_details);

       // if app preferences say to use jabber, or if the user can (and has) selected jabber
       // and the jabber options are entered in the applications preferences
       if (($flyspray_prefs['user_notify'] == '3')
         OR ($flyspray_prefs['user_notify'] == '1' && $notify_type == '2')
          && $flyspray_prefs['jabber_server'] != ''
          && $flyspray_prefs['jabber_port'] != ''
          && $flyspray_prefs['jabber_username'] != ''
          && $flyspray_prefs['jabber_password'] != ''
          ) {
            $subject = stripslashes($subject);
            $message = stripslashes($message);

            $this->JabberMessage($flyspray_prefs['jabber_server'],
                                 $flyspray_prefs['jabber_port'],
                                 $flyspray_prefs['jabber_username'],
                                 $flyspray_prefs['jabber_password'],
                                 $jabber_id,
                                 //"{$functions_text['notifyfrom']} {$flyspray_prefs['project_title']}",
                                 $subject,
                                 $message,
                                 "OpenCaseTracker"
                                 );
            //return TRUE;

            // if app preferences say to use email, or if the user can (and has) selected email
            } elseif (($flyspray_prefs['user_notify'] == '2') OR ($flyspray_prefs['user_notify'] == '1' && $notify_type == '1')) {
                $sendto = ($email_address) ? $email_address : $to;
                $this->SendEmail($sendto, $subject, $message);
            };
        // End of basic notification function
    }

    // Detailed notification function - generates and passes arrays of recipients
    // These are the additional people who want to be notified of a task changing
    function SendDetailedNotification($task_id, $subject, $message, $initiator=0) {

        $flyspray_prefs = $this->GetGlobalPrefs();
        $lang = $flyspray_prefs['lang_code'];
        require("lang/$lang/functions.inc.php");

        $jabber_users = array();
        $email_users = array();

        $get_users = $this->dbQuery("SELECT user_id FROM ".$this->returnDBPrefix()."notifications WHERE task_id = ? AND user_id != ?", array($task_id, $initiator));

        while ($row = $this->dbFetchArray($get_users)) {

            $get_details = $this->dbQuery("SELECT notify_type, jabber_id, email_address
                    FROM ".$this->returnDBPrefix()."users
                    WHERE user_id = ?",
                    array($row['user_id']));
            while ($subrow = $this->dbFetchArray($get_details)) {

                if (($flyspray_prefs['user_notify'] == '1' && $subrow['notify_type'] == '1')
                        OR ($flyspray_prefs['user_notify'] == '2')) {
                    array_push($email_users, $subrow['email_address']);
                } elseif (($flyspray_prefs['user_notify'] == '1' && $subrow['notify_type'] == '2')
                        OR ($flyspray_prefs['user_notify'] == '3')) {
                    array_push($jabber_users, $subrow['jabber_id']);
                };
            };
        };
        $subject = stripslashes($subject);
        $message = stripslashes($message);

        // Pass the recipients and message onto the Jabber Message function
        $this->JabberMessage($flyspray_prefs['jabber_server'],
                             $flyspray_prefs['jabber_port'],
                             $flyspray_prefs['jabber_username'],
                             $flyspray_prefs['jabber_password'],
                             $jabber_users,
                             //"{$functions_text['notifyfrom']} {$flyspray_prefs['project_title']}",
                             $subject,
                             $message,
                             "OpenCaseTracker"
                             );
        // Pass the recipients and message onto the mass email function
        $this->SendEmail($email_users, $subject, $message);
        return TRUE;
        // End of detailed notification function
    }

    // This function generates a query of users for the "Assigned To" list
    function listUsers($current) {
     $flyspray_prefs = $this->getGlobalPrefs();

      $these_groups = explode(" ", $flyspray_prefs['assigned_groups']);
      while (list($key, $val) = each($these_groups)) {
        if (empty($val))
          continue;
        $group_details = $this->dbFetchArray($this->dbQuery("SELECT group_name FROM ".$this->returnDBPrefix()."groups WHERE group_id = ?", array($val)));

        echo "<optgroup label=\"{$group_details['group_name']}\">\n";

        $user_query = $this->dbQuery("SELECT * FROM ".$this->returnDBPrefix()."users WHERE account_enabled = ? AND group_in = ? ORDER BY real_name", array('1', $val));

        while ($row = $this->dbFetchArray($user_query)) {
          if ($current == $row['user_id']) {
            echo "<option value=\"{$row['user_id']}\" SELECTED>{$row['real_name']}</option>\n";
          } else {
            echo "<option value=\"{$row['user_id']}\">{$row['real_name']}</option>\n";
          };
        };

        echo "</optgroup>\n";
      };

  }

    // This provides funky page numbering
    // Thanks to Nathan Fritz for this.  http://www.netflint.net/
    function pagenums($pagenum, $perpage, $pagesper, $totalcount, $extraurl) {
    $flyspray_prefs = $this->GetGlobalPrefs();
    $lang = $flyspray_prefs['lang_code'];
    require("lang/$lang/functions.inc.php");

    if (!($totalcount / $perpage <= 1)) {

        if ($pagenum - 1000 >= 0) $output .= "<a href=\"?pagenum=" . ($pagenum - 1000) . $extraurl . "\">{$functions_text['back']} 1,000</a> - ";
        if ($pagenum - 100 >= 0) $output .= "<a href=\"?pagenum=" . ($pagenum - 100) . $extraurl . "\">{$functions_text['back']} 100</a> - ";
        if ($pagenum - 10 >= 0) $output .= "<a href=\"?pagenum=" . ($pagenum - 10) . $extraurl . "\">{$functions_text['back']} 10</a> - ";
        if ($pagenum - 1 >= 0) $output .= "<a href=\"?pagenum=" . ($pagenum - 1) . $extraurl . "\">{$functions_text['back']}</a> - ";
        $start = floor($pagenum - ($pagesper / 2)) + 1;
        if ($start <= 0) $start = 0;
        $finish = $pagenum + ceil($pagesper / 2);
        if ($finish >= $totalcount / $perpage) $finish = floor($totalcount / $perpage);
        for ($pagelink = $start; $pagelink <= $finish;  $pagelink++)
        {
            if ($pagelink != $start) $output .= " - ";
            if ($pagelink == $pagenum) {
                $output .= "<a href=\"?pagenum=" . ($pagelink) . "$extraurl\"><b>" . ($pagelink + 1) . "</b></a>";
            } else {
                $output .= "<a href=\"?pagenum=" . ($pagelink) . "$extraurl\">" . ($pagelink + 1) . "</a>";
            }
        }
        if ($pagenum + 1 < $totalcount / $perpage) $output .= " - <a href=\"?pagenum=" . ($pagenum + 1) . $extraurl . "\">{$functions_text['forward']}</a> ";
        if ($pagenum + 10 < $totalcount / $perpage) $output .= " - <a href=\"?pagenum=" . ($pagenum + 10) . $extraurl . "\">{$functions_text['forward']} 10</a> ";
        if ($pagenum + 100 < $totalcount / $perpage) $output .= " - <a href=\"?pagenum=" . ($pagenum + 100) . $extraurl . "\">{$functions_text['forward']} 100</a> ";
        if ($pagenum + 1000 < $totalcount / $perpage) $output .= " - <a href=\"?pagenum=" . ($pagenum + 1000) . $extraurl . "\">{$functions_text['forward']} 1,000</a> ";
        return $output;
    }
}

    function formatDate($timestamp, $extended) {
        $dateformat = '';
        $format_id = $extended ? "dateformat_extended" : "dateformat";

        if(isset($_SESSION['userid']))
        {
            $get_user_details = $this->dbQuery("SELECT {$format_id} FROM ".$this->returnDBPrefix()."users WHERE user_id = " . $_SESSION['userid']);
            $user_details = $this->dbFetchArray($get_user_details);
            $dateformat = $user_details[$format_id];
        }

        if($dateformat == '')
        {
            $flyspray_prefs = $this->GetGlobalPrefs();
            $dateformat = $flyspray_prefs[$format_id];
        }

        if($dateformat == '')
            $dateformat = $extended ? "l, j M Y, g:ia" : "Y-m-j";

        return date($dateformat, $timestamp);
    }

    function lastEvent($task) {
        $result = $this->dbQuery("SELECT * FROM ".$this->returnDBPrefix()."history
                                  WHERE task_id = ?
                                  ORDER BY event_date DESC
                                  LIMIT 2",
                                  array($task));
        if ($this->dbCountRows($result) > 0) {
            while ($row = $this->dbFetchArray($result)) {
              $output[]=$row;
            }
        } else {
            $output[]=array("event_type" => 99, "event_date" => time());
        }
        return $output;
    }

    function logEvent($task, $type, $newvalue = '', $oldvalue = '', $field = '') {
        if ($field == "date_due") {
            $newvalue = date("d M Y", $newvalue);
            $oldvalue = date("d M Y", $oldvalue);
        }
        $this->dbQuery("INSERT INTO ".$this->returnDBPrefix()."history (task_id, user_id, event_date, event_type, field_changed, old_value, new_value)
                          VALUES(?, ?, ?, ?, ?, ?, ?)",
                          array($task, $this->emptyToZero($_SESSION['userid']), date(U), $type, $field, $oldvalue, $newvalue));
    }

    function LinkedUsername($user_id) {
        $result = $this->dbQuery("SELECT user_name, real_name FROM ".$this->returnDBPrefix()."users WHERE user_id = ?", array($user_id));
        if ($this->dbCountRows($result) == 0) return '';
        $result = $this->dbFetchRow($result);
        return "<a href=\"?do=admin&amp;area=users&amp;id={$user_id}\">{$result['real_name']} ({$result['user_name']})</a>";
    }

    function dirList ($directory) {

        // create an array to hold directory list
        $results = array();

        // create a handler for the directory
        $handler = opendir($directory);

        // keep going until all files in directory have been read
        while ($file = readdir($handler)) {

            // if $file isn't this directory or its parent,
            // add it to the results array
            if ($file != '.' && $file != '..')
                $results[] = $file;
        }

        // tidy up: close the handler
        closedir($handler);

        // done!
        return $results;

    }

    function historyDetails($history, $newvalue, $oldvalue) {
          //Create an event description
      if ($history['event_type'] == 0) {            //Field changed

          $field = $history['field_changed'];

          switch ($field) {
          case 'item_summary':
              $field = $details_text['summary'];
              $oldvalue = htmlspecialchars($oldvalue);
              $newvalue = htmlspecialchars($newvalue);
              if (!get_magic_quotes_gpc()) {
                $oldvalue = str_replace("\\", "&#92;", $oldvalue);
                $newvalue = str_replace("\\", "&#92;", $newvalue);
              };
              $oldvalue = stripslashes($oldvalue);
              $newvalue = stripslashes($newvalue);
              break;
          case 'attached_to_project':
              $field = $details_text['attachedtoproject'];
              list($oldprojecttitle) = $fs->dbFetchRow($fs->dbQuery("SELECT project_title FROM ".$this->returnDBPrefix()."projects WHERE project_id = ?", array($oldvalue)));
              list($newprojecttitle) = $fs->dbFetchRow($fs->dbQuery("SELECT project_title FROM ".$this->returnDBPrefix()."projects WHERE project_id = ?", array($newvalue)));
              $oldvalue = "<a href=\"?project={$oldvalue}\">{$oldprojecttitle}</a>";
              $newvalue = "<a href=\"?project={$newvalue}\">{$newprojecttitle}</a>";
              break;
          case 'task_type':
              $field = $details_text['tasktype'];
              list($oldvalue) = $fs->dbFetchRow($fs->dbQuery("SELECT tasktype_name FROM ".$this->returnDBPrefix()."list_tasktype WHERE tasktype_id = ?", array($oldvalue)));
              list($newvalue) = $fs->dbFetchRow($fs->dbQuery("SELECT tasktype_name FROM ".$this->returnDBPrefix()."list_tasktype WHERE tasktype_id = ?", array($newvalue)));
              break;
          case 'product_category':
              $field = $details_text['category'];
              list($oldvalue) = $fs->dbFetchRow($fs->dbQuery("SELECT category_name FROM ".$this->returnDBPrefix()."list_category WHERE category_id = ?", array($oldvalue)));
              list($newvalue) = $fs->dbFetchRow($fs->dbQuery("SELECT category_name FROM ".$this->returnDBPrefix()."list_category WHERE category_id = ?", array($newvalue)));
              break;
          case 'item_status':
              $field = $details_text['status'];
              $oldvalue = $status_list[$oldvalue];
              $newvalue = $status_list[$newvalue];
              break;
          case 'task_priority':
              $field = $details_text['priority'];
              $oldvalue = $priority_list[$oldvalue];
              $newvalue = $priority_list[$newvalue];
              break;
          case 'operating_system':
              $field = $details_text['operatingsystem'];
              list($oldvalue) = $this->dbFetchRow($this->dbQuery("SELECT os_name FROM ".$this->returnDBPrefix()."list_os WHERE os_id = ?", array($oldvalue)));
              list($newvalue) = $this->dbFetchRow($this->dbQuery("SELECT os_name FROM ".$this->returnDBPrefix()."list_os WHERE os_id = ?", array($newvalue)));
              break;
          case 'task_severity':
              $field = $details_text['severity'];
              $oldvalue = $severity_list[$oldvalue];
              $newvalue = $severity_list[$newvalue];
              break;
          case 'product_version':
              $field = $details_text['reportedversion'];
              list($oldvalue) = $this->dbFetchRow($this->dbQuery("SELECT version_name FROM ".$this->returnDBPrefix()."list_version WHERE version_id = ?", array($oldvalue)));
              list($newvalue) = $this->dbFetchRow($this->dbQuery("SELECT version_name FROM ".$this->returnDBPrefix()."list_version WHERE version_id = ?", array($newvalue)));
              break;
          case 'closedby_version':
              $field = $details_text['dueinversion'];
              if ($oldvalue == '0') {
                  $oldvalue = $details_text['undecided'];
              } else {
                  list($oldvalue) = $this->dbFetchRow($this->dbQuery("SELECT version_name
                                                                    FROM ".$this->returnDBPrefix()."list_version
                                                                    WHERE version_id = ?", array($fs->emptyToZero($oldvalue))));
              };
              if ($newvalue == '0') {
                  $newvalue = $details_text['undecided'];
              } else {
                  list($newvalue) = $this->dbFetchRow($this->dbQuery("SELECT version_name
                                                                    FROM ".$this->returnDBPrefix()."list_version
                                                                    WHERE version_id = ?", array($fs->emptyToZero($newvalue))));
              };
              break;
          case 'percent_complete':
              $field = $details_text['percentcomplete'];
              $oldvalue .= '%';
              $newvalue .= '%';
              break;
          case 'detailed_desc':
              $field = "<a href=\"index.php?do=details&amp;id={$history['task_id']}&amp;area=history&amp;details={$history['history_id']}#tabs\">{$details_text['details']}</a>";
              if ($details != '') {
                  $details_previous = htmlspecialchars($oldvalue);
                  $details_new = htmlspecialchars($newvalue);
                  if (!get_magic_quotes_gpc()) {
                    $details_previous = str_replace("\\", "&#92;", $details_previous);
                    $details_new = str_replace("\\", "&#92;", $details_new);
                  };
                  $details_previous = nl2br(stripslashes($details_previous));
                  $details_new = nl2br(stripslashes($details_new));
              };
              $oldvalue = '';
              $newvalue = '';
              break;
          };

          echo "{$details_text['fieldchanged']}: {$field}";
          if ($oldvalue != '' || $newvalue != '') {
              echo " ({$oldvalue} &rarr; {$newvalue})";
          };

          } elseif ($history['event_type'] == 1) {      //Task opened
              echo $details_text['taskopened'];

          } elseif ($history['event_type'] == 2) {      //Task closed
              echo $details_text['taskclosed'];
              $res_name = $fs->dbFetchRow($fs->dbQuery("SELECT resolution_name FROM ".$this->returnDBPrefix()."list_resolution WHERE resolution_id = ?", array($newvalue)));
              echo " ({$res_name['resolution_name']}";
              if ($oldvalue != '') {
                  echo ": {$oldvalue}";
              }
              echo ')';

          } elseif ($history['event_type'] == 3) {      //Task edited
              echo $details_text['taskedited'];

          } elseif ($history['event_type'] == 4) {      //Comment added
              echo "<a href=\"?do=details&amp;id={$history['task_id']}&amp;area=comments#{$newvalue}\">{$details_text['commentadded']}</a>";

          } elseif ($history['event_type'] == 5) {      //Comment edited
              echo "<a href=\"?do=details&amp;id={$history['task_id']}&amp;area=history&amp;details={$history['history_id']}#tabs\">{$details_text['commentedited']}</a>";
              $comment = $fs->dbQuery("SELECT user_id, date_added FROM ".$this->returnDBPrefix()."comments WHERE comment_id = ?", array($history['field_changed']));
              if ($fs->dbCountRows($comment) != 0) {
                  $comment = $fs->dbFetchRow($comment);
                  echo " ({$details_text['commentby']} " . $fs->LinkedUsername($comment['user_id']) . " - " . $fs->formatDate($comment['date_added'], true) . ")";
              };
              if ($details != '') {
                  $details_previous = htmlspecialchars($oldvalue);
                  $details_new = htmlspecialchars($newvalue);
                  if (!get_magic_quotes_gpc()) {
                    $details_previous = str_replace("\\", "&#92;", $details_previous);
                    $details_new = str_replace("\\", "&#92;", $details_new);
                  };
                  $details_previous = nl2br(stripslashes($details_previous));
                  $details_new = nl2br(stripslashes($details_new));
              };

          } elseif ($history['event_type'] == 6) {      //Comment deleted
              echo "<a href=\"?do=details&amp;id={$history['task_id']}&amp;area=history&amp;details={$history['history_id']}#tabs\">{$details_text['commentdeleted']}</a>";
              if ($newvalue != '' && $history['field_changed'] != '') {
                  echo " ({$details_text['commentby']} " . $fs->LinkedUsername($newvalue) . " - " . $fs->formatDate($history['field_changed'], true) . ")";
              };
              if ($details != '') {
                  $details_previous = htmlspecialchars($oldvalue);
                  if (!get_magic_quotes_gpc()) {
                    $details_previous = str_replace("\\", "&#92;", $details_previous);
                  };
                  $details_previous = nl2br(stripslashes($details_previous));
                  $details_new = '';
              };

          } elseif ($history['event_type'] == 7) {      //Attachment added
              echo $details_text['attachmentadded'];
              $attachment = $fs->dbQuery("SELECT orig_name, file_desc FROM ".$this->returnDBPrefix()."attachments WHERE attachment_id = ?", array($newvalue));
              if ($fs->dbCountRows($attachment) != 0) {
                  $attachment = $fs->dbFetchRow($attachment);
                  echo ": <a href=\"?getfile={$newvalue}\">{$attachment['orig_name']}</a>";
                  if ($attachment['file_desc'] != '') {
                      echo " ({$attachment['file_desc']})";
                  };
              };

          } elseif ($history['event_type'] == 8) {      //Attachment deleted
              echo "{$details_text['attachmentdeleted']}: {$newvalue}";

          } elseif ($history['event_type'] == 9) {      //Notification added
              echo "{$details_text['notificationadded']}: " . $fs->LinkedUsername($newvalue);

          } elseif ($history['event_type'] == 10) {      //Notification deleted
              echo "{$details_text['notificationdeleted']}: " . $fs->LinkedUsername($newvalue);

          } elseif ($history['event_type'] == 11) {      //Related task added
              list($related) = $fs->dbFetchRow($fs->dbQuery("SELECT item_summary FROM ".$this->returnDBPrefix()."tasks WHERE task_id = ?", array($newvalue)));
              echo "{$details_text['relatedadded']}: {$details_text['task']} #{$newvalue} &mdash; <a href=\"?do=details&amp;id={$newvalue}\">{$related}</a>";

          } elseif ($history['event_type'] == 12) {      //Related task deleted
              list($related) = $fs->dbFetchRow($fs->dbQuery("SELECT item_summary FROM ".$this->returnDBPrefix()."tasks WHERE task_id = ?", array($newvalue)));
              echo "{$details_text['relateddeleted']}: {$details_text['task']} #{$newvalue} &mdash; <a href=\"?do=details&amp;id={$newvalue}\">{$related}</a>";

          } elseif ($history['event_type'] == 13) {      //Task reopened
              echo $details_text['taskreopened'];

          } elseif ($history['event_type'] == 14) {      //Task assigned
              if ($oldvalue == '0') {
                  echo "{$details_text['taskassigned']} " . $fs->LinkedUsername($newvalue);
              } elseif ($newvalue == '0') {
                  echo $details_text['assignmentremoved'];
              } else {
                  echo "{$details_text['taskreassigned']} " . $fs->LinkedUsername($newvalue);
              };
          } elseif ($history['event_type'] == 15) {      //Task added to related list of another task
              list($related) = $fs->dbFetchRow($fs->dbQuery("SELECT item_summary FROM ".$this->returnDBPrefix()."tasks WHERE task_id = ?", array($newvalue)));
              echo "{$details_text['addedasrelated']} {$details_text['task']} #{$newvalue} &mdash; <a href=\"?do=details&amp;id={$newvalue}\">{$related}</a>";

          } elseif ($history['event_type'] == 16) {      //Task deleted from related list of another task
              list($related) = $fs->dbFetchRow($fs->dbQuery("SELECT item_summary FROM ".$this->returnDBPrefix()."tasks WHERE task_id = ?", array($newvalue)));
              echo "{$details_text['deletedasrelated']} {$details_text['task']} #{$newvalue} &mdash; <a href=\"?do=details&amp;id={$newvalue}\">{$related}</a>";

          } elseif ($history['event_type'] == 17) {      //Reminder added
              echo "{$details_text['reminderadded']}: " . $fs->LinkedUsername($newvalue);

          } elseif ($history['event_type'] == 18) {      //Reminder deleted
              echo "{$details_text['reminderdeleted']}: " . $fs->LinkedUsername($newvalue);
          } elseif ($history['event_type'] == 19) {      //Servant added
        echo "{$details_text['servantadded']}: {$details_text['task']} #{$newvalue} &mdash; <a href=\"?do=details&amp;id={$newvalue}\">{$related}</a>";
    } elseif ($history['event_type'] == 20) {      //Servant removed
        echo "{$details_text['servantremoved']}: {$details_text['task']} #{$newvalue} &mdash; <a href=\"?do=details&amp;id={$newvalue}\">{$related}</a>";
    } elseif ($history['event_type'] == 21) {      //Made servant of
        echo "{$details_text['madeservant']}: {$details_text['task']} #{$newvalue} &mdash; <a href=\"?do=details&amp;id={$newvalue}\">{$related}</a>";
    } elseif ($history['event_type'] == 22) {      // Servant status removed
        echo "{$details_text['masterremoved']}: {$details_text['task']} #{$newvalue} &mdash; <a href=\"?do=details&amp;id={$newvalue}\">{$related}</a>";
    } elseif ($history['event_type'] == 23) {
        echo "{$details_text['strategyadded']}: $newvalue";
    } elseif ($history['event_type'] == 24) {
        echo "{$details_text['strategydeleted']}: $oldvalue";
    } elseif ($history['event_type'] == 25) {
        echo "{$details_text['strategyread']}: ";
    } elseif ($history['event_type'] == 26) { //Companion Task Added
              list($related) = $fs->dbFetchRow($fs->dbQuery("SELECT item_summary FROM ".$this->returnDBPrefix()."tasks WHERE task_id = ?", array($newvalue)));
              echo "{$details_text['companionadded']}: {$details_text['task']} #{$newvalue} &mdash; <a href=\"?do=details&amp;id={$newvalue}\">{$related}</a>";
    } elseif ($history['event_type'] == 27) { //Companion Task Removed
              list($related) = $fs->dbFetchRow($fs->dbQuery("SELECT item_summary FROM ".$this->returnDBPrefix()."tasks WHERE task_id = ?", array($newvalue)));
              echo "{$details_text['companiondeleted']}: {$details_text['task']} #{$newvalue} &mdash; <a href=\"?do=details&amp;id={$newvalue}\">{$related}</a>";
    } elseif ($history['event_type'] == 28) {      //Task added to companion list of another task
              list($related) = $fs->dbFetchRow($fs->dbQuery("SELECT item_summary FROM ".$this->returnDBPrefix()."tasks WHERE task_id = ?", array($newvalue)));
              echo "{$details_text['addedascompanion']} {$details_text['task']} #{$newvalue} &mdash; <a href=\"?do=details&amp;id={$newvalue}\">{$related}</a>";
    } elseif ($history['event_type'] == 29) {      //Task deleted from companion list of another task
              list($related) = $fs->dbFetchRow($fs->dbQuery("SELECT item_summary FROM ".$this->returnDBPrefix()."tasks WHERE task_id = ?", array($newvalue)));
              echo "{$details_text['deletedascompanion']} {$details_text['task']} #{$newvalue} &mdash; <a href=\"?do=details&amp;id={$newvalue}\">{$related}</a>";

    }
 }

    /**
    * niceDateFromSybase manually extracts a date in the YYYY-MM-DD HH:MM:SS format and returns it in your preferred model
    * 
    * @param mixed $thedate  A date in Sybase format
    * @param mixed $format Manner in which you want it returned (from PHP date function) - defaults to d M Y
    * 
    * @return string containing date in requested format
    */
    function niceDateFromSybase($thedate, $format="d M Y") {
        if (empty($thedate)) {
            return "";
        }
         list($dte, $time) = explode(" ", $thedate);
        list($year, $month, $day)=explode("-", $dte);
        list($hour, $minute, $seconds)=explode(":", $time);
        list($second, $micros)=explode(".", $seconds);
        //return "$day $month $year $hour $minute $second";
        $output=mktime($hour, $minute, $second, $month, $day, $year);
        if (@$return=date($format, $output)) {
            return $return;
        } else {
            return "$day/$month/$year";
        }
    }

    /**
    * Takes a date in standard Sybase format and converts it to a nicer more readable format
    * 
    * @param mixed $date - Sybase formatted date (DD-Mmm-YY HH:MM:SS, 17-Nov-13 13:25:55)
    * 
    * Output - "d M YYYY"
    */
    function niceSYBdate($date) {        
        $smaller=trim(substr($date, 0, 10));
        list($year, $month, $day) = explode("-", $smaller);
        $utime=mktime(0, 0, 0, $month, $day, 1990);
        $nicedate = date("d M", $utime);
        $nicedate .= " $year";
        return $nicedate;
    }       

    /**
    * Opens a template file
    * 
    * @param mixed $location
    * 
    * @returns array containing ($template The contents of the template file,
    *                            $imagefiles A keyed array containing a list of png files in directory [filename]=>[filename.ext]
    *                            $imagedir The location of the images)
    */
    function openEmailTemplate($location) {
        /*
        *
        * OPEN THE ADMINISTRATOR TEMPLATE 
        * 
        */
        global $project_prefs, $basedir;
        if(file_exists($basedir."/themes/".$project_prefs['theme_style']."/emailtemplates/".$location."/".$lang.".html")) {
            $template_file=$basedir."/themes/".$project_prefs['theme_style']."/emailtemplates/".$location."/".$lang.".html";
            $imagedir=$basedir.'/themes/'.$project_prefs['theme_style'].'/emailtemplates/'.$location;
        } else {
            //if all else fails, use the standard
            $template_file=$basedir."/themes/Default/emailtemplates/".$location."/en.html";
            $imagedir=$basedir.'/themes/Default/emailtemplates/'.$location;
        }
        /* FIND ANY *.png FILES IN THE DIRECTORY AND ADD THEM AS INLINE ATTACHMENTS */
        $imagefiles=array();
        if($handle = opendir($imagedir)) {
            while (false !== ($entry=readdir($handle))) {
                if(substr($entry, -4) == ".png") {
                    $filename=substr($entry, 0, -4);
                    $imagefiles[$filename]=$entry;    
                }
            }
        }
        //Now read the file
        $openfile=file_get_contents($template_file);
        
        return array($openfile, $imagefiles, $imagedir);
        /*
         *
         * END OF TEMPLATE
         * 
         */        
    } 
    
    /**
    * getCustomText returns single custom text matching value $action(if it exists)
    * 
    * @param mixed $action
    */
    function getCustomText($action) {
        global $project_prefs;
        $output="";
        $return = $this->dbFetchArray(
                    $this->dbQuery(
                        "SELECT custom_text FROM ".
                            $this->returnDBPrefix().
                            "custom_texts WHERE modify_action = ?", 
                            array($action)
                        )
                    );
        if(!empty($return['custom_text'])) {
            $output = stripslashes($return['custom_text']);
        }
        return $output;
        
    }
    /**
    * getCustomTexts returns all custom texts matching $action(if it exists)
    * 
    * @param mixed $action
    */
    function getCustomTexts($action="%") {
        global $project_prefs;
        $output="";
        $return = 
                    $this->dbQuery(
                        "SELECT * FROM ".
                            $this->returnDBPrefix().
                            "custom_texts WHERE modify_action LIKE ? ORDER BY modify_action", 
                            array($action)
                        );
        while($row=$this->dbFetchArray($return)) {
            $output[]=$row;
        }
        return $output;
    }
    
    /**
    * This function simply contains an array of the action/names of
    * all actions where the custom text has been enabled
    *     
    */
    function customTextOptions() {
        return array(
            "taskclosed",        
        );
    }
    
    function usedCustomTextOptions() {
        $return = $this->dbQuery("SELECT modify_action FROM ".
                            $this->returnDBPrefix().
                            "custom_texts ORDER BY modify_action");
        $output=array();
        while($row=$this->dbFetchArray($return)) {
            $output[]=$row['modify_action'];
        }
        return $output;
    }

    function getLanguages() {
        // Let's get a list of the available languages by reading the ./lang/ directory.
        if ($handle = opendir('lang/')) {
            $lang_array = array();
            while (false !== ($file = readdir($handle))) {
                if ($file != "." && $file != ".." && file_exists("lang/$file/main.php")) {
                    array_push($lang_array, $file);
                }
            }
            closedir($handle);
        }

        // Sort the array alphabetically
        sort($lang_array);
        // Then display them
        while (list($key, $val) = each($lang_array)) {
            
        };
        return $lang_array;

    }
}  // END OF OCT CLASS

?>
