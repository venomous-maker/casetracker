<?php
// As of 24 July 2004, all editable config is stored in flyspray.conf.php
// There should be no reason to edit this file anymore, except if you
// move flyspray.conf.php to a directory where a browser can't access it.
// (RECOMMENDED)

// You might like to uncomment the next line if you are receiving lots of
// PPHP NOTICE errors
//error_reporting(E_ALL & -E_NOTICE);
// Load the config file
error_reporting(0);
$version = "2.131015";

$conf_array = @parse_ini_file("casetracker.conf.php", true);

/* Setup alternate db name if doing db setup testing */
if(isset($_GET['testdb']) && $_GET['testdb'] != "") {
	$dbname=$_GET['testdb'];
}

//print_r($conf_array);
//$conf_array = array_merge($conf_array,
//	      @parse_ini_file("../casetracker.conf.php", true));
// Set values from the config file. Once these settings are loaded a connection
// is made to the database to retrieve all the other preferences.
if(isset($conf_array['general']['defaulttimezone'])) {date_default_timezone_set($conf_array['general']['defaulttimezone']);}
$basedir     = $conf_array['general']['basedir'];
$attachdir   = $conf_array['general']['attachmentdir'];
$dbprefix    = $conf_array['general']['dbprefix'];
$adodbpath   = $conf_array['general']['adodbpath'];
$jpgraphpath = $conf_array['general']['jpgraphpath'];
$phpmailerpath=$conf_array['general']['phpmailerpath'];
$cookiesalt  = $conf_array['general']['cookiesalt'];
$baseproject = $conf_array['general']['baseproject'];
$dbtype      = $conf_array['database']['dbtype'];
$dbhost      = $conf_array['database']['dbhost'];
$dbname      = !isset($dbname) ? $conf_array['database']['dbname'] : $dbname;
$dbuser      = $conf_array['database']['dbuser'];
$dbpass      = $conf_array['database']['dbpass'];
$mustodbcdsn = $conf_array['must']['mustodbcdsn'];
$external_db = isset($conf_array['must']['externaldb']) ? $conf_array['must']['externaldb'] : "must";
$mustdbtype  = $conf_array['must']['mustdbtype'];
$mustdbname  = $conf_array['must']['mustdbname'];
$mustdbuser  = $conf_array['must']['mustdbuser'];
$mustdbpass  = $conf_array['must']['mustdbpass'];
$cookieprefix= $conf_array['general']['cookieprefix'];
$jpgraphdir  = $conf_array['jpgraph']['jpgraphdir'];
$notgroups   = explode(",", $conf_array['notifications']['groups']);
$notproject  = $conf_array['notifications']['project'];
$noturl		 = $conf_array['notifications']['url'];
$notfrom	 = $conf_array['notifications']['from'];
$notgroupex  = explode (",", $conf_array['notifications']['admingroupexclude']);
$usemust     = $conf_array['must']['usemust'];
$phoneclose  = isset($conf_array['general']['defaultphoneclosureid']) ? $conf_array['general']['defaultphoneclosureid'] : 7;

include_once ( "$adodbpath" );

// You might like to uncomment the next line if you are receiving lots of
// PPHP NOTICE errors
//error_reporting(E_ALL ^ -E_NOTICE && ~E_STRICT);

require ( "$basedir/functions.inc.php" );
require ( "$basedir/classes/external_db/".$external_db.".php");
require ( "$basedir/regexp.php" );
// Check PHP Version (Must Be > 4.2)
if (PHP_VERSION  < '4.2.0') {
	die('Your version of PHP is not compatible with Casetracker, please upgrade to the latest version of PHP.  Casetracker requires at least PHP version 4.2.0');
};

session_start();

//Create the main CaseTracker object ($fs, named after the original $flyspray object)
$fs = new CaseTracker;

/* Check if database is current or even exists */
$db = NewADOConnection($dbtype);
$db->close();
/* End of checking if database exists */

$res = $fs->dbOpen($dbhost, $dbuser, $dbpass, $dbname, $dbtype);

if (!$res) {
  die("Database disconnected");
}
$ddict=($dbtype=="pgsql") ? "postgres" : $dbtype;
$dict = NewDataDictionary($fs->dblink, $ddict);
$tablelist=$dict->MetaTables();

if(isset($_GET{'systemupdate'}) &&  $_SESSION['admin'] == "1") {
    include("install/install.php");
    $db->close();
    die();
}

if(empty($tablelist) || (isset($_GET['dbsetup']) && $_GET['dbsetup']=="true")) {
	//This means that the database exists but is empty!
	include("install/install.php");
	$db->close();
	die();
}

//Connect to external database if setting is true (called "Must" after first external database used)
if($conf_array['must']['usemust']) {
	$must = $fs->odbcOpen($mustodbcdsn, $mustdbuser, $mustdbpass);
	if (!$must) {
	die("Must database disconnected");
	}
	$_SESSION['externaldb']=true;
} else {
    $_SESSION['externaldb']=false;
	$must = false;
}

$flyspray_prefs = $fs->getGlobalPrefs();

if(!isset($flyspray_prefs['version']) || $flyspray_prefs['version'] != $version) {
    $updateavailable=true;
}

if (isset($_SESSION['userid']) && !$_SESSION['userid']) {
	echo "PANIC!";
	$_SESSION['userid'] = $conf_array['general']['panicuser'];
}
if(!empty($_SESSION['userid'])) {
$user_prefs = $fs->getUserPrefs($_SESSION['userid']);
}
if(empty($user_prefs)) {unset ($user_prefs);}
//echo $_SESSION['userid'];
//print_r($user_prefs);
if (!empty($user_prefs['default_task_view']) && empty($_GET['tasks'])) {
    $_GET['tasks'] = $user_prefs['default_task_view'];
}

$project_id = $conf_array['general']['baseproject'];
if (isset($_GET['do']) && ($_GET['do'] == 'details') && (isset($_GET['id']))) {
  $ref1=$fs->dbQuery("SELECT attached_to_project FROM ".$fs->returnDBPrefix()."tasks WHERE task_id = {$_GET['id']}");
  list($project_id) = $fs->dbFetchArray($ref1);
};
if (!$project_id) {
  if ($_GET['project']) {
    $project_id = $_GET['project'];
    setcookie("{$cookieprefix}_project", $_GET['project'], time()+60*60*24*30, "/");
  } elseif ($_COOKIE["{$cookieprefix}_project"]) {
    $project_id = $_COOKIE["{$cookieprefix}_project"];
  } else {
    $project_id = $flyspray_prefs['default_project'];
    setcookie("{$cookieprefix}_project", $flyspray_prefs['default_project'], time()+60*60*24*30, "/");
  };
};

if (!(preg_match ("/^(upgrade)$/", $_SERVER['PHP_SELF']))) {
  $project_prefs = $fs->getProjectPrefs($project_id);
};

////////////////////////////////////////////////////////////////
//    MOBILE DEVICE DETECTION     //////////////////////////////
////////////////////////////////////////////////////////////////
$mobile_browser = '0';

if(preg_match('/(up.browser|up.link|mmp|symbian|smartphone|midp|wap|phone)/i', strtolower($_SERVER['HTTP_USER_AGENT']))) {
    $mobile_browser++;
}

if((strpos(strtolower($_SERVER['HTTP_ACCEPT']),'application/vnd.wap.xhtml+xml')>0) or ((isset($_SERVER['HTTP_X_WAP_PROFILE']) or isset($_SERVER['HTTP_PROFILE'])))) {
    $mobile_browser++;
}

$mobile_ua = strtolower(substr($_SERVER['HTTP_USER_AGENT'],0,4));
$mobile_agents = array(
    'w3c ','acs-','alav','alca','amoi','audi','avan','benq','bird','blac',
    'blaz','brew','cell','cldc','cmd-','dang','doco','eric','hipt','inno',
    'ipaq','java','jigs','kddi','keji','leno','lg-c','lg-d','lg-g','lge-',
    'maui','maxo','midp','mits','mmef','mobi','mot-','moto','mwbp','nec-',
    'newt','noki','oper','palm','pana','pant','phil','play','port','prox',
    'qwap','sage','sams','sany','sch-','sec-','send','seri','sgh-','shar',
    'sie-','siem','smal','smar','sony','sph-','symb','t-mo','teli','tim-',
    'tosh','tsm-','upg1','upsi','vk-v','voda','wap-','wapa','wapi','wapp',
    'wapr','webc','winw','winw','xda','xda-');

if(in_array($mobile_ua,$mobile_agents)) {
    $mobile_browser++;
}

if (strpos(strtolower(@$_SERVER['ALL_HTTP']),'OperaMini')>0) {
    $mobile_browser++;
}

if (strpos(strtolower($_SERVER['HTTP_USER_AGENT']),'windows')>0) {
    $mobile_browser=0;
}

if($mobile_browser>0) {
   // do something
	$cssfile="mobile.css";
	$mobile=true;
}
else {
   // do something else
	$cssfile="theme.css";
	$mobile=false;
}
if(isset($_GET['mobile']) && $_GET['mobile'] == "true") {
	$cssfile="mobile.css";
	$mobile=true;
}

//////////////////////////////////////////////////////////
//    END MOBILE DEVICE DETECTION     ////////////////////
//////////////////////////////////////////////////////////

?>