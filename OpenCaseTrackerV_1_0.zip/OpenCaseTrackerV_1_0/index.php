<?php
include('header.php');
$lang = $flyspray_prefs['lang_code'];
get_language_pack($lang, 'main');

if(isset($_GET['id'])) {$tasknumber="Case #".$_GET['id'];} else {$tasknumber="";}


//////////////////////////////////////////////////////////////////////////////////////////////
// If a file was requested, deliver it
//////////////////////////////////////////////////////////////////////////////////////////////
if (isset($_GET['getfile'])) {

    list($orig_name, $file_name, $file_type) = $fs->dbFetchArray(
                                $fs->dbQuery("SELECT orig_name,
                                              file_name,
                                              file_type
                                              FROM ".$fs->returnDBPrefix()."attachments
                                              WHERE attachment_id = '{$_GET['getfile']}'
                                      ")
                                 );
    //if (file_exists("attachments/$file_name") && substr($orig_name, -4, 4) != ".eml" ) {
    if (file_exists("$attachdir/$file_name")) {
        $path = "$attachdir/$file_name";
	    $orig_name=urlencode($orig_name);
        header("Cache-Control: max-age=60"); //Fix for Internet explorer bug
        header("Pragma: public");
        header("Content-type: $file_type");
        header("Content-Disposition: attachment; filename=$orig_name");
        header("Content-transfer-encoding: binary\n");
        header("Content-length: " . filesize($path) . "\n");

        readfile("$path");
    //  } elseif (substr($orig_name, -4, 4) == ".eml" && isset($_GET['attachment'])){
    //
    //	    include("scripts/view_eml.php");
    //
    //  } elseif (substr($orig_name, -4, 4) == ".eml") {
    //	    header("Location: index.php?do=view_eml&target={$_GET['getfile']}");
    //      //echo "<script type='text/javascript'>\n<!--\ndocument.open('?do=view_eml&target=$file_name', '_blank');\n//--></script>\n";
    } else {
        echo $language['filenotexist']." ($attachdir/$file_name)";
    };

    // If no file was requested, show the page as per normal
} else {
    //////////////////////////////////////////////////////////////////////////////////////////////
    // SEND DEFAULT HEADERS FOR A NORMAL PAGE
    //////////////////////////////////////////////////////////////////////////////////////////////
    header("Content-type: text/html; charset=utf-8");

    //////////////////////////////////////////////////////////////////////////////////////////////
    // Check if this is the first time logged in for three hours
    //////////////////////////////////////////////////////////////////////////////////////////////
    $firstvisit = FALSE;
    if ($_COOKIE["{$cookieprefix}_firstvisit"] < time()-60*60*3) {
	    //This is the first visit for 3 hours - set a new cookie
	    $firstvisit = TRUE;
	    setcookie("{$cookieprefix}_firstvisit", time(), time()+60*60*24, "/");
    } elseif (empty($_COOKIE["{$cookieprefix}_firstvisit"])) {
        //There is no cookie - set a new one
        $firstvisit = TRUE;
	    setcookie("{$cookieprefix}_firstvisit", time(), time()+60*60*24, "/");
    }


    // If the user has specified column sorting, send them a cookie
/*if ($_GET['order']) {
  setcookie("{$cookieprefix}_order", $_GET['order'], time()+60*60*24*30, "/");
};

if ($_GET['sort']) {
  setcookie("{$cookieprefix}_sort", $_GET['sort'], time()+60*60*24*30, "/");
};*/

    /////////////////////////////////////////////////////////////////////////////////////////////
    // HANDLE AJAX QUERIES
    /////////////////////////////////////////////////////////////////////////////////////////////
    if (isset($_GET['do']) && $_GET['do']=="ajax") {
      //Don't do any headers or anything, just load the relevant do file
      $do="scripts/ajax.php";
      require($do);
      die();
    }

    /////////////////////////////////////////////////////////////////////////////////////////////
    // Load JqGrid Plugin if Required
    /////////////////////////////////////////////////////////////////////////////////////////////
    if ((isset($_GET['do']) && $_GET['do'] == "admin") && (isset($_GET['area']) && $_GET['area'] == "peopleofinterest")) {
	    $jqgrid=true;
    }

    /////////////////////////////////////////////////////////////////////////////////////////////
    // START DISPLAYING A STANDARD PAGE
    /////////////////////////////////////////////////////////////////////////////////////////////
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
<?php if($mobile) {
?>
<meta name="HandheldFriendly" content="true" />
<meta name="viewport" content="width=device-width" />
<?php
}?>
<title>OpenCaseTracker<?php if(isset($tasknumber) && $tasknumber) echo " - ".$tasknumber ?></title>
  <link rel="icon" href="./favicon.ico" type="image/png" />
  <link rel="apple-touch-icon" href="./apple-touch-icon.png"/>
  <meta name="description" content="CaseTracker, a Case Tracking System written in PHP." />
  <link href="themes/<?php echo $project_prefs['theme_style'];?>/<?php echo $cssfile ?>" rel="stylesheet" type="text/css" />
  <link href="jscalendar/calendar-blue.css" rel="stylesheet" type="text/css" />
  <script type="text/javascript" src="functions.js"></script>
  <script type="text/javascript" src="styleswitcher.js"></script>
  <style type="text/css">@import url(jscalendar/calendar-win2k-1.css);</style>
  <script type="text/javascript" src="jscalendar/calendar_stripped.js"></script>
  <script type="text/javascript" src="jscalendar/lang/calendar-en.js"></script>
  <script type="text/javascript" src="jscalendar/calendar-setup.js"></script>
  <script type="text/javascript" src="js/jquery-1.6.1.min.js"></script>
  <script type="text/javascript" src="js/jquery-ui-1.8.13.custom.min.js"></script>
  <script type="text/javascript" src="js/jquery_plugins/jquery.jeditable.mini.js"></script>
  <script type="text/javascript" src="js/jquery_plugins/jquery.jeditable.datepicker.js"></script>

<?php
// MORE JQGRID REQUIREMENTS
if(isset($jqgrid) && $jqgrid==true) {
	?>
  <link rel="stylesheet" type="text/css" media="screen" href="themes/<?php echo $project_prefs['theme_style'];?>/ui.jqgrid.css" />

  <script type="text/javascript">
     var gridimgpath='themes/<?php echo $project_prefs['theme_style'];?>/';
  </script>
  <script type="text/javascript" src="js/jquery_plugins/jqGrid/js/i18n/grid.locale-en.js"></script>
  <script type="text/javascript" src="js/jquery_plugins/jqGrid/js/jquery.jqGrid.min.js"></script>
	<?php
}
?>
  <!--[if lte IE 6]>
    <link rel="stylesheet" type="text/css" href="themes/<?php echo $project_prefs['theme_style'];?>/ie.css" />
  <![endif]-->
  <!--[if IE 7]>
    <link rel="stylesheet" type="text/css" href="themes/<?php echo $project_prefs['theme_style'];?>/ie.css" />
  <![endif]-->
  <!--[if IE 8]>
    <link rel="stylesheet" type="text/css" href="themes/<?php echo $project_prefs['theme_style'];?>/ie.css" />
  <![endif]-->


  <link rel="stylesheet" href="js/jquery_plugins/jquery.nyroModal/styles/nyroModal.css" type="text/css" media="screen" />
  <script type="text/javascript" src="js/jquery_plugins/jquery.nyroModal/jquery.nyroModal.custom.min.js"></script>


  <script type="text/javascript">window.name="casetracker";</script>
  <script type='text/javascript'>
   <!--
   function loadURL(name, target, value, description) {
   if (value != '') {
    var url=name+value;
	var ok=confirm('<?php echo $language['urlcheck']; ?>'+description)
	 if (ok) {
 	 window.open(url, target);
	 }
    }
   }

   //-->
  </script>

  <script type='text/javascript' src='js/main.js'></script>

  <?php
  //Set the id variable for javascript files
  ?>
  <script type='text/javascript'>
  <?php
  if(isset($_GET['id'])) {
    ?>
    var task_id=<?php echo $_GET['id'] ?>;
    <?php
  }
  ?>
  </script>
  <?php
  //Load any javascript files needed for this page
  if (!isset($_REQUEST['do'])) {
    $jsdo = "index";
  } else {
  	$jsdo = $_REQUEST['do'];
  }
  //Load javasacript files
  if(file_exists("js/$jsdo.js")) {
    echo "<script type='text/javascript' src='js/$jsdo.js'></script>\n";
  }
  ?>
  <?php
      // open the themes directory
      if ($handle = opendir('themes/')) {
      $theme_array = array();
       while (false !== ($file = readdir($handle))) {
        if ($file != "." && $file != ".." && file_exists("themes/$file/$cssfile")) {
          array_push($theme_array, $file);
        }
      }
      closedir($handle);
    }

    // Sort the array alphabetically
    sort($theme_array);
    // Then display them
    while (list($key, $val) = each($theme_array)) {
      echo "<link href=\"themes/$val/$cssfile\" title=\"$val\" rel=\"alternate stylesheet\" type=\"text/css\" />\n";
    };
    ?>
</head>
<?php
///////////////////////////////////////////////////////////////////////////////////////////////////
// END OF THE HTML HEADER SECTION FOR A NORMAL PAGE
///////////////////////////////////////////////////////////////////////////////////////////////////
?>
<body>

<?php
// DISPLAY REMINDERS AND OTHER POPUP MESSAGES FOR FIRSTVISITS
if (($firstvisit === TRUE || 1==1) &&   //Note that this is currently forced on in all situations!
    (isset($flyspray_prefs['overdue_modal']) && $flyspray_prefs['overdue_modal'] > 0)
   ) {
    if(!isset($_SESSION['modalcount'])) {$_SESSION['modalcount']=0;}
	$_SESSION['modalcount']++;
	if($_SESSION['modalcount'] % $flyspray_prefs['overdue_modal'] == 0) {
		//if ($_COOKIE["{$cookieprefix}_userid"]==2) {
		@$overduecases = $fs->countOverdueCases($_COOKIE["{$cookieprefix}_userid"]);
		if($overduecases > 0 && !isset($_GET['do']) && !isset($_POST['do'])) {
			$text=str_replace("{cases}", $overduecases, $language['overduemessage']);
			//echo "<script type='text/javascript'>\n<!--\n alert(\"$text\");\n //-->\n</script>";
			//TIME TO DO SOMETHING A BIT MORE DRASTIC - Make them do something with their overdue cases
			?>
			<script type='text/javascript'>
              $(document).ready(function(){
				$(function() {
				  $.nyroModalManual({
					url: 'scripts/overduecases.php?userid=<?php echo $_COOKIE["{$cookieprefix}_userid"]; ?>&lightbox=yes'
				  });
				});
              });
			</script>
			<?php
		}
	}
}
$headerfile = "$basedir/themes/".$project_prefs['theme_style']."/header.inc.php";
if(file_exists("$headerfile") && !$mobile) {
 include("$headerfile");
}

if ($project_prefs['show_logo'] == '1' && ((isset($_GET['do']) && $_GET['do'] != "code_search") || (!isset($_GET['do']))) && !$mobile) {
  echo "<a href='$noturl'><h1 id=\"title\"><span>{$project_prefs['project_title']}</span></h1></a>";
} elseif ($mobile) {
 echo "<span class='mobiletitle'>OpenCaseTracker Mobile</span>";
};

//////////////////////////////////////////////////////////////////////////////////////////////////
// INITIAL LINE - WITH DROPDOWN MENU AND JUMP BOX
//////////////////////////////////////////////////////////////////////////////////////////////////
?>
<div id="content">
<div id="lefttop">
  <form action="index.php" method="get">
    <p>
	  <?php
	  if ((isset($_GET['do']) && $_GET['do'] != "member_search" && $_GET['do'] != "mailform" && $_GET['do'] != "code_search" && $_GET['do'] != "time_invoice") || (!isset($_GET['do']))) {
	  ?>
      <select name="tasks">
        <option value="all"><?php echo $language['tasksall'];?></option>
      <?php if ($_COOKIE["{$cookieprefix}_userid"]) { ?>
        <option value="assigned" <?php if($_GET['tasks'] == 'assigned') echo 'selected="selected"'; ?>><?php echo $language['tasksassigned']; ?></option>
        <option value="reported" <?php if($_GET['tasks'] == 'reported') echo 'selected="selected"'; ?>><?php echo $language['tasksreported']; ?></option>
        <option value="watched" <?php if($_GET['tasks'] == 'watched') echo 'selected="selected"'; ?>><?php echo $language['taskswatched']; ?></option>
      <?php }; ?>
      </select>
      <!--<?php echo $language['selectproject'];?>
      <select name="project">
      <option value="0"<?php if ($_GET['project'] == '0') echo ' selected="selected"';?>><?php echo $language['allprojects'];?></option>
      <?php
      $get_projects = $fs->dbQuery("SELECT * FROM ".$fs->returnDBPrefix()."projects WHERE project_is_active = ? ORDER BY project_title", array('1'));
      while ($row = $fs->dbFetchArray($get_projects)) {
        if ($project_id == $row['project_id'] && $_GET['project'] != '0') {
          echo '<option value="' . $row['project_id'] . '" selected="selected">' . stripslashes($row['project_title']) . '</option>';
        } else {
          echo '<option value="' . $row['project_id'] . '">' . stripslashes($row['project_title']) . '</option>';
        };
      };
      ?>
      </select>-->
      <input class="mainbutton" type="submit" value="<?php echo $language['show'];?>" />
	  <?php if (isset($_COOKIE["{$cookieprefix}_userid"])) {
	    if($must) {
	  ?>
	  &nbsp;&nbsp;<a href='#' onclick='window.open("index.php?do=member_search", "_blank", "toolbar=no, scrollbars=yes, width=600, height=500, left=10, top=10")'><img src="themes/<?php echo $project_prefs['theme_style']?>/find.png"> <?php echo $language['member_search']?></a>
	  <?php } ?>
	  &nbsp;&nbsp;<a href='<?php echo $_SESSION['last_view']; ?>'><img src='themes/<?php echo $project_prefs['theme_style']?>/menu/lastview.png'> <?php echo $language['lastview']?></a>
	  <?php if(!$mobile) { ?>
	  &nbsp;&nbsp;<a href='?do=summary_report'><img src='themes/<?php echo $project_prefs['theme_style']?>/menu/reports.png'><?php echo $language['summaryreport'] ?></a>
	  <?php }
	  }
	  ?>
	  <?php
	  }
	  ?>
    </p>
  </form>
</div>

<?php
if ((isset($_GET['do']) && ($_GET['do'] != "member_search" && $_GET['do'] != "mailform" && $_GET['do'] != "code_search" && $_GET['do'] != "time_invoice")) || (!isset($_GET['do']))) {
  $taskidlength = !$mobile ? 10 : 5;
?>
<!--<a href="<?php echo $flyspray_prefs['base_url'];?>"><?php echo $flyspray_prefs['project_title'];?></a></h2>-->

<div id="righttop">
  <form action="index.php" method="get">

      <?php if(!$mobile) { ?>
	  <label class='inline' for="showtaskid"><?php echo $language['showtask'];?> #</label>
	  <?php } ?>
      <input name="id" id="showtaskid" type="text" size="<?php echo $taskidlength ?>" maxlength="10" accesskey="t" />
      <input type="hidden" name="do" value="details" />
      <input class="mainbutton" type="submit" value="<?php echo $language['go'];?>" />
  </form>
</div>

<div style='clear: both'></div>
<?php
//////////////////////////////////////////////////////////////////////////////////////////////////
// SECOND LINE
//////////////////////////////////////////////////////////////////////////////////////////////////
}
if ($project_prefs['intro_message'] != '') {
  $intro_message = nl2br(stripslashes($project_prefs['intro_message']));
  echo "<p class=\"intromessage\">$intro_message</p>";
};

// If we have allowed anonymous logging of new tasks
// Show the link to the Add Task form
if ($flyspray_prefs['anon_open'] == '1' && $flyspray_prefs['anon_view'] == '1' && !$_COOKIE["{$cookieprefix}_userid"]) {
  echo "<p class=\"unregistered\"><a href=\"?do=newtask&amp;project=$project_id\">{$language['opentaskanon']}</a></p>";
};

// Otherwise show the link to a registration form
if ($flyspray_prefs['anon_open'] != '0' && !$_COOKIE["{$cookieprefix}_userid"] && $flyspray_prefs['spam_proof'] == '1') {
  echo "<p class=\"unregistered\"><a href=\"index.php?do=register\">{$language['register']}</a></p>";
} elseif ($flyspray_prefs['anon_open'] != '0' && !$_COOKIE["{$cookieprefix}_userid"] && $flyspray_prefs['spam_proof'] != '1') {
  echo "<p class=\"unregistered\"><a href=\"index.php?do=newuser\">{$language['register']}</a></p>";
};
if(!isset($_GET['do'])) {$_GET['do']=null;}
// If the user has the right name cookies
if (isset($_COOKIE["{$cookieprefix}_userid"]) && $_COOKIE["{$cookieprefix}_passhash"] && $_GET['do'] != "member_search" && $_GET['do'] != "mailform" && $_GET['do'] != "code_search" && $_GET['do'] != "time_invoice") {

    // Check to see if the user has been trying to hack their cookies to perform sql-injection
    if (!preg_match ("/^\d+$/", $_COOKIE["{$cookieprefix}_userid"])) {
      //die("Stop hacking your cookies, you naughty fellow!");
    };
	if (!preg_match ("/^\d+$/", $_COOKIE["{$cookieprefix}_project"])) {
	  //echo "Project prefix cookie hack?";
	}

  // Get current user details
  $result = $fs->dbQuery("SELECT * FROM ".$fs->returnDBPrefix()."users WHERE user_id = ?", array($_COOKIE["{$cookieprefix}_userid"]));
  $current_user = $fs->dbFetchArray($result);

  // Get the group information for this user
  $result = $fs->dbQuery("SELECT * FROM ".$fs->returnDBPrefix()."groups WHERE group_id = ?", array($current_user['group_in']));
  $group_details = $fs->dbFetchArray($result);

  // Check that the user hasn't spoofed the cookie contents somehow
  if ($_COOKIE["{$cookieprefix}_passhash"] == crypt($current_user['user_pass'], "$cookiesalt")
    // And that their account is enabled
    && $current_user['account_enabled'] == "1"
    // And that their group is open
    && $group_details['group_open'] == '1')
    {

    // Get the group information for this user
    $isgroupadmin = $fs->dbQuery("SELECT * FROM ".$fs->returnDBPrefix()."groups WHERE group_id = ?", array($current_user['group_in']));
    $permissions = $fs->dbFetchArray($isgroupadmin);
    $_SESSION['userid'] = $current_user['user_id'];
    //$_SESSION['account_enabled'] = $current_user['account_enabled'];
    $_SESSION['admin'] = $permissions['is_admin'];
    $_SESSION['can_open_jobs'] = $permissions['can_open_jobs'];
    $_SESSION['can_modify_jobs'] = $permissions['can_modify_jobs'];
    $_SESSION['can_add_comments'] = $permissions['can_add_comments'];
    $_SESSION['can_attach_files'] = $permissions['can_attach_files'];
    $_SESSION['can_vote'] = $permissions['can_vote'];

	//Variable to tell if the user is a project admin for the current
	$isprojectadmin = $fs->dbQuery("SELECT COUNT(*) as project_owner FROM ".$fs->returnDBPrefix()."projects WHERE default_cat_owner = ? AND project_id = ?", array($current_user['user_id'], $project_id));
	$gppermissions = $fs->dbFetchArray($isprojectadmin);
	$_SESSION['project_admin'] = $gppermissions['project_owner'];

////////////////////////////////////////////////////////////////////////////////////////////////////
// Show the user menu
////////////////////////////////////////////////////////////////////////////////////////////////////
	if(!$mobile) {
	?>
    <p id="menu">
      <!--<em><?php echo $language['loggedinas'] ?> - <?php echo $current_user['user_name'] ?></em>-->
      <span id="mainmenu">
        <!--<small> | </small>--><a href="index.php?do=newtask&amp;project=<?php echo $project_id ?>" class="buttonlink">
          <img src="themes/<?php echo $project_prefs['theme_style'] ?>/menu/newtask.png" />&nbsp;<?php echo $language['addnewtask'] ?></a>
		<!--<small> | </small>--><a href="index.php?do=openshut&amp;project=<?php echo $project_id ?>" class="buttonlink">
	      <img src="themes/<?php echo $project_prefs['theme_style'] ?>/menu/phone.png" />&nbsp;<?php echo $language['openshut'] ?></a>
         <!--<small> | </small>--><a href="index.php?do=admin&amp;area=peopleofinterest" class="buttonlink">
         <?php echo '<img src="themes/' . $project_prefs['theme_style'] . '/menu/usersandgroups.png" />&nbsp;' . $language['poi'];?></a>
		<!--<small> | </small>--><a href="index.php?do=reports" class="buttonlink">
		  <img src="themes/<?php echo $project_prefs['theme_style'] ?>/menu/reports.png" />&nbsp;<?php echo $language['reports'] ?></a>
		<?php
		if ($flyspray_prefs['allow_billing'] == 1) { ?>
			<!--<small> | </small>--><a href="index.php?do=timesummary" class="buttonlink">
			<img src="themes/<?php echo $project_prefs['theme_style'] ?>/menu/reports.png" />&nbsp;Billing Summary</a>
		<?php
		}
		?>
        <!--<small> | </small>--><a href="index.php?do=admin&amp;area=users&amp;id=<?php echo $_SESSION['userid'] ?>" class="buttonlink">
          <img src="themes/<?php echo $project_prefs['theme_style'] ?>/menu/editmydetails.png" />&nbsp;<?php echo $language['editmydetails'] ?></a>
		<!--<small> | </small>--><a href="index.php?do=chpass" class="buttonlink">
		  <img src="themes/<?php echo $project_prefs['theme_style'] ?>/menu/password.png" />&nbsp;<?php echo $language['changepassword'] ?></a>
		<!--<small> | </small>--><a href="scripts/authenticate.php?action=logout" class="buttonlink">
		  <img src="themes/<?php echo $project_prefs['theme_style'] ?>/menu/logout.png" />&nbsp;<?php echo $language['logout'] ?></a></span>
		<?php

	    $isgroupadmin = $fs->dbQuery("SELECT is_admin FROM ".$fs->returnDBPrefix()."groups WHERE group_id = ?", array($current_user['group_in']));
	    $is_admin = $fs->dbFetchArray($isgroupadmin);
	    $_SESSION['admin'] = $is_admin['is_admin'];

/////////////////////////////////////////////////////////////////////////////////////////////
// Show the Admin menu
/////////////////////////////////////////////////////////////////////////////////////////////
	    if ($_SESSION['admin'] == "1") {
		    ?>

		    <span id="adminmenu">
		     <!--<em><?php echo $language['adminmenu'];?></em>-->

		     <!--<small> | </small>--><a href="?do=admin&amp;area=options" class="buttonlink">
		     <?php echo '<img src="themes/' . $project_prefs['theme_style'] . '/menu/options.png" />&nbsp;' . $language['options'];?></a>

		     <!--<small> | </small>--><a href="?do=admin&amp;area=projects" class="buttonlink">
		     <?php echo '<img src="themes/' . $project_prefs['theme_style'] . '/menu/projectprefs.png" />&nbsp;' . $language['projects'];?></a>

		     <!--<small> | </small>--><a href="?do=admin&amp;area=users" class="buttonlink">
		     <?php echo '<img src="themes/' . $project_prefs['theme_style'] . '/menu/usersandgroups.png" />&nbsp;' . $language['usersandgroups'];?></a>

		     <!--<small> | </small>--><a href="?do=admin&amp;area=tasktype" class="buttonlink">
		     <?php echo '<img src="themes/' . $project_prefs['theme_style'] . '/menu/lists.png" />&nbsp;' . $language['tasktypes'];?></a>

		     <!--<small> | </small>--><a href="?do=admin&amp;area=resolution" class="buttonlink">
		     <?php echo '<img src="themes/' . $project_prefs['theme_style'] . '/menu/lists.png" />&nbsp;' . $language['resolutions'];?></a>

             <!--<small> | </small>--><a href="?do=admin&amp;area=texts" class="buttonlink">
             <?php echo '<img src="themes/' . $project_prefs['theme_style'] . '/menu/lists.png" />&nbsp;' . $language['texts'];?></a>
		    </span>
		    <?php
	    };
	}; //End menu display to non-mobiles
	?>
    </p>
	<?php
    } else {
      echo "<br />{$language['disabledaccount']}";
      echo "<meta http-equiv=\"refresh\" content=\"0; URL=scripts/authenticate.php?action=logout\">";
    };

};
/////////////////////////////////////////////////////////////////////////////////////////
// SHOW THE SELECTED PAGE (according to "do" request
/////////////////////////////////////////////////////////////////////////////////////////
    $do = isset($_REQUEST['do']) ? $_REQUEST['do'] : "index";

    if (requestDuplicated()) {
      printf('<meta http-equiv="refresh" content="2; URL=?id=%s">', $project_id);
      printf('<div class="redirectmessage"><p><em>%s</em></p></div>', $language['duplicated']);
      echo '</body></html>';
      exit;
    }

// This is to only allow people to request valid pages, instead of things like config.inc.php or /etc/passwd
//      if (preg_match ("/^(admin|reports|authenticate|chpass|chproject|details|index|loginbox|modify|newgroup|newproject|newtask|newuser|changelog|register)$/", $do)
      if ($flyspray_prefs['anon_view'] == '1' OR isset($_COOKIE["{$cookieprefix}_userid"])) {
         if($do == "filereport")  {
           $do="reports/".$_REQUEST['reportname'];
		   require("scripts/$do");
         } elseif (substr($do, -7)== "_report") {
           require("scripts/reports/$do.php");
		 } else {
           require("scripts/$do.php");
         }
      };
	  if ($do == "index") {
	      // Since we're in the index page, we must be looking at a list!
		  // Save the current query to a session variable for simply returns later
		  $_SESSION['last_view']=$_SERVER['REQUEST_URI'];
	  }

      // if no-one's logged in, show the login box
      if(!isset($_COOKIE["{$cookieprefix}_userid"])) {
        require('scripts/loginbox.php');
      };

      ?>
</div>
<?php
/////////////////////////////////////////////////////////////////////////////////////////
// SHOW THE PAGE FOOTER
/////////////////////////////////////////////////////////////////////////////////////////
?>
<p id="footer">
<!-- Please don't remove this line - it helps promote CaseTracker -->
<a href="http://sourceforge.net/projects/opencasetracker//" class="offsite"><?php printf("%s %s", $language['poweredby'], $fs->version);?> (v<?php echo $version ?>)</a>
</p>

<?php
$footerfile = "$basedir/themes/".$project_prefs['theme_style']."/footer.inc.php";
if(file_exists("$footerfile")) {
 include("$footerfile");
}
?>

</body>
</html>
<?php

// End of file delivery / showing the page
};
$fs->dbClose();
if($must) $fs->odbcClose();
?>