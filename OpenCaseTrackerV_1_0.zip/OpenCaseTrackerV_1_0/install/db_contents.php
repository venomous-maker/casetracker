; <?php die( 'Do not access this page directly.' ); ?>
; This is the OpenCaseTracker Default Database Contents File
;
; Each section represents a table, and each setting within that section
; represents a row of data to add with the values being the ADODB data library method
; for creating the field (see http://phplens.com/lens/adodb/docs-datadict.htm)

[users]
collist="(`user_id`, `user_name`, `user_pass`, `real_name`, `group_in`, `jabber_id`, `email_address`, `notify_type`, `account_enabled`, `dateformat`, `dateformat_extended`, `default_task_view`, `default_version`, `strategy_enabled`, `email_moderator`)"
1="(1, 'admin', '4tQSEW3lEnOio', 'Super User', 1, 'super@yourdomain', 'super@yourdomain', 0, 1, '', '', '', 1, 1, 1)"

[groups]
collist="(`group_id`, `group_name`, `group_desc`, `is_admin`, `can_open_jobs`, `can_modify_jobs`, `can_add_comments`, `can_attach_files`, `can_vote`, `group_open`)"
1="(1, 'Admin', 'Members have unlimited access to all functionality.', 1, 1, 1, 1, 1, 1, 1)"
2="(2, 'Second', 'Second Group', 0, 1, 1, 0, 0, 0, 1)"

[list_category]
collist="(`category_id`, `project_id`, `category_name`, `category_descrip`, `list_position`, `show_in_list`, `category_owner`, `parent_id`)"
1="(1, 1, 'Default', 'Default Department', 10, 1, 0, 0)"
2="(2, 1, 'finance', 'Finance Department', 2, 1, 1, 0)"
3="(3, 1, 'admin', 'Administration Department', 3, 1, 1, 0)"

[list_resolution]
collist="(`resolution_id`, `resolution_name`, `list_position`, `show_in_list`)"
1="(1, 'None', 1, 1)"
2="(2, 'Positive Outcome', 13, 1)"
3="(3, 'No Longer Employed', 11, 1)"
4="(4, 'Case refused', 3, 1)"
5="(5, 'Negative Outcome', 9, 1)"
6="(6, 'Duplicate Case', 5, 1)"
7="(7, 'Phone Enquiry', 12, 1)"
8="(8, 'Case resolved (oth)', 4, 0)"
9="(9, 'Pre-existing Issue', 14, 0)"
10="(10, 'No furth. action req', 10, 1)"
11="(11, 'Inactive', 6, 1)"
12="(12, 'Assess not to proceed', 2, 1)"

[list_tasktype]
collist="(`tasktype_id`, `tasktype_name`, `list_position`, `show_in_list`)"
1="(1, 'Standard', 1, 1)"

[list_version]
collist="(`version_id`, `project_id`, `version_name`, `list_position`, `show_in_list`, `version_tense`)"
1="(1, 1, ' Standard Case', 1, 1, 2)"
2="(2, 1, ' Phone enquiry', 3, 1, 2)"
3="(3, 1, 'Default', 10, 1, 2)"

[projects]
collist="(`project_id`, `project_title`, `theme_style`, `show_logo`, `inline_images`, `default_cat_owner`, `intro_message`, `project_is_active`, `visible_columns`)"
1="(1, 'Default Project', 'Default', 1, 1, 40, '', 1, 'id project summary assignedto date_due member')"

[prefs]
collist="(`pref_name`, `pref_value`, `pref_desc`)"
1="('anon_open', '0', 'Allow anonymous users to open new tasks')"
2="('theme_style', 'Default', 'Theme / Style')"
3="('jabber_server', '', 'Jabber server')"
4="('jabber_port', '5222', 'Jabber server port')"
5="('jabber_username', 'jabberuser', 'Jabber username')"
6="('jabber_password', 'jabberpass', 'Jabber password')"
7="('project_title', 'Open Case Tracker!', 'Project title')"
8="('base_url', 'http://localhost/opencasetracker/', 'Base URL for this installation')"
9="('user_notify', '2', 'Force task notifications as')"
10="('admin_email', 'emailaddress@mydomain.com', 'Reply email address for notifications')"
11="('assigned_groups', '1 2', 'Members of these groups can be assigned tasks')"
12="('default_cat_owner', '0', 'Default category owner')"
13="('lang_code', 'en', 'Language')"
14="('spam_proof', '', 'Use confirmation codes for user registrations')"
15="('anon_view', '0', 'Allow anonymous users to view this system')"
16="('default_project', '1', 'Default project id')"
17="('hover_effects', '1', 'Use css mouseover effects on lists')"
18="('restrict_view', '', 'Restrict access to only ones own cases')"
19="('hidden_users', '', 'Users that are hidden from the standard case list')"
20="('allow_restricted', '1', 'Allow tasks to be set with restricted access')"
21="('allow_billing', '1', 'Display billing tab')"
22="('billing_rate', '100', 'Per hour billing rate')"
23="('overdue_modal', '2', 'Display a modal popup box at users listing their overdue cases')"
24="('hide_dept_filter', '0', 'Hide the department filter')"
25="('version', '20130326', 'Database Version')"
26="('error_email', 'jason@aptigence.com.au', 'Send any error notifications to this email address')"

[reports]
collist="(`report_id`, `report_category_id`, `name`, `description`, `inputs`, `input_names`, `outputs`, `output_names`, `sql`)"
1="(1, 2, 'Caseloads per user', 'A list of open cases assigned to each user', 'category_id', 'Department', 'real_name|total', 'Name|Total Cases', 'SELECT real_name, count(  *  )  as total\r\nFROM casetracker_users\r\nLEFT JOIN casetracker_tasks \r\nON user_id = assigned_to\r\nWHERE casetracker_users.user_id = casetracker_tasks.assigned_to AND attached_to_project =  ''1''\r\nAND casetracker_tasks.product_category LIKE '':category_id''\r\nAND is_closed = 0\r\nGROUP  BY real_name\r\nORDER BY total desc')"
2="(2, 2, 'Average case age per user', 'The average age in days per case for each user', '', '', 'real_name|days', 'Name|Age (days)', 'SELECT real_name, ROUND((sum(UNIX_TIMESTAMP()-date_opened)/60/60/24)/count(*) , 2) AS days\r\nFROM casetracker_tasks, casetracker_users\r\nWHERE casetracker_tasks.assigned_to = casetracker_users.user_id AND attached_to_project = 1 AND is_closed =0\r\nGROUP BY real_name\r\nORDER BY days desc')"
3="(3, 1, 'Open Cases by Age', '', 'user_id', 'User ID', 'age|total', 'Days since Opened|Total Open Cases', 'SELECT ROUND((UNIX_TIMESTAMP(  )  - date_opened)/60/60/24) AS age, count(*) as total\r\nFROM casetracker_tasks\r\nWHERE is_closed =  ''0'' AND attached_to_project =  ''1''\r\nAND assigned_to like '':user_id''\r\nGROUP BY age\r\nORDER BY age\r\n')"
4="(4, 1, 'Closed Cases by Days Open', '', 'user_id', 'User ID', 'age|total', 'Days Open|Total Open Cases', 'SELECT ROUND((date_closed  - date_opened)/60/60/24) AS age, count(*) as total\r\nFROM casetracker_tasks\r\nWHERE is_closed =  ''1'' AND attached_to_project =  ''1''\r\nAND assigned_to like '':user_id''\r\nGROUP BY age\r\nORDER BY age\r\n')"
5="(5, 1, 'Closed cases - By Reason', 'A list of the close-case categories and the number of closed cases', 'user_id', 'User Id', 'resolution_name|total', 'Reason|Total', 'SELECT resolution_name, count(*) as total\r\nFROM casetracker_tasks, casetracker_list_resolution\r\nWHERE casetracker_tasks.resolution_reason=casetracker_list_resolution.resolution_id\r\nAND is_closed=''1''\r\nAND assigned_to like '':user_id''\r\nGROUP BY resolution_name')"
6="(6, 1, 'Caseloads by Case Type', '', 'user_id|is_closed', 'User|Closed?', 'tasktype_name|total', 'Case Type|Total', 'SELECT tasktype_name, count(*) as total\r\nFROM casetracker_tasks, casetracker_list_tasktype\r\nWHERE casetracker_list_tasktype.tasktype_id=casetracker_tasks.task_type\r\nAND casetracker_tasks.assigned_to like '':user_id''\r\nAND casetracker_tasks.is_closed like '':is_closed''\r\nGROUP BY tasktype_name\r\nORDER BY total DESC, tasktype_name')"
7="(7, 3, 'Recent Case Closures', 'A list of cases that have been recently closed', '', '', '_closed|_id|ure_comment|lution_name', '_closed| No|ure_comment|lution_name', 'SELECT task_id, date_closed, item_summary, closure_comment, resolution_name, real_name\r\nFROM casetracker_tasks, casetracker_list_resolution, casetracker_users\r\nWHERE casetracker_tasks.resolution_reason=casetracker_list_resolution.resolution_id\r\nAND casetracker_tasks.closed_by=casetracker_users.user_id\r\nAND date_closed >= (UNIX_TIMESTAMP()-(:days * 24 * 60 * 60))\r\nORDER BY date_closed desc')"
8="(8, 2, 'Caseload spread by department by user', 'No. of open cases per department for a specific user', 'user_id', 'User', 'real_name|total', 'Officer|Total Cases', 'SELECT real_name, category_name, count(*) as total\r\nFROM casetracker_tasks, casetracker_list_category, casetracker_users\r\nWHERE casetracker_list_category.category_id=casetracker_tasks.product_category\r\nAND casetracker_tasks.assigned_to = casetracker_users.user_id\r\nAND assigned_to like '':user_id''\r\nAND is_closed = ''0''\r\nGROUP BY real_name, category_name\r\nORDER BY real_name, category_name')"
9="(9, 4, 'Open Cases Summary (By Team)', '', 'group_id', 'Group Name', 'real_name|info|member', 'Officer|Case Information|Member', 'select real_name, member, CONCAT(''<b>Case #'',task_id, ''</b>: '', item_summary, ''<br /><b>Date Opened:</b> '', FROM_UNIXTIME(date_opened, ''%d %M %Y''), ''<br /><b>Days Open:</b> '', ROUND((UNIX_TIMESTAMP()-date_opened)/60/60/24), ''<br /><b>Assigned Officer:</b> '', real_name) as info\r\nFROM casetracker_tasks, casetracker_users\r\nWHERE casetracker_tasks.assigned_to=casetracker_users.user_id\r\nAND is_closed = 0\r\nAND group_in like '':group_id''\r\nORDER BY user_id DESC')"
10="(10, 3, 'Recent Activity', 'A list of cases that have been modified or changed in the last x days', 'days', 'Days', 'real_name', 'Officer', 'SELECT  DISTINCT casetracker_tasks.task_id, real_name, max(event_date)\r\nFROM casetracker_tasks, casetracker_history, casetracker_users\r\nWHERE casetracker_tasks.task_id = casetracker_history.task_id AND casetracker_tasks.assigned_to = casetracker_users.user_id AND casetracker_history.event_date >= ( UNIX_TIMESTAMP(  )  - ( :days *24 *60 *60  )  )\r\nGROUP BY event_date \r\nORDER  BY event_date DESC ')"
11="(11, 4, 'Closed Cases Summary', 'A summary of cases closed since the chosen date', 'date_closed|user_id|version|group_id', 'Closed Greater than or Equal to|Officer|Issue Type|Group Name', 'real_name|closure_comment', 'Closing Officer|Reason Closed', 'select real_name, CONCAT(''<b>Case #'',task_id, ''</b>: '', item_summary, ''<br /><b>Date Closed:</b> '', FROM_UNIXTIME(date_closed, ''%d %M %Y''),''<br /><b>Reason Closed:</b> <i>'', resolution_name, ''</i><br /><b>Closure Comments:</b> '', closure_comment) as info\r\nFROM casetracker_tasks, casetracker_list_resolution, casetracker_users, casetracker_groups\r\nWHERE casetracker_tasks.resolution_reason=casetracker_list_resolution.resolution_id\r\nAND casetracker_tasks.closed_by=casetracker_users.user_id\r\nAND casetracker_users.group_in = casetracker_groups.group_id\r\nAND is_closed = 1\r\nAND date_closed >= '':date_closed''\r\nAND user_id like '':user_id''\r\nAND product_version like '':version''\r\nAND group_in = :group_id\r\nORDER BY user_id, date_closed DESC;')"

[report_categories]
collist="(`report_category_id`, `project_id`, `name`, `description`, `sort_order`)"
1="(1, 1, 'Summary Reports', 'Reports that provide general summary information', 1)"
2="(2, 1, 'User Reports', 'Reports that focus on individual users', 2)"
3="(3, 1, 'Activity Reports', 'Reports that focus on recent activity', 3)"
4="(4, 1, 'End of Month', 'Reports for Branch Council', 4)"

[tasks]
collist="(`task_id`, `attached_to_project`, `task_type`, `date_opened`, `date_due`, `opened_by`, `is_closed`, `date_closed`, `closed_by`, `closure_comment`, `item_summary`, `detailed_desc`, `item_status`, `assigned_to`, `resolution_reason`, `product_category`, `product_version`, `closedby_version`, `operating_system`, `task_severity`, `task_priority`, `last_edited_by`, `last_edited_time`, `percent_complete`, `member`, `name`, `unit`, `line_manager`, `line_manager_ph`, `local_delegate`, `local_delegate_ph`, `resolution_sought`, `is_restricted`, `closure_checklist`, `member_is_delegate`)"
1="(1, 1, 1, '1304913326', '1305151200', 1, 0, '1306989129', 1, ' ', 'Example Case', 'One morning, when Gregor Samsa woke from troubled dreams, he found himself transformed in his bed into a horrible vermin. He lay on his armour-like back, and if he lifted his head a little he could see his brown belly, slightly domed and divided by arches into stiff sections.\r\n\r\nThe bedding was hardly able to cover it and seemed ready to slide off any moment. His many legs, pitifully thin compared with the size of the rest of him, waved about helplessly as he looked. \"What''s happened to me? \" he thought. It wasn\'t a dream. His room, a proper human ', 7, 1, 1, 1, 3, 0, 0, 0, 0, 1, '1305779759', 0, 0, 'William Mountbatton', '', 'Alberta Moret', '9555-1234', '', '', 'One morning, when Gregor Samsa woke from troubled dreams, he found himself transformed in his bed into a horrible vermin. He lay on his armour-like back', 0, '1|1||', 0)"

[tasktype_checklist]
collist="(`checklist_id`, `tasktype_id`, `item`, `created`, `user_id`)"
1="(1, 46, 'Yes, the client has signed the legal disclaimer document', 1160455472, 2)"
2="(2, 46, 'Yes, I am aware of, and I have checked the 21 day limit for unfair dismissal applications', 1160455502, 2)"