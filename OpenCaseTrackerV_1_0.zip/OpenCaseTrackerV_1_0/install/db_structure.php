; <?php die( 'Do not access this page directly.' ); ?>
; This is the OpenCaseTracker Database Configuration/Creation File
;
; Each section represents a table, and each setting within that section
; represents a field, with the values being the ADODB data library method
; for creating the field (see http://phplens.com/lens/adodb/docs-datadict.htm)

[attachments]
attachment_id="attachment_id I(5) NOTNULL AUTOINCREMENT PRIMARY"
task_id="task_id I(10) NOTNULL DEFAULT 0"
orig_name="orig_name C(100) NOTNULL"
file_name="file_name C(30) NOTNULL"
file_desc="file_desc C(100) NOTNULL"
file_type="file_type C(50) NOTNULL"
file_size="file_size I(20) NOTNULL DEFAULT 0"
added_by="added_by I(3) NOTNULL DEFAULT 0"
date_added="date_added C(12) NOTNULL"

[comments]
comment_id="comment_id I(10) NOTNULL AUTOINCREMENT PRIMARY"
task_id="task_id I(10) NOTNULL DEFAULT 0"
date_added="date_added C(12) NOTNULL"
user_id="user_id I(3) NOTNULL DEFAULT 0"
comment_text="comment_text X NOTNULL"

[companion]
related_id="related_id I(10) NOTNULL AUTOINCREMENT PRIMARY"
this_task="this_task I(10) NOTNULL DEFAULT 0"
related_task="related_task I(10) NOTNULL DEFAULT 0"

[emailtemplates]
template_id="template_id I(11) NOTNULL AUTOINCREMENT PRIMARY"
project_id="project_id I(11) NOTNULL DEFAULT 0"
name="name C(100) NOTNULL"
subject="subject X NOTNULL"
message="message X NOTNULL"
attachment="attachment C(255) NOTNULL"

[groups]
group_id="group_id I(3) NOTNULL AUTOINCREMENT PRIMARY"
group_name="group_name C(20) NOTNULL"
group_desc="group_desc C(150) NOTNULL"
is_admin="is_admin I(1) NOTNULL DEFAULT 0"
can_open_jobs="can_open_jobs I(1) NOTNULL DEFAULT 0"
can_modify_jobs="can_modify_jobs I(1) NOTNULL DEFAULT 0"
can_add_comments="can_add_comments I(1) NOTNULL DEFAULT 0"
can_attach_files="can_attach_files I(1) NOTNULL DEFAULT 0"
can_vote="can_vote I(1) NOTNULL DEFAULT 0"
group_open="group_open I(1) NOTNULL DEFAULT 0"

[history]
history_id="history_id I(10) NOTNULL AUTOINCREMENT PRIMARY"
task_id="task_id I(10) NOTNULL DEFAULT 0"
user_id="user_id I(3) NOTNULL DEFAULT 0"
event_date="event_date C(12) NOTNULL"
event_type="event_type I(12) NOTNULL DEFAULT 0"
field_changed="field_changed X NOTNULL"
old_value="old_value X NOTNULL"
new_value="new_value X NOTNULL"

[invoices]
invoice_id="invoice_id I(11) NOTNULL AUTOINCREMENT PRIMARY"
task_id="task_id I(11) NOTNULL DEFAULT 0"
time_ids="time_ids X NOTNULL"
date_generated="date_generated C(12) NOTNULL"
minutes="minutes I(11) NOTNULL DEFAULT 0"
amount="amount F NOTNULL DEFAULT 0"

[list_category]
category_id="category_id I(3) NOTNULL AUTOINCREMENT PRIMARY"
project_id="project_id I(3) NOTNULL DEFAULT 0"
category_name="category_name C(30) NOTNULL"
category_descrip="category_descrip C(255) NOTNULL"
list_position="list_position I(5) NOTNULL DEFAULT 0"
show_in_list="show_in_list I(1) NOTNULL DEFAULT 0"
category_owner="category_owner I(3) NOTNULL DEFAULT 0"
parent_id="parent_id I(1) NOTNULL DEFAULT 0"

[list_os]
os_id="os_id I(3) NOTNULL AUTOINCREMENT PRIMARY"
project_id="project_id I(3) NOTNULL DEFAULT 0"
os_name="os_name C(20) NOTNULL"
list_position="list_position I(3) NOTNULL DEFAULT 0"
show_in_list="show_in_list I(1) NOTNULL DEFAULT 0"

[list_resolution]
resolution_id="resolution_id I(3) NOTNULL AUTOINCREMENT PRIMARY"
resolution_name="resolution_name C(60) NOTNULL"
list_position="list_position I(3) NOTNULL DEFAULT 0"
show_in_list="show_in_list I(1) NOTNULL DEFAULT 0"

[list_tasktype]
tasktype_id="tasktype_id I(3) NOTNULL AUTOINCREMENT PRIMARY"
tasktype_name="tasktype_name C(60) NOTNULL"
list_position="list_position I(3) NOTNULL DEFAULT 0"
show_in_list="show_in_list I(1) NOTNULL DEFAULT 0"

[list_tasktype_groups]
tasktype_groups_id="tasktype_groups_id I(11) NOTNULL AUTOINCREMENT PRIMARY"
tasktype_groups_name="tasktype_groups_name C(100) NOTNULL"
owner_id="owner_id I(11) NOTNULL"
list_position="list_position I(11) NOTNULL"
hide_from_list="hide_from_list I(11) NOTNULL DEFAULT 0"

[list_tasktype_groups_links]
id="id I(11) NOTNULL AUTOINCREMENT PRIMARY"
tasktype_groups_id="tasktype_groups_id I(11) NOTNULL"
tasktype_id="tasktype_id I(11) NOTNULL"

[list_version]
version_id="version_id I(3) NOTNULL AUTOINCREMENT PRIMARY"
project_id="project_id I(3) NOTNULL DEFAULT 0"
version_name="version_name C(20) NOTNULL"
list_position="list_position I(3) NOTNULL DEFAULT 0"
show_in_list="show_in_list I(1) NOTNULL DEFAULT 0"
version_tense="version_tense I(1) NOTNULL DEFAULT 0"

[master]
link_id="link_id I(10) NOTNULL AUTOINCREMENT PRIMARY"
master_task="master_task I(10) NOTNULL DEFAULT 0"
servant_task="servant_task I(10) NOTNULL DEFAULT 0"

[notifications]
notify_id="notify_id I(10) NOTNULL AUTOINCREMENT PRIMARY"
task_id="task_id I(10) NOTNULL DEFAULT 0"
user_id="user_id I(10) NOTNULL DEFAULT 0"

[payments]
payment_id="payment_id I(11) NOTNULL AUTOINCREMENT PRIMARY"
task_id="task_id I(11) NOTNULL DEFAULT 0"
amount="amount F NOTNULL DEFAULT 0"
date_received="date_received C(12) NOTNULL"
notes="notes X NOTNULL"

[people]
id="id I(11) NOTNULL AUTOINCREMENT PRIMARY"
firstname="firstname C(255) NOTNULL"
lastname="lastname C(255) NOTNULL"
position="position C(255) NOTNULL"
organisation="organisation C(255) NOTNULL"
phone="phone C(255) NOTNULL"
email="email C(255) NOTNULL"
created="created C(12) NOTNULL"
modified="modified C(12) NOTNULL"

[people_of_interest]
id="id I(11) NOTNULL AUTOINCREMENT PRIMARY"
person_id="person_id I(11) NOTNULL"
task_id="task_id I(11) NOTNULL"
comment="comment X"
created="created C(12) NOTNULL"
modified="modified C(12) NOTNULL"

[prefs]
pref_id="pref_id I(11) NOTNULL AUTOINCREMENT PRIMARY"
pref_name="pref_name C(20) NOTNULL"
pref_value="pref_value C(100) NOTNULL"
pref_desc="pref_desc C(100) NOTNULL"

[projects]
project_id="project_id I(3) NOTNULL AUTOINCREMENT PRIMARY"
project_title="project_title C(100) NOTNULL"
theme_style="theme_style C(20) NOTNULL DEFAULT `default`"
show_logo="show_logo I(1) NOTNULL DEFAULT 0"
inline_images="inline_images I(1) NOTNULL DEFAULT 0"
default_cat_owner="default_cat_owner I(3) NOTNULL DEFAULT 0"
intro_message="intro_message X NOTNULL"
project_is_active="project_is_active I(1) NOTNULL DEFAULT 0"
visible_columns="visible_columns C(255) NOTNULL"
last_email_check="last_email_check C(12)"

[registrations]
reg_id="reg_id I(10) NOTNULL AUTOINCREMENT PRIMARY"
reg_time="reg_time C(12) NOTNULL"
confirm_code="confirm_code C(20) NOTNULL"

[related]
related_id="related_id I(10) NOTNULL AUTOINCREMENT PRIMARY"
this_task="this_task I(10) NOTNULL DEFAULT 0"
related_task="related_task I(10) NOTNULL DEFAULT 0"

[reminders]
reminder_id="reminder_id I(1) NOTNULL AUTOINCREMENT PRIMARY"
task_id="task_id I(10) NOTNULL DEFAULT 0"
to_user_id="to_user_id I(3) NOTNULL DEFAULT 0"
from_user_id="from_user_id I(3) NOTNULL DEFAULT 0"
start_time="start_time C(12) NOTNULL DEFAULT 0"
how_often="how_often I(12) NOTNULL DEFAULT 0"
last_sent="last_sent C(12) NOTNULL DEFAULT 0"
reminder_message="reminder_message X2 NOTNULL"

[reports]
report_id="report_id I(11) NOTNULL AUTOINCREMENT PRIMARY"
report_category_id="report_category_id I(11) NOTNULL DEFAULT 0"
name="name C(150) NOTNULL"
description="description X NOTNULL"
inputs="inputs X NOTNULL"
input_names="input_names X NOTNULL"
outputs="outputs X NOTNULL"
output_names="output_names X NOTNULL"
sql="`sql` X NOTNULL"

[report_categories]
report_category_id="report_category_id I(11) NOTNULL AUTOINCREMENT PRIMARY"
project_id="project_id I(11) NOTNULL DEFAULT 0"
name="name C(100) NOTNULL"
description="description X NOTNULL"
sort_order="sort_order I(11) NOTNULL DEFAULT 0"

[strategy]
strategy_id="strategy_id I(11) NOTNULL AUTOINCREMENT PRIMARY"
task_id="task_id I(11) NOTNULL DEFAULT 0"
user_id="user_id I(11) NOTNULL DEFAULT 0"
comment_date="comment_date C(12) NOTNULL"
comment="comment X NOTNULL"
acknowledged_date="acknowledged_date C(12) NOTNULL"
acknowledged="acknowledged I(11) NOTNULL DEFAULT 0"

[tasks]
task_id="task_id I(10) NOTNULL AUTOINCREMENT PRIMARY"
attached_to_project="attached_to_project I(3) NOTNULL DEFAULT 0"
task_type="task_type I(3) NOTNULL DEFAULT 0"
date_opened="date_opened C(12) NOTNULL"
date_due="date_due C(12) NOTNULL"
opened_by="opened_by I(3) NOTNULL DEFAULT 0"
is_closed="is_closed I(1) NOTNULL DEFAULT 0"
date_closed="date_closed C(12) NOTNULL"
closed_by="closed_by I(3) NOTNULL DEFAULT 0"
closure_comment="closure_comment X2 NOTNULL"
item_summary="item_summary C(100) NOTNULL"
detailed_desc="detailed_desc X2 NOTNULL"
item_status="item_status I(3) NOTNULL DEFAULT 0"
assigned_to="assigned_to I(3) NOTNULL DEFAULT 0"
resolution_reason="resolution_reason I(3) NOTNULL DEFAULT 0"
product_category="product_category I(3) NOTNULL DEFAULT 0"
product_version="product_version I(3) NOTNULL DEFAULT 0"
closedby_version="closedby_version I(3) NOTNULL DEFAULT 0"
operating_system="operating_system I(3) NOTNULL DEFAULT 0"
task_severity="task_severity I(3) NOTNULL DEFAULT 0"
task_priority="task_priority I(3) NOTNULL DEFAULT 0"
last_edited_by="last_edited_by I(3) NOTNULL DEFAULT 0"
last_edited_time="last_edited_time C(12) NOTNULL"
percent_complete="percent_complete I(3) NOTNULL DEFAULT 0"
member="member I(11) NOTNULL DEFAULT 0"
name="name C(100) NOTNULL"
unit="unit X NOTNULL"
line_manager="line_manager X NOTNULL"
line_manager_ph="line_manager_ph C(20) NOTNULL"
local_delegate="local_delegate X NOTNULL"
local_delegate_ph="local_delegate_ph C(20) NOTNULL"
resolution_sought="resolution_sought X NOTNULL"
is_restricted="is_restricted I(1) NOTNULL DEFAULT 0"
closure_checklist="closure_checklist C(10) NOTNULL"
member_is_delegate="member_is_delegate I(1) NOTNULL DEFAULT 0"

[tasktype_checked]
checked_id="checked_id I(11) NOTNULL AUTOINCREMENT PRIMARY"
checklist_id="checklist_id I(11) NOTNULL DEFAULT 0"
task_id="task_id I(11) NOTNULL DEFAULT 0"
date_checked="date_checked I(12) NOTNULL DEFAULT 0"
user_id="user_id I(11) NOTNULL DEFAULT 0"

[tasktype_checklist]
checklist_id="checklist_id I(11) NOTNULL AUTOINCREMENT PRIMARY"
tasktype_id="tasktype_id I(11) NOTNULL DEFAULT 0"
item="item X NOTNULL"
created="created I(12) NOTNULL DEFAULT 0"
user_id="user_id I(11) NOTNULL DEFAULT 0"

[times]
time_id="time_id I(11) NOTNULL AUTOINCREMENT PRIMARY"
task_id="task_id I(11) NOTNULL DEFAULT 0"
time="`time` C(12)"
date="`date` C(12)"
description="description X"
user_id="user_id I(11) NOTNULL"
invoiced="invoiced I(1) DEFAULT 0"
invoice_date="invoice_date C(12)"
rate="rate F NOTNULL"

[users]
user_id="user_id I(3) NOTNULL AUTOINCREMENT PRIMARY"
user_name="user_name C(20) NOTNULL"
user_pass="user_pass C(30) NOTNULL"
real_name="real_name C(100) NOTNULL"
group_in="group_in I(3) NOTNULL DEFAULT 0"
jabber_id="jabber_id C(100) NOTNULL"
email_address="email_address C(100) NOTNULL"
notify_type="notify_type I(1) NOTNULL DEFAULT 0"
account_enabled="account_enabled I(1) NOTNULL DEFAULT 0"
dateformat="dateformat C(30) NOTNULL"
dateformat_extended="dateformat_extended C(30) NOTNULL"
default_task_view="default_task_view C(15) NOTNULL"
default_version="default_version I(11) NOTNULL DEFAULT 0"
strategy_enabled="strategy_enabled I(1) NOTNULL DEFAULT 0"
email_moderator="email_moderator I(1) NOTNULL DEFAULT 0"
self_notify="self_notify I(1) NOTNULL DEFAULT 0"
notify_rate="notify_rate C(1) NOTNULL DEFAULT 'D'"
last_notice="last_notice C(12)"

[member_cache]
member="member I(11) NOTNULL PRIMARY"
subs_paid_to="subs_paid_to T NOTNULL"
paying_emp = "paying_emp C(5) NOTNULL"
joined = "joined C(20) NOTNULL"
surname = "surname C(255) NOTNULL"
pref_name = "pref_name C(255) NOTNULL"
modified = "modified I(11) NOTNULL"

[custom_texts]
custom_text_id="custom_text_id I(10) NOTNULL AUTOINCREMENT PRIMARY"
modify_action="modify_action C(30) NOTNULL"
custom_text_lang="custom_text_lang C(10) NOTNULL"
custom_text="custom_text X NOTNULL"