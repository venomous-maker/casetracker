<?php

/**
 * INSTALL SCRIPT
 *
 * This script is to create an empty database and populate it with a minimum of data
 *
 * It should be run before system operations
 *
 * @version $Id$
 * @copyright 2011
 */

 //Ensure script is not run directly, avoid path disclosure
if (!isset($dbprefix) || isset($_REQUEST['dbprefix'])) {die("Sorry, but you cannot not run this script directly");}

/* Load the minimum required files */

/* Create adodb datadictionary - required to modify tables etc. on database */

?>
<div style='text-align: center; font-family: arial'>
    <div style='border: 1px solid #555; margin-left: auto; margin-right: auto; width: 500px; -moz-border-radius: 5px; -webkit-border-radius: 5px;'>
        <div style='background-color: blue; color: white; font-family: arial; padding: 5px'>
            <h1>OpenCaseTracker Database Setup and Updater</h1>
            <?php if(isset($_GET['systemupdate'])) { ?>
                <h2>Performing system update</h2>
            <?php } ?>
            Using '<?php echo $dbname ?>' Database
	    </div>
	    <div>
<?php
/* Read the db structure file */
$db_array = @parse_ini_file("db_structure.php", true);
$fieldchanges=0;
$tablechanges=0;

/* Iterate through the db_array and check it table by table */
echo "<div style='background-color: black; color: white; font-size: 14pt'>Database Structure Operations</div>\n";
echo "<div style='height: 400px; overflow: auto'>\n";
foreach($db_array as $key=>$val) {
	echo "<div style='margin-top: 5px; width: 85%; border: 1px solid #CCC; margin-left: auto; margin-right: auto;-moz-border-radius: 5px; -webkit-border-radius: 5px'>";
	$tablename=$dbprefix.$key;
	echo "<strong>Checking Table $tablename</strong><br />\n";
	/* First we need to see if the table actually exists already */
	if(in_array($tablename, $tablelist)) {
		/* The table already exists, so now we should check fields */
		echo "<span style='font-size: 8pt'><strong style='color: blue'>Checking fields..</strong><br />\n";
		$fieldlist=$dict->MetaColumns($tablename);
		foreach($val as $fieldname=>$fielddetail) {
			/* We are iterating through each field that _SHOULD_ exist */
			/* We check if it does exist, and if it doesn't we create it */

			if($fieldlist[strtoupper($fieldname)]) {
			    echo "<span style='color: green'>[Field $fieldname OK]</span> \n";
			} else {
				$newsql=$dict->AddColumnSQL($tablename, $fielddetail);
                if($dict->ExecuteSQLArray($newsql)==2) {
                    echo "<span style='color: green'>Field $fieldname added</span><br />\n";
                    $fieldchanges++;
                } elseif($dict->ExecuteSQLArray($newsql)==1) {
                    echo "<span style='color: orange'>Attempted to add Field $fieldname but errors occurred</span><br />\n";
                } else {
                    echo "<span style='color: red'>Failed to add Field $fieldname</span><br />\n";
                }
			}
		}
		echo "</span><br />";
	} else {
	    /* The table doesn't even exist yet, so we need to create the table, */
        /* and populate it with columns */
		$newfields=implode(",\n", $val);
		$newsql = $dict->CreateTableSQL($tablename, $newfields);
		if($dict->ExecuteSQLArray($newsql)==2) {
			echo "<span style='color: green'>$tablename created</span><br />\n";
            $tablechanges++;
		} elseif($dict->ExecuteSQLArray($newsql)==1) {
            echo "<span style='color: orange'>Attempted to create $tablename but errors occurred</span><br />\n";
        } else {
            echo "<span style='color: red'>Failed to create $tablename</span><br />\n";
        }
	}
	echo "</div>\n";
}
echo "</div>\n<br />\n";
/* Report on changes made */
echo "<div style='background-color: black; color: white; font-size: 14pt'>Summary Report</div>\n";
echo "<div style='font-size: 8pt; margin-top: 5px; width: 85%; border: 1px solid #CCC; margin-left: auto; margin-right: auto;-moz-border-radius: 5px; -webkit-border-radius: 5px;'>";
echo "There were $tablechanges new tables created in your database.<br />";
echo "There were $fieldchanges fields added to tables in your database.<br />";
echo "Your database has ".count($db_array)." tables.";
echo "</div>";

$flyspray_prefs = $fs->getGlobalPrefs();
if(!isset($flyspray_prefs['version'])) {
    $sql = "INSERT INTO ".$dbprefix."prefs (pref_name, pref_value, pref_desc) VALUES ('version', '".$version."', 'Database Version Number')";
} else {
    $sql = "UPDATE ".$dbprefix."prefs SET pref_value='".$version."' WHERE pref_name='version'";
}
$fs->dbQuery($sql);
/**
  *
  * Return to main page
  * 
* */

/* Step 3 - Install required minimum data */
if($tablechanges == count($db_array) || (isset($_GET['installdata']) && $_GET['installdata']=="yes")) {

	echo "<div style='background-color: black; color: white; font-size: 14pt'>Database Data Operations</div>\n";
	echo "<div style='height: 400px; overflow: auto'>\n";
	echo "<div style='margin-top: 5px; width: 85%; border: 1px solid #CCC; margin-left: auto; margin-right: auto;-moz-border-radius: 5px; -webkit-border-radius: 5px;'>";
	echo "Populating the database with the minimum required data:<br />\n";
	$data_array = parse_ini_file("db_contents.php", true);

	foreach($data_array as $key=>$dataline) {
		echo "<div style='margin-top: 5px; width: 85%; border: 1px solid #CCC; margin-left: auto; margin-right: auto;-moz-border-radius: 5px; -webkit-border-radius: 5px;'>";
		$tablename=$dbprefix.$key;
		echo "<strong>Inserting Required Data for Table $tablename</strong><br />\n";
		//echo "$key - "; print_r($dataline);
		if($dbtype == "pgsql") {$dataline['collist'] = str_replace("`", "", $dataline['collist']);}
		$thissql = "INSERT INTO ".$tablename."\n".$dataline['collist']." VALUES\n";
		$valuesarray=array();
		for ($i=1; $i<count($dataline); $i++) {
			$valuesarray[] = $dataline[$i]."\n";
		}
		$thissql .= implode(",\n", $valuesarray);
		$fs->dbQuery($thissql, array());
		reset($valuesarray);
		echo "<span style='font-size: 7pt'>".$thissql."</span>";
		echo "</div>\n";
	}
	echo "</div>\n";
	echo "</div>";
}

?>
<div style='background-color: black; color: white; font-size: 14pt'>Installation/Update Operations Complete</div>
<div style='background-color: blue; color: white; font-family: arial; padding: 5px; margin-top: 5px; width: 83%; margin-left: auto; margin-right: auto'>
    <a href='index.php' style='color: white'>Start using OpenCaseTracker</a>
</div>
<?php
/* FOOTER */

?>
			&nbsp;<br />
		</div>
		<div style='background-color: silver; color: blue; font-family: arial; font-size: 8pt; border-top: 1px solid #111'>
		<div style='background-color: silver; color: blue; font-family: arial; font-size: 8pt; border-top: 1px solid #111'>
		    OpenCaseTracker is distributed under the GPL3 public license. Please ensure you understand the terms and requirements of this license before using this software.<br /><br />
		    If you like OpenCaseTracker please contribute to its development. <a href='http://opencasetracker.sourceforge.net/' target='_blank'>http://opencasetracker.sourceforge.net/</a>
		</div>
	</div>
</div>
<?php

?>