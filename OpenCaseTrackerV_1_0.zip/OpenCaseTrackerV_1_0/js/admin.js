$(document).ready(function(){
  $('a.caselist').click(function() {
    var idnum=this.id.substring(9);
	var thisid='#children_'+idnum;
	var dataid='#childrendata_'+idnum;
	var expandid='#expandimg_'+idnum;
	var shrinkid='#shrinkimg_'+idnum;
	$(dataid).html('Retrieving data...');
	$(thisid).toggle();
	$(expandid).toggle();
	$(shrinkid).toggle();
	$.ajax({
	  type: "POST",
	  url: "index.php?do=ajax&ajax=casegroupchildren&casetypegroupid="+idnum,
	  success: function(msg) {
	    $(dataid).html(msg)
	  }
	});
  });

	$(".postform").live('click', function() {
	/* AJAX Call to Post New Person */
	    var firstname=$("input#poi_firstname").val();
	    var lastname=$("input#poi_lastname").val();
	    var position=$("input#poi_position").val();
	    var phone=$("input#poi_phone").val();
	    var email=$("input#poi_email").val();
	    var organisation=$("input#poi_organisation").val();
	    var dataString='firstname='+firstname+'&lastname='+lastname+'&position='+position+'&phone='+phone+'&email='+email+'&organisation='+organisation;
	    $.ajax({
	      type: "POST",
	      url: "scripts/ajax/ajax_poi_post.php",
	      data: dataString,
	      success: function(data) {
	        $("#theform").fadeOut(20);
	        $("#message").show();
	        $("#message").html("<h2>New Person Submitted!</h2>")
	         .append("<p>Thank you</p>")
	         .hide()
	         .fadeIn(1500, function() {
	           $('#message').append(data);
			 });
			$("#list1").trigger("reloadGrid");
			$("#message").fadeOut(1500);
			$("#theform").each (function() {
			    this.reset();
			});
			$("#theform").fadeIn(1500);
		  }
		});
		return false;
	});

  var lastsel;
  
  
  if(typeof gridimgpath==='undefined') {
      //Do nothing
  } else {
      jQuery("#list1").jqGrid({
        url:'scripts/ajax/ajax_poi_list.php?q=1',
        datatype: "json",
        mtype: 'POST',
        colNames:['id', '', 'FirstName', 'LastName', 'Email', 'Phone', 'Position', 'Organisation', 'Connections'],
        colModel:[
            {name:'id',index:'id',width:10, hidden: true, search: false},
            {name:'gravatar',index:'gravatar', width:20, search: false},
             {name:'firstname',index:'firstname', width:90, editable: true},
             {name:'lastname',index:'lastname', width:100, editable: true},
             {name:'email',index:'email', width:200,align:"left", editable: true},
             {name:'phone',index:'phone', width:80, align:"center", editable: true},
             {name:'position',index:'position', width:250, align:"left", editable: true},
             {name:'organisation',index:'organisation', width:100, align:"left", editable: true},
             {name:'connections',index:'connections', width:20, align:"center", editable: false}
         ],
         rowNum:10, rowList:[10,20,50,100],
         imgpath: gridimgpath,
         pager: jQuery('#pager1'),
         sortname: 'lastname',
         viewrecords: true,
         sortorder: "asc",
         subGrid: true,
         subGridUrl : 'scripts/ajax/ajax_poi_connections_list.php?q=1',
         subGridModel : [
             {
             name : ['Case Summary', 'Assigned To', 'Date Due', 'Reason Connected'],
             width: [320, 160, 75, 320],
             align: ['left', 'left', 'Center'],
             params: ['id']
             }
         ],
         ondblClickRow: function(id){
             if(id && id!==lastsel){
                 $('#list1').jqGrid('restoreRow',lastsel);
                 $('#list1').jqGrid('editRow',id,true, false, reload);
             }
         },
         caption:"People of Interest",
         editurl:"scripts/ajax/ajax_poi_update.php"
      }).navGrid('#pager1',{
         edit:true,
         add:false,
         del:true
      },
      {}, //Edit options
      {}, //Add options
      {   afterSubmit: function(response,postdata) {
              if(response.responseText != "") {
                  alert(response.responseText);
              }
              $('#list1').trigger('reloadGrid');
              $('#delmodlist1').hide();
              },
      }, //Delete options
      {
          afterShowSearch: function() {
              $(".opsel").hide();
          },
          caption: "Search for...",
          Find: "Find",
          Reset: "Reset",
          sopt: ['eq', 'ne', 'cn', 'nc', 'gt', 'lt', 'ge', 'le'],
          groupOps: false,
          closeAfterSearch: true
      }, //Search options
      {} //View paramaters
      );      
  }

  /**
   *
   * @access public
   * @return void
   **/
  function reload(result){
    $('#list1').trigger('reloadGrid');
  }

});