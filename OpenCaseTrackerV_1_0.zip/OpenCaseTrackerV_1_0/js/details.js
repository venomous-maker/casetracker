function lookup(inputString) {
    /* When adding connections, search the POI database as the user types a name */
    if(inputString.length == 0) {
        // Hide the suggestion box.
        $('#suggestions').hide();
    } else {
        // Search the database
        $.post("scripts/ajax/ajax_poi_search.php", {queryString: ""+inputString+""}, function(data){
            if(data.length >0) {
                // Some data has been returned, so show something
			    $('#autoSuggestionsList').html('');
                $('#suggestions').show();
				$('#addbutton').hide();
				$('#poi_submit').show();
                $('#autoSuggestionsList').html(data);
            }
        });
    }
} // lookup

function fill(thisValue) {
    $('#inputString').val(thisValue);
    $('#suggestions').hide();
	$('#addbutton').show();
}
$(document).ready(function(){

	$('.edit').editable('scripts/ajax/ajax_update_attachment_file_date.php', {
	    type    : 'datepicker',
		id		: 'attachmentid',
		tooltip : 'Click to edit...',
		submit  : 'OK',
		cancel  : 'Cancel',
		indicator: 'Saving...'
	});
	$('.desedit').editable('scripts/ajax/ajax_update_attachment_description.php', {
		id		: 'attachmentid',
		tooltip : 'Click to edit...',
		submit  : 'OK',
		cancel  : 'Cancel',
		indicator: 'Saving...'
	});

	$('.jeditable').editable('scripts/ajax/ajax_poi_updatecomment.php', {
	    indicator : 'Saving comment update...',
	    tooltip   : 'Click to edit...',
	    id        : 'connection_id',
	    style     : 'inherit'
	});

	$(".postform").live('click', function() {
	    var firstname=$("input#poi_firstname").val();
	    var lastname=$("input#poi_lastname").val();
	    var position=$("input#poi_position").val();
	    var phone=$("input#poi_phone").val();
	    var email=$("input#poi_email").val();
	    var organisation=$("input#poi_organisation").val();
	    var dataString='firstname='+firstname+'&lastname='+lastname+'&position='+position+'&phone='+phone+'&email='+email+'&organisation='+organisation;
	    $.ajax({
	      type: "POST",
	      url: "scripts/ajax/ajax_poi_post.php",
	      data: dataString,
	      success: function(data) {
	        $("#postnewform").html("<div id='message'>SUCCESS</div>");
            $("#message").html("<h2>New Person Submitted!</h2>")
	         .append("<p>Thank you</p>")
	         .hide()
	         .fadeIn(1500, function() {
	           $('#message').append(data);
			 });
            //Put the data into the Name form
            $("#inputString").val(firstname+" "+lastname);
            lookup($("#inputString").val());
		  }
		});
		return false;
	});
	$(".addnewpoi").live('click', function() {
	    var id=this.id.split('_');
	    var thisid=id[1];
		var dataString='id='+thisid+'&task_id='+task_id;
		$.ajax({
	      type: "POST",
	      url: "scripts/ajax/ajax_poi_connect.php",
	      data: dataString,
	      success: function(data) {
	        $("#results").toggle();
	        $("#postnewform").html("<div id='message'>Working...</div>");
	        $("#message").html("<h2>Connect person to this case</h2>")
	         .append("<p>Complete the following information:</p>")
	         .hide()
	         .fadeIn(1500, function() {
	           $('#message').append(data);
			 });
		  }
		});
		return false;
	});
});