$(document).ready(function(){
	$('#showmorefilter').click(function() {
	   $('#advancedsearch').toggle('slow');
	   $('#filtersubmit1').toggle();
	});
});
